# تست پیوست عکس در تیکت‌ها. اول smoke_test.py (برای نصب سایت تستی روی پورت ۸۰۹۹) را اجرا کن، بعد این فایل را.
import requests, re, io, os, sqlite3, glob
from PIL import Image
B='http://127.0.0.1:8099'; fails=0
def tok(h): m=re.search(r'name="_t" value="([^"]+)"',h); return m.group(1) if m else None
def check(n,c,x=''):
    global fails; print(('PASS ' if c else 'FAIL ')+n, '' if c else x); fails+= (not c)
def png(color=(66,99,235),size=(120,80)):
    b=io.BytesIO(); Image.new('RGB',size,color).save(b,'PNG'); return b.getvalue()
def login(mobile):
    s=requests.Session(); r=s.get(B+'/login.php'); s.post(B+'/login.php',data={'_t':tok(r.text),'act':'send','mobile':mobile})
    r=s.get(B+'/login.php'); code=re.findall(r'کد ورود شما به جیب‌چک: (\d{5})',open('/tmp/t/storage/sms_debug.log').read())[-1]
    r=s.post(B+'/login.php',data={'_t':tok(r.text),'act':'verify','code':code}); return s
con=sqlite3.connect('/tmp/t/storage/data.sqlite')
a=requests.Session(); r=a.get(B+'/admin/login.php'); a.post(B+'/admin/login.php',data={'_t':tok(r.text),'username':'admin','password':'Passw0rd!x'})
u=login('09130000001'); other=login('09130000002')
# ۱) ساخت تیکت با دو عکس
r=u.get(B+'/ticket.php'); check('new-ticket form has file input + multipart','name="images[]"' in r.text and 'multipart/form-data' in r.text)
r=u.post(B+'/ticket.php',data={'_t':tok(r.text),'act':'new','subject':'تست عکس','body':'عکس صفحه‌ی خطا پیوست است'},
         files=[('images[]',('a.png',png(),'image/png')),('images[]',('b.png',png((200,50,50)),'image/png'))])
check('ticket with images created','تیکت ثبت شد' in r.text, r.text[:200])
tid=con.execute("select max(id) from tickets").fetchone()[0]
fids=[x[0] for x in con.execute("select f.id from ticket_files f join ticket_msgs m on m.id=f.msg_id where m.ticket_id=? order by f.id",(tid,))]
check('2 files recorded',len(fids)==2,fids)
check('files exist on disk in storage/tickets',len(glob.glob('/tmp/t/storage/tickets/*.png'))==2)
check('storage/tickets blocked from web by .htaccess',os.path.isfile('/tmp/t/storage/tickets/.htaccess'))
page=u.get(B+f'/ticket.php?id={tid}').text
check('user page shows both images',all(f'ticket_file.php?id={i}' in page for i in fids))
# ۲) کنترل دسترسی
r=u.get(B+f'/ticket_file.php?id={fids[0]}'); check('owner can open image',r.status_code==200 and r.headers['Content-Type']=='image/png' and r.content[:4]==b'\x89PNG')
check('anonymous gets 404',requests.get(B+f'/ticket_file.php?id={fids[0]}').status_code==404)
check('other user gets 404',other.get(B+f'/ticket_file.php?id={fids[0]}').status_code==404)
check('admin can open image',a.get(B+f'/ticket_file.php?id={fids[0]}').status_code==200)
check('admin ticket page shows images',f'ticket_file.php?id={fids[1]}' in a.get(B+f'/admin/tickets.php?id={tid}').text)
# ۳) پاسخ ادمین با عکس (و فقط عکس بدون متن)
r=a.get(B+f'/admin/tickets.php?id={tid}'); check('admin form has file input','name="images[]"' in r.text and 'multipart/form-data' in r.text)
r=a.post(B+f'/admin/tickets.php?id={tid}',data={'_t':tok(r.text),'act':'reply','body':'راهنما در تصویر است'},files=[('images[]',('g.png',png((10,160,90)),'image/png'))])
check('admin reply with image saved','پاسخ ثبت شد' in r.text,r.text[:200])
r=a.get(B+f'/admin/tickets.php?id={tid}'); r=a.post(B+f'/admin/tickets.php?id={tid}',data={'_t':tok(r.text),'act':'reply','body':''},files=[('images[]',('g2.png',png((90,10,160)),'image/png'))])
check('admin image-only reply allowed','پاسخ ثبت شد' in r.text)
page=u.get(B+f'/ticket.php?id={tid}').text
check('user sees admin images',len(re.findall(r'ticket_file\.php\?id=\d+',page))>=8)   # هر عکس دو بار (لینک + تصویر)
# ۴) پاسخ کاربر فقط با عکس
r=u.get(B+f'/ticket.php?id={tid}'); r=u.post(B+f'/ticket.php?id={tid}',data={'_t':tok(r.text),'act':'reply','body':''},files=[('images[]',('c.png',png(),'image/png'))])
check('user image-only reply allowed','پیام ارسال شد' in r.text,r.text[:200])
r=u.get(B+f'/ticket.php?id={tid}'); r=u.post(B+f'/ticket.php?id={tid}',data={'_t':tok(r.text),'act':'reply','body':''})
check('empty reply (no text, no image) rejected','متن پیام خالی است' in r.text)
# ۵) فایل‌های نامعتبر
n0=con.execute("select count(*) from ticket_files").fetchone()[0]; m0=con.execute("select count(*) from ticket_msgs").fetchone()[0]
def reply(files):
    r=u.get(B+f'/ticket.php?id={tid}'); return u.post(B+f'/ticket.php?id={tid}',data={'_t':tok(r.text),'act':'reply','body':'تست'},files=files).text
check('fake image (text renamed .png) rejected','فقط عکس' in reply([('images[]',('x.png',b'<?php echo 1; ?>','image/png'))]))
check('php file rejected','فقط عکس' in reply([('images[]',('shell.php',b'<?php system($_GET[0]); ?>','application/x-php'))]))
check('4 images rejected (max 3)','حداکثر' in reply([('images[]',(f'{i}.png',png(),'image/png')) for i in range(4)]))
big=io.BytesIO(); Image.frombytes('RGB',(1500,1500),os.urandom(1500*1500*3)).save(big,'PNG')
check('image over 5MB rejected','کمتر از' in reply([('images[]',('big.png',big.getvalue(),'image/png'))]), len(big.getvalue()))
check('nothing stored for rejected uploads',con.execute("select count(*) from ticket_files").fetchone()[0]==n0 and con.execute("select count(*) from ticket_msgs").fetchone()[0]==m0)
check('no stray files on disk',len([f for f in glob.glob('/tmp/t/storage/tickets/*') if f.endswith(('.png','.jpg','.webp'))])==n0 and not glob.glob('/tmp/t/storage/tickets/*.php'))
# ۶) حذف تیکت => حذف عکس‌ها
def confirm_delete(url):
    r=a.get(url); r=a.post(url,data={'_t':tok(r.text),'act':'delete'}); m=re.search(r'name="token" value="([^"]+)"',r.text)
    return a.post(url,data={'_t':tok(r.text),'act':'confirm_apply','token':m.group(1)}) if m else None
check('delete ticket confirm ok',confirm_delete(B+f'/admin/tickets.php?id={tid}') is not None)
check('ticket files rows gone',con.execute("select count(*) from ticket_files").fetchone()[0]==0)
check('image files removed from disk',len(glob.glob('/tmp/t/storage/tickets/*.png'))==0)
# ۷) آرم و آیکن سایت
h=requests.get(B+'/').text
check('logo image in header','assets/logo-192.png' in h and 'rel="icon"' in h and 'favicon-32.png' in h and 'apple-touch-icon' in h)
for p in ['/assets/logo-192.png','/assets/favicon-32.png','/assets/favicon-192.png','/assets/apple-touch-icon.png','/favicon.ico','/assets/fonts/JibSans-Regular.woff2']:
    check('asset served '+p,requests.get(B+p).status_code==200)
print('FAILS:',fails)
