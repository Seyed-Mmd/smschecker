import requests, re, json, hashlib, time, os, io, sqlite3, subprocess
B='http://127.0.0.1:8099'
def tok(html):
    m=re.search(r'name="_t" value="([^"]+)"',html); return m.group(1) if m else None
def confirm2(sess, url, data):
    # دو مرحله: اول درخواست را می‌فرستد و باید فقط جعبه‌ی تایید نشان دهد، بعد با همان توکن تایید نهایی می‌زند
    r = sess.get(url); d = dict(data); d['_t'] = tok(r.text)
    r = sess.post(url, data=d)
    m = re.search(r'name="token" value="([^"]+)"', r.text)
    if not m: return r, False   # جعبه‌ی تایید ظاهر نشد (یعنی اجرا فوری شده یا خطا داده)
    r2 = sess.post(url, data={'_t': tok(r.text), 'act': 'confirm_apply', 'token': m.group(1)})
    return r2, True
def check(name,cond,extra=''):
    print(('PASS ' if cond else 'FAIL ')+name, extra if not cond else '')
    if not cond: global fails; fails+=1
fails=0
# --- install
s=requests.Session()
r=s.get(B+'/install.php'); t=tok(r.text)
r=s.post(B+'/install.php',data={'_t':t,'site_url':B,'driver':'sqlite','admin_user':'admin','admin_pass':'Passw0rd!x'})
check('install done','نصب با موفقیت' in r.text, r.text[:300])
# enable dev mode
cfg=open('/tmp/t/config.php').read().replace("'dev_mode' => false","'dev_mode' => true"); open('/tmp/t/config.php','w').write(cfg)
for p in ['/','/buy.php','/login.php','/terms.php','/panel.php','/ticket.php','/admin/login.php']:
    r=requests.get(B+p,allow_redirects=False); check('GET '+p, r.status_code in (200,302), r.status_code)
r=requests.get(B+'/'); check('landing has jalali/persian',"جیب‌چک" in r.text and "خرید کد" in r.text)
# --- admin settings
a=requests.Session()
r=a.get(B+'/admin/login.php'); t=tok(r.text)
r=a.post(B+'/admin/login.php',data={'_t':t,'username':'admin','password':'bad'}); check('admin bad login rejected','اشتباه' in r.text)
r=a.post(B+'/admin/login.php',data={'_t':tok(r.text),'username':'admin','password':'Passw0rd!x'}); check('admin login','داشبورد' in r.text, r.text[:200])
r=a.get(B+'/admin/settings.php'); t=tok(r.text)
form={'_t':t,'act':'save','site_name':'جیب‌چک','price':'149000','license_days':'365','max_uses':'2','app_download_url':'https://example.com/app.apk',
 'buy_note':'','support_note':'پاسخ سریع','pay_gateway_on':'1','zarinpal_merchant':'x'*36,'pay_card_on':'1','card_number':'6037-9911-2233-4455','card_holder':'علی رضایی','card_bank':'ملی',
 'sms_api_key':'k','sms_line':'30001','admin_phone':'09120000001','admin_notify':'1'}
r=a.post(B+'/admin/settings.php',data=form); check('settings saved','ذخیره شد' in r.text, r.text[:200])
check('card number digits stored','6037991122334455' in a.get(B+'/admin/settings.php').text)
# --- user login
u=requests.Session()
r=u.get(B+'/buy.php'); check('buy redirects to login','ورود / ثبت‌نام' in r.text or 'کد ورود' in r.text)
t=tok(r.text)
r=u.post(B+'/login.php',data={'_t':t,'act':'send','mobile':'۰۹۱۲۳۴۵۶۷۸۹'}); check('otp step shown','کد ۵ رقمی' in r.text, r.text[:300])
log=open('/tmp/t/storage/sms_debug.log').read(); code=re.findall(r'کد ورود شما به جیب‌چک: (\d{5})',log)[-1]
r=u.post(B+'/login.php',data={'_t':tok(r.text),'act':'verify','code':'00000'}); check('wrong otp rejected','کد اشتباه' in r.text)
r=u.post(B+'/login.php',data={'_t':tok(r.text),'act':'verify','code':code}); check('login ok -> buy page','روش پرداخت' in r.text, r.url)
# --- buy card
t=tok(r.text)
r=u.post(B+'/buy.php',data={'_t':t,'method':'card'}); check('terms required','قوانین' in r.text and 'روش پرداخت' in r.text)
r=u.post(B+'/buy.php',data={'_t':tok(r.text),'method':'card','terms':'1'}); check('card page','6037 9911 2233 4455' in r.text, r.url)
oid=re.search(r'id=(\d+)',r.url).group(1)
png=bytes.fromhex('89504e470d0a1a0a0000000d49484452000000010000000108060000001f15c4890000000a49444154789c6300010000050001')+b''
import base64
png=base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==')
r=u.post(B+f'/card.php?id={oid}',data={'_t':tok(r.text)},files={'receipt':('r.php.png',io.BytesIO(b'<?php echo 1;'),'image/png')}); check('fake receipt rejected','فقط عکس رسید' in r.text)
r=u.get(B+f'/card.php?id={oid}'); 
r=u.post(B+f'/card.php?id={oid}',data={'_t':tok(r.text)},files={'receipt':('r.png',io.BytesIO(png),'image/png')}); check('receipt accepted','منتظر تایید' in r.text, r.text[:300])
check('admin sms sent for order','سفارش در انتظار تایید' in open('/tmp/t/storage/sms_debug.log').read())
r=u.get(B+f'/receipt.php?id={oid}'); check('owner sees receipt', r.status_code==200 and r.headers['content-type']=='image/png')
check('anon cannot see receipt', requests.get(B+f'/receipt.php?id={oid}').status_code==404)
# --- admin approve
r=a.get(B+'/admin/orders.php?s=awaiting_review'); check('order listed in admin', f'<td>{"".join(chr(0x6f0+int(c)) for c in oid)}</td>' in r.text)
r=a.post(B+'/admin/orders.php',data={'_t':tok(r.text),'id':oid,'act':'approve'}); 
m=re.search(r'JC-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}',r.text); check('approved + code shown',bool(m),r.text[:300]); CODE=m.group(0)
check('code sms sent to user',CODE in open('/tmp/t/storage/sms_debug.log').read())
r=a.post(B+'/admin/orders.php',data={'_t':tok(r.text),'id':oid,'act':'approve'}); check('double approve idempotent', len(re.findall(r'JC-',open('/tmp/t/storage/sms_debug.log').read()))>=1 and a.get(B+'/admin/codes.php').text.count(CODE)==1)
# --- static page
h=hashlib.sha256(CODE.encode()).hexdigest()
r=requests.get(B+f'/c/{h}.json'); check('static code page', r.status_code==200 and r.json()['ok'] is True, r.text)
check('unknown code page 404', requests.get(B+'/c/'+'0'*64+'.json').status_code==404)
check('c/ dir listing blocked(php srv n/a)', True)
# --- activation API
def act(code,dev,name='Pixel'): return requests.post(B+'/api/activate.php',json={'code':code,'device':dev,'name':name}).json()
d1=hashlib.sha256(b'd1').hexdigest(); d2=hashlib.sha256(b'd2').hexdigest(); d3=hashlib.sha256(b'd3').hexdigest()
check('activate #1',act(CODE,d1)['ok'])
check('same device again not consuming',act(CODE,d1)['used']==1)
check('activate #2',act(CODE,d2)['used']==2)
r=act(CODE,d3); check('third device blocked',r=={'ok':False,'error':'limit'},r)
check('lower-case/no-dash code accepted',act(CODE.replace('-','').lower(),d1)['ok'])
check('invalid code',act('JC-AAAA-BBBB-CCCC',d1)['error']=='invalid')
# --- user panel
r=u.get(B+'/panel.php'); check('panel shows code and slots',CODE in r.text and 'ظرفیت تمام شده' in r.text, '')
# --- revoke (حالا همه‌ی این اعمال دومرحله‌ای هستند)
r=a.get(B+'/admin/codes.php'); cid=re.search(r'name="id" value="(\d+)"',r.text).group(1)
r,ok = confirm2(a, B+'/admin/codes.php', {'id':cid,'act':'revoke'}); check('revoke needs confirm & applies', ok)
check('static page revoked',requests.get(B+f'/c/{h}.json').json()['ok'] is False)
check('api says revoked',act(CODE,d1)['error']=='revoked')
r,ok = confirm2(a, B+'/admin/codes.php', {'id':cid,'act':'restore'}); check('restore needs confirm & applies', ok)
r,ok = confirm2(a, B+'/admin/codes.php', {'id':cid,'act':'extend','days':'30'}); check('extend needs confirm & applies', ok)
check('restored',requests.get(B+f'/c/{h}.json').json()['ok'] is True)
# expiry
import sqlite3; con=sqlite3.connect('/tmp/t/storage/data.sqlite'); con.execute('update codes set expires_at=?',(int(time.time())-10,)); con.commit()
r,ok = confirm2(a, B+'/admin/codes.php', {'id':cid,'act':'rewrite'}); check('rewrite needs confirm & applies', ok)
j=requests.get(B+f'/c/{h}.json').json(); check('expired page has past expiry', 0<j["expires"]<time.time())
check('api says expired',act(CODE,d1)['error']=='expired')
r=u.get(B+'/panel.php'); check('panel shows expired','منقضی شده' in r.text)
# --- tickets
r=u.get(B+'/ticket.php'); r=u.post(B+'/ticket.php',data={'_t':tok(r.text),'act':'new','subject':'مشکل فعال‌سازی','body':'کد من کار نمی‌کند لطفاً بررسی کنید'})
check('ticket created','مشکل فعال‌سازی' in r.text and 'تیکت ثبت شد' in r.text)
check('admin ticket sms','تیکت پشتیبانی جدید' in open('/tmp/t/storage/sms_debug.log').read())
tid=re.search(r'id=(\d+)',r.url).group(1)
r=a.get(B+f'/admin/tickets.php?id={tid}'); r=a.post(B+f'/admin/tickets.php?id={tid}',data={'_t':tok(r.text),'act':'reply','body':'بررسی شد، تمدید شد.'})
check('admin reply -> user sms','پاسخ داده شده' in r.text or 'پاسخ ثبت شد' in r.text and 'شما در جیب‌چک پاسخ داده شد' in open('/tmp/t/storage/sms_debug.log').read())
r=u.get(B+f'/ticket.php?id={tid}'); check('user sees admin reply','بررسی شد، تمدید شد.' in r.text and 'پاسخ داده شد' in r.text)
# notify disabled
form['admin_notify']='0'; del form['admin_notify']
r=a.get(B+'/admin/settings.php'); form['_t']=tok(r.text); a.post(B+'/admin/settings.php',data=form)
n=open('/tmp/t/storage/sms_debug.log').read().count('تیکت پشتیبانی جدید')
r=u.get(B+f'/ticket.php?id={tid}'); u.post(B+f'/ticket.php?id={tid}',data={'_t':tok(r.text),'act':'reply','body':'ممنون'})
check('admin notify off respected',open('/tmp/t/storage/sms_debug.log').read().count('تیکت پشتیبانی جدید')==n)
# gateway w/o network -> graceful
r=a.get(B+'/admin/settings.php'); 
r=u.get(B+'/buy.php'); r=u.post(B+'/buy.php',data={'_t':tok(r.text),'method':'gateway','terms':'1'},allow_redirects=True)
check('gateway failure handled gracefully','اتصال به درگاه' in r.text, r.text[:200])
# --- کد تخفیف
def coupon_add(code,kind,value,max_uses='0',days='0'):
    r=a.get(B+'/admin/coupons.php'); return a.post(B+'/admin/coupons.php',data={'_t':tok(r.text),'act':'add','code':code,'kind':kind,'value':value,'max_uses':max_uses,'days':days})
def coupon_act(code,act,**kw):
    r=a.get(B+'/admin/coupons.php'); cid=con2.execute('select id from coupons where code=?',(code,)).fetchone()[0]
    return a.post(B+'/admin/coupons.php',data=dict({'_t':tok(r.text),'id':cid,'act':act},**kw))
def apply_coupon(sess,code):
    r=sess.get(B+'/buy.php'); return sess.post(B+'/buy.php',data={'_t':tok(r.text),'act':'coupon','coupon':code})
con2=sqlite3.connect('/tmp/t/storage/data.sqlite')
check('coupons page loads', a.get(B+'/admin/coupons.php').status_code==200)
check('coupon created (percent)','ساخته شد' in coupon_add('test20','percent','20','2').text)
check('coupon created (fixed)','ساخته شد' in coupon_add('FIX50','fixed','50000','1').text)
check('coupon created (free)','ساخته شد' in coupon_add('FREE100','percent','100').text)
check('coupon created (auto code)','ساخته شد' in coupon_add('','percent','5').text)
check('duplicate coupon rejected','قبلاً ثبت شده' in coupon_add('TEST20','percent','10').text)
check('percent > 100 rejected','بین ۱ تا ۱۰۰' in coupon_add('BAD1','percent','150').text)
check('code is stored upper-case', con2.execute("select count(*) from coupons where code='TEST20'").fetchone()[0]==1)
r=apply_coupon(u,'NOPE'); check('unknown coupon rejected','وجود ندارد' in r.text)
r=apply_coupon(u,'test20'); check('percent coupon applied, price shown','اعمال شد' in r.text and '۱۱۹,۲۰۰ تومان' in r.text and '۱۴۹,۰۰۰ تومان' in r.text, r.text[:200])
r=u.post(B+'/buy.php',data={'_t':tok(r.text),'act':'coupon_remove'}); check('coupon removed','۱۱۹,۲۰۰' not in r.text and 'کد تخفیف (اختیاری)' in r.text)
r=apply_coupon(u,'TEST20')
r=u.post(B+'/buy.php',data={'_t':tok(r.text),'method':'card','terms':'1'}); check('discounted card order created', 'card.php?id=' in r.url and '۱۱۹,۲۰۰ تومان' in r.text, r.url)
oid2=re.search(r'id=(\d+)',r.url).group(1)
row=con2.execute('select amount,orig_amount,discount,coupon_id from orders where id=?',(oid2,)).fetchone()
check('order stores amount/orig/discount/coupon', row[0]==119200 and row[1]==149000 and row[2]==29800 and row[3] is not None, row)
r=a.get(B+'/admin/orders.php'); check('admin sees discount on order','TEST20' in r.text)
check('not counted before approval', con2.execute("select count(*) from orders where coupon_id=? and status='approved'",(row[3],)).fetchone()[0]==0)
r=a.post(B+'/admin/orders.php',data={'_t':tok(r.text),'id':oid2,'act':'approve'}); check('discounted order approved','تایید شد' in r.text)
r=a.get(B+'/admin/coupons.php'); check('usage counted after approval', re.search(r'TEST20.*?۱ از ۲',r.text,re.S) is not None)
r=apply_coupon(u,'TEST20'); check('same user cannot reuse coupon','قبلاً از این کد' in r.text)
r=u.get(B+'/panel.php'); check('panel shows discount hint','با تخفیف' in r.text)
# مبلغ ثابت + سقف تعداد
r=apply_coupon(u,'FIX50'); check('fixed coupon applied','۹۹,۰۰۰ تومان' in r.text, r.text[:100])
r=u.post(B+'/buy.php',data={'_t':tok(r.text),'method':'card','terms':'1'}); oid3=re.search(r'id=(\d+)',r.url).group(1)
r=a.get(B+'/admin/orders.php'); a.post(B+'/admin/orders.php',data={'_t':tok(r.text),'id':oid3,'act':'approve'})
u2=requests.Session(); r=u2.get(B+'/login.php'); u2.post(B+'/login.php',data={'_t':tok(r.text),'act':'send','mobile':'09129998877'})
code2=re.findall(r'کد ورود شما به جیب‌چک: (\d{5})',open('/tmp/t/storage/sms_debug.log').read())[-1]
r=u2.get(B+'/login.php'); r=u2.post(B+'/login.php',data={'_t':tok(r.text),'act':'verify','code':code2}); check('second user logged in','پنل' in r.text or 'کد فعال‌سازی' in r.text, r.url)
r=apply_coupon(u2,'FIX50'); check('capacity reached -> rejected','ظرفیت' in r.text)
# منقضی و غیرفعال
con2.execute("update coupons set expires_at=? where code='TEST20'",(int(time.time())-5,)); con2.commit()
r=apply_coupon(u2,'TEST20'); check('expired coupon rejected','مهلت' in r.text)
coupon_act('FREE100','toggle'); r=apply_coupon(u2,'FREE100'); check('inactive coupon rejected','فعال نیست' in r.text)
coupon_act('FREE100','toggle')
# تخفیف ۱۰۰٪ => بدون پرداخت
r=apply_coupon(u2,'FREE100'); check('free coupon shows free','رایگان' in r.text and 'نیازی به پرداخت نیست' in r.text)
r=u2.post(B+'/buy.php',data={'_t':tok(r.text),'terms':'1'}, allow_redirects=True); check('free order -> panel with code','صادر شد' in r.text and re.search(r'JC-[A-Z0-9]{4}-',r.text) is not None, r.url)
fr=con2.execute("select status,method,amount,discount from orders where method='coupon'").fetchone(); check('free order approved without payment', fr==('approved','coupon',0,149000), fr)
check('free code sms sent', open('/tmp/t/storage/sms_debug.log').read().count('JC-')>=3)
# حداقل مبلغ قابل پرداخت و حذف
print(subprocess.run(['php','-r','require "/tmp/t/inc/coupon.php"; echo json_encode([coupon_apply(149000,["kind"=>"fixed","value"=>148500]),coupon_apply(149000,["kind"=>"fixed","value"=>999999999]),coupon_apply(149000,["kind"=>"percent","value"=>33])]);'],capture_output=True,text=True).stdout)
r=coupon_act('FIX50','delete'); check('used coupon cannot be deleted','قبلاً استفاده شده' in r.text)
coupon_add('TMP9','percent','9'); r=coupon_act('TMP9','delete'); check('unused coupon deleted','حذف شد' in r.text)
r=coupon_act('FIX50','setmax',max_uses='5'); r=apply_coupon(u2,'FIX50'); check('raising cap re-opens coupon','اعمال شد' in r.text)
# csrf
check('csrf enforced', requests.post(B+'/admin/orders.php',data={'id':1,'act':'approve'}).status_code in (400,302,200))
r=a.post(B+'/admin/orders.php',data={'id':1,'act':'approve'}); check('csrf missing -> 400',r.status_code==400)
# admin protected
check('admin pages need login', requests.get(B+'/admin/orders.php',allow_redirects=False).status_code==302)
# jalali sanity
import subprocess
print(subprocess.run(['php','-r','require "/tmp/t/inc/helpers.php"; date_default_timezone_set("Asia/Tehran"); echo strip_tags(jdate(strtotime("2026-10-10")))," ",strip_tags(jdate(strtotime("2026-03-21")))," ",strip_tags(jdate(strtotime("2025-03-21")));'],capture_output=True,text=True).stdout)
# --- پلن‌های چندگانه
def plan_add(name,price,days,max_uses):
    r=a.get(B+'/admin/plans.php'); return a.post(B+'/admin/plans.php',data={'_t':tok(r.text),'act':'add','name':name,'price':price,'days':days,'max_uses':max_uses})
check('plans page loads', a.get(B+'/admin/plans.php').status_code==200)
r=plan_add('یک ماهه','49000','30','1'); check('monthly plan created','ساخته شد' in r.text)
r=plan_add('نامحدود','990000','0','5'); check('unlimited plan created','ساخته شد' in r.text)
plans=con2.execute("select id,name,days from plans order by id").fetchall(); check('3 plans total (default+2)', len(plans)==3, plans)
monthly_id=[p[0] for p in plans if p[1]=='یک ماهه'][0]; unlimited_id=[p[0] for p in plans if p[1]=='نامحدود'][0]
r=u.get(B+'/buy.php?plan='+str(monthly_id)); r=u.get(B+'/buy.php')
check('buy.php shows selected plan price','۴۹,۰۰۰ تومان' in r.text and 'یک ماهه' in r.text, r.text[:200])
check('plan picker shown for 3 plans','نوع اشتراک را انتخاب کن' in r.text)
r=u.post(B+'/buy.php',data={'_t':tok(r.text),'method':'card','terms':'1'})
oid_m=re.search(r'id=(\d+)',r.url).group(1)
row=con2.execute('select plan_id,plan_days,plan_max_uses,plan_name,amount from orders where id=?',(oid_m,)).fetchone()
check('order snapshots plan fields', row==(monthly_id,30,1,'یک ماهه',49000), row)
r=a.get(B+'/admin/orders.php'); a.post(B+'/admin/orders.php',data={'_t':tok(r.text),'id':oid_m,'act':'approve'})
code_row=con2.execute("select max_uses,expires_at from codes where order_id=?",(oid_m,)).fetchone()
exp_days=(code_row[1]-int(time.time()))/86400
check('issued code matches plan (1 slot, ~30d)', code_row[0]==1 and 28<exp_days<31, code_row)
# پلن نامحدود => expires_at=0
r=u.get(B+'/buy.php?plan='+str(unlimited_id)); r=u.get(B+'/buy.php')
r=u.post(B+'/buy.php',data={'_t':tok(r.text),'method':'card','terms':'1'}); oid_u=re.search(r'id=(\d+)',r.url).group(1)
r=a.get(B+'/admin/orders.php'); a.post(B+'/admin/orders.php',data={'_t':tok(r.text),'id':oid_u,'act':'approve'})
ucode=con2.execute("select max_uses,expires_at from codes where order_id=?",(oid_u,)).fetchone()
check('unlimited plan -> expires_at 0, 5 slots', ucode==(5,0), ucode)
# صدور دستی ادمین هنوز از تنظیمات سراسری استفاده می‌کند (بدون تغییر رفتار قبلی)
r=a.get(B+'/admin/codes.php'); r=a.post(B+'/admin/codes.php',data={'_t':tok(r.text),'act':'issue','mobile':'09120004444','sms':'1'})
manual=con2.execute("select max_uses,expires_at from codes where order_id is null order by id desc limit 1").fetchone()
check('manual issuance unaffected by plans', manual[0]==2, manual)
# حذف/پنهان‌سازی پلن خریداری‌شده مجاز نیست، فقط پنهان
r=a.post(B+'/admin/plans.php',data={'_t':tok(a.get(B+'/admin/plans.php').text),'id':monthly_id,'act':'delete'})
check('cannot delete plan already purchased','پنهان کن' in r.text)
r=a.post(B+'/admin/plans.php',data={'_t':tok(a.get(B+'/admin/plans.php').text),'id':monthly_id,'act':'toggle'})
r=u.get(B+'/buy.php'); check('hidden plan no longer offered','یک ماهه' not in r.text or 'نوع اشتراک' in r.text)

# --- کد تخفیف: سقف استفاده‌ی هر کاربر
r=coupon_add('MULTI5','percent','10','0'); r=a.get(B+'/admin/coupons.php')
cid=con2.execute("select id from coupons where code='MULTI5'").fetchone()[0]
r=a.post(B+'/admin/coupons.php',data={'_t':tok(r.text),'id':cid,'act':'setperuser','per_user_max':'2'})
check('per-user cap updated', con2.execute('select per_user_max from coupons where id=?',(cid,)).fetchone()[0]==2)
r=apply_coupon(u2,'MULTI5'); r=u2.post(B+'/buy.php',data={'_t':tok(r.text),'method':'card','terms':'1'})
oid1=re.search(r'id=(\d+)',r.url).group(1); r=a.get(B+'/admin/orders.php'); a.post(B+'/admin/orders.php',data={'_t':tok(r.text),'id':oid1,'act':'approve'})
r=apply_coupon(u2,'MULTI5'); check('2nd use allowed within per-user cap','اعمال شد' in r.text)
r=u2.post(B+'/buy.php',data={'_t':tok(r.text),'method':'card','terms':'1'})
oid2=re.search(r'id=(\d+)',r.url).group(1); r=a.get(B+'/admin/orders.php'); a.post(B+'/admin/orders.php',data={'_t':tok(r.text),'id':oid2,'act':'approve'})
r=apply_coupon(u2,'MULTI5'); check('3rd use blocked (cap=2)','سهمیه' in r.text, r.text[:200])

# --- تایید دومرحله‌ای برای کاهش روز/ظرفیت کد
r=a.get(B+'/admin/codes.php'); cid2=con2.execute("select id from codes where order_id=?",(oid_m,)).fetchone()[0]
exp_before=con2.execute("select expires_at from codes where id=?",(cid2,)).fetchone()[0]
r=a.post(B+'/admin/codes.php',data={'_t':tok(r.text),'id':cid2,'act':'dec_days','days':'5'})
check('decrease-days shows confirm box, not applied yet','تایید نهایی لازم است' in r.text and con2.execute("select expires_at from codes where id=?",(cid2,)).fetchone()[0]==exp_before)
tok2=re.search(r'name="token" value="([^"]+)"',r.text).group(1)
r=a.post(B+'/admin/codes.php',data={'_t':tok(r.text),'act':'confirm_apply','token':tok2})
exp_after=con2.execute("select expires_at from codes where id=?",(cid2,)).fetchone()[0]
check('decrease-days applied after confirm', abs((exp_before-exp_after)-5*86400)<5, (exp_before,exp_after))
# کاهش ظرفیت زیر تعداد گوشی فعال‌شده مجاز نیست؛ با کد ۵ظرفیتی (پلن نامحدود) و ۱ دستگاه فعال تست می‌کنیم
cid3=con2.execute("select id from codes where order_id=?",(oid_u,)).fetchone()[0]
con2.execute("insert into activations(code_id,device_hash,device_name,first_at,last_at) values (?,?,?,?,?)",(cid3,'h1','dev1',int(time.time()),int(time.time()))); con2.commit()
r=a.get(B+'/admin/codes.php'); r=a.post(B+'/admin/codes.php',data={'_t':tok(r.text),'id':cid3,'act':'dec_cap','cap':'10'})
check('dec_cap clamped to active device count, shows confirm','تایید نهایی لازم است' in r.text and 'بیشتر از این کم نمی‌شود' in r.text, r.text[:300])
tok3=re.search(r'name="token" value="([^"]+)"',r.text).group(1)
r=a.post(B+'/admin/codes.php',data={'_t':tok(r.text),'act':'confirm_cancel'})
check('cancel leaves max_uses unchanged', con2.execute("select max_uses from codes where id=?",(cid3,)).fetchone()[0]==5)
r=a.get(B+'/admin/codes.php'); r=a.post(B+'/admin/codes.php',data={'_t':tok(r.text),'id':cid3,'act':'dec_cap','cap':'2'})
tok4=re.search(r'name="token" value="([^"]+)"',r.text).group(1)
r=a.post(B+'/admin/codes.php',data={'_t':tok(r.text),'act':'confirm_apply','token':tok4})
check('dec_cap applied after confirm (5-2=3)', con2.execute("select max_uses from codes where id=?",(cid3,)).fetchone()[0]==3)
# کد یک‌ظرفیتی که همان یک گوشی را دارد: کاهش بیشتر اصلاً مجاز نیست (بدون جعبه‌ی تایید)
con2.execute("insert into activations(code_id,device_hash,device_name,first_at,last_at) values (?,?,?,?,?)",(cid2,'h2','dev2',int(time.time()),int(time.time()))); con2.commit()
r=a.get(B+'/admin/codes.php'); r=a.post(B+'/admin/codes.php',data={'_t':tok(r.text),'id':cid2,'act':'dec_cap','cap':'5'})
check('dec_cap refused outright when already at floor','بیشتر کم کرد' in r.text and 'تایید نهایی لازم است' not in r.text, r.text[:200])

# --- «مرا به‌خاطر بسپار»
check('remember cookie set after login', 'jc_remember' in u.cookies.get_dict())
sel = u.cookies.get('jc_remember').split('%3A')[0] if '%3A' in u.cookies.get('jc_remember') else u.cookies.get('jc_remember').split(':')[0]
check('remember token stored in db', con2.execute('select count(*) from remember_tokens where selector=?',(sel,)).fetchone()[0]==1)
fresh = requests.Session(); fresh.cookies.set('jc_remember', u.cookies.get('jc_remember'), domain='127.0.0.1')
r = fresh.get(B+'/panel.php'); check('fresh client auto-logged-in via remember cookie', 'پنل' in r.text and 'ورود / ثبت‌نام' not in r.text, r.text[:150])
old_sel = sel
check('old token rotated away after use', con2.execute('select count(*) from remember_tokens where selector=?',(old_sel,)).fetchone()[0]==0)
r = u.get(B+'/logout.php')
check('logout clears remember cookie', u.cookies.get('jc_remember') in (None, '', '""'))

# --- حذف کامل کد (با تایید دومرحله‌ای)
r=a.get(B+'/admin/codes.php'); r=a.post(B+'/admin/codes.php',data={'_t':tok(r.text),'id':cid2,'act':'delete_code'})
check('delete_code shows confirm, not deleted yet','تایید نهایی لازم است' in r.text and 'قابل بازگشت نیست' in r.text and con2.execute('select count(*) from codes where id=?',(cid2,)).fetchone()[0]==1, r.text[:200])
tok5=re.search(r'name="token" value="([^"]+)"',r.text).group(1)
code_str=con2.execute('select code from codes where id=?',(cid2,)).fetchone()[0]
import hashlib as _h; pagefile='/tmp/t/c/'+_h.sha256(code_str.encode()).hexdigest()+'.json'
check('static code page exists before delete', os.path.isfile(pagefile))
r=a.post(B+'/admin/codes.php',data={'_t':tok(r.text),'act':'confirm_apply','token':tok5})
check('code row deleted after confirm', con2.execute('select count(*) from codes where id=?',(cid2,)).fetchone()[0]==0)
check('activations cleaned up', con2.execute('select count(*) from activations where code_id=?',(cid2,)).fetchone()[0]==0)
check('order.code_id nulled out', con2.execute('select code_id from orders where id=?',(oid_m,)).fetchone()[0] is None)
check('static code page removed', not os.path.isfile(pagefile))
r=a.get(B+'/admin/codes.php'); check('deleted code no longer listed', code_str not in r.text)

# --- کاربر تازه برای تست‌های تیکت/حذف کاربر
u3=requests.Session(); r=u3.get(B+'/login.php'); u3.post(B+'/login.php',data={'_t':tok(r.text),'act':'send','mobile':'09127776655'})
code3=re.findall(r'کد ورود شما به جیب‌چک: (\d{5})',open('/tmp/t/storage/sms_debug.log').read())[-1]
r=u3.get(B+'/login.php'); u3.post(B+'/login.php',data={'_t':tok(r.text),'act':'verify','code':code3})
uid3=con2.execute("select id from users where mobile='09127776655'").fetchone()[0]

# --- بسته‌شدن تیکت: کاربر دیگر نتواند پیام بدهد
r=u3.get(B+'/ticket.php'); r=u3.post(B+'/ticket.php',data={'_t':tok(r.text),'act':'new','subject':'تست بستن تیکت','body':'یک سوال تستی دارم'})
tid3=re.search(r'id=(\d+)',r.url).group(1)
r=u3.post(B+'/ticket.php?id='+tid3,data={'_t':tok(r.text),'act':'close'})
check('ticket closed by user', con2.execute('select status from tickets where id=?',(tid3,)).fetchone()[0]=='closed')
r=u3.get(B+'/ticket.php?id='+tid3)
check('no reply form shown on closed ticket', 'name="body"' not in r.text)
csrf_tok = tok(u3.get(B+'/ticket.php').text)   # صفحه‌ی بسته دیگر فرمی (و توکنی) ندارد؛ از لیست تیکت‌ها می‌گیریم تا بی‌اعتباری درخواست را شبیه‌سازی کنیم
r=u3.post(B+'/ticket.php?id='+tid3,data={'_t':csrf_tok,'act':'reply','body':'یه چیز دیگه می‌خوام بگم'})
check('reply on closed ticket rejected server-side','نمی‌توانی در آن پیام بدهی' in r.text)
check('no new message actually inserted', con2.execute('select count(*) from ticket_msgs where ticket_id=?',(tid3,)).fetchone()[0]==1)

# --- حذف تیکت (ادمین، دومرحله‌ای)
r=a.get(B+'/admin/tickets.php'); check('ticket search by subject', 'تست بستن تیکت' in a.get(B+'/admin/tickets.php?q=بستن+تیکت').text)
r,ok = confirm2(a, B+f'/admin/tickets.php?id={tid3}', {'act':'delete'}); check('ticket delete needs confirm & applies', ok)
check('ticket row gone', con2.execute('select count(*) from tickets where id=?',(tid3,)).fetchone()[0]==0)
check('ticket messages gone', con2.execute('select count(*) from ticket_msgs where ticket_id=?',(tid3,)).fetchone()[0]==0)

# --- حذف سفارش (ادمین، دومرحله‌ای)
r=u3.get(B+'/buy.php'); r=u3.post(B+'/buy.php',data={'_t':tok(r.text),'method':'card','terms':'1'})
oid3=re.search(r'id=(\d+)',r.url).group(1)
check('order search by id', str(oid3) in a.get(B+'/admin/orders.php?q='+str(oid3)).text)
r,ok = confirm2(a, B+'/admin/orders.php', {'id':oid3,'act':'delete'}); check('order delete needs confirm & applies', ok)
check('order row gone', con2.execute('select count(*) from orders where id=?',(oid3,)).fetchone()[0]==0)

# --- یادداشت روی کد و کاربر
r=a.get(B+'/admin/codes.php'); cid_note=re.search(r'name="id" value="(\d+)"',r.text).group(1)
r=a.post(B+'/admin/codes.php',data={'_t':tok(r.text),'id':cid_note,'act':'note','note':'این کاربر VIP است'})
check('code note saved (no confirm needed)', con2.execute('select note from codes where id=?',(cid_note,)).fetchone()[0]=='این کاربر VIP است')
r=a.post(B+'/admin/users.php',data={'_t':tok(a.get(B+'/admin/users.php').text),'id':uid3,'act':'note','note':'چند بار تماس گرفته'})
check('user note saved', con2.execute('select note from users where id=?',(uid3,)).fetchone()[0]=='چند بار تماس گرفته')
_fa_digits = str.maketrans('0123456789','۰۱۲۳۴۵۶۷۸۹')
check('user search by mobile', '09127776655'.translate(_fa_digits) in a.get(B+'/admin/users.php?q=09127776655').text)

# --- حذف کامل کاربر (آبشاری: سفارش‌ها، کدها، تیکت‌ها)
r=u3.get(B+'/ticket.php'); u3.post(B+'/ticket.php',data={'_t':tok(r.text),'act':'new','subject':'تیکت باقی‌مانده','body':'این باید با حذف کاربر از بین برود'})
nord=con2.execute('select count(*) from orders where user_id=?',(uid3,)).fetchone()[0]
ncod=con2.execute('select count(*) from codes where user_id=?',(uid3,)).fetchone()[0]
ntik=con2.execute('select count(*) from tickets where user_id=?',(uid3,)).fetchone()[0]
check('user has data to cascade (orders+codes+tickets>0)', nord+ncod+ntik>0, (nord,ncod,ntik))
r=a.get(B+'/admin/users.php'); r=a.post(B+'/admin/users.php',data={'_t':tok(r.text),'id':uid3,'act':'delete_user'})
check('delete_user shows confirm with counts', 'تایید نهایی لازم است' in r.text and 'قابل بازگشت نیست' in r.text)
check('user not deleted yet', con2.execute('select count(*) from users where id=?',(uid3,)).fetchone()[0]==1)
tok6=re.search(r'name="token" value="([^"]+)"',r.text).group(1)
r=a.post(B+'/admin/users.php',data={'_t':tok(r.text),'act':'confirm_apply','token':tok6})
check('user deleted', con2.execute('select count(*) from users where id=?',(uid3,)).fetchone()[0]==0)
check('cascaded: orders gone', con2.execute('select count(*) from orders where user_id=?',(uid3,)).fetchone()[0]==0)
check('cascaded: codes gone', con2.execute('select count(*) from codes where user_id=?',(uid3,)).fetchone()[0]==0)
check('cascaded: tickets gone', con2.execute('select count(*) from tickets where user_id=?',(uid3,)).fetchone()[0]==0)

print('FAILS:',fails)
