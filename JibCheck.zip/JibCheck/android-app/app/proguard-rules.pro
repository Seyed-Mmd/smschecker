# قوانین R8 برای نسخه‌ی release.
# برنامه از Reflection، Gson یا Parcelable استفاده نمی‌کند، پس نیازی به keep گسترده نیست؛
# همین چند مورد برای اطمینان کافی است.

# فعالیت‌ها، سرویس و گیرنده‌های پخشی که در AndroidManifest.xml نام‌شان آمده را AGP خودش keep می‌کند؛
# این خط فقط برای اطمینان بیشتر (مثلاً اگر جایی با نام کلاس از Intent استفاده شد) است.
-keep public class com.example.banksms.** extends android.app.Activity
-keep public class com.example.banksms.** extends android.app.Service
-keep public class com.example.banksms.** extends android.content.BroadcastReceiver

# SQLiteOpenHelper (Db.kt) با متدهای onCreate/onUpgrade از اندروید صدا زده می‌شود
-keep class com.example.banksms.Db { *; }

# شماره‌خط را برای خوانا ماندن کرش‌لاگ‌ها نگه می‌داریم، ولی نام فایل واقعی کاتلین را حذف می‌کنیم
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute ""
