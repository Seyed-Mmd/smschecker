import java.util.Properties

plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

// امضای نسخه نهایی: فایل keystore.properties را کنار این فایل بساز (نمونه: keystore.properties.sample).
// این فایل و کلید (jks) را هرگز در گیت یا جای عمومی نگذار.
val keyProps = Properties().apply {
    val f = file("keystore.properties")
    if (f.exists()) f.inputStream().use { load(it) }
}

android {
    namespace = "com.example.banksms"
    compileSdk = 34
    defaultConfig {
        applicationId = "ir.jibcheck.app"
        minSdk = 26; targetSdk = 34; versionCode = 12; versionName = "1.2"
    }
    signingConfigs {
        if (keyProps.containsKey("storeFile")) create("release") {
            storeFile = file(keyProps.getProperty("storeFile")); storePassword = keyProps.getProperty("storePassword")
            keyAlias = keyProps.getProperty("keyAlias"); keyPassword = keyProps.getProperty("keyPassword")
        }
    }
    buildTypes {
        getByName("release") {
            if (keyProps.containsKey("storeFile")) signingConfig = signingConfigs.getByName("release")
            // R8 کد را کوچک، بهینه و مبهم (obfuscate) می‌کند تا مهندسی معکوس و کرک سخت‌تر شود.
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    lint { checkReleaseBuilds = false; abortOnError = false }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
