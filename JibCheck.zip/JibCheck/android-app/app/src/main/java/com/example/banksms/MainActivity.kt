package com.example.banksms

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

private const val NONE_FILTER = "__none__"
private const val REQ_IMPORT = 77

private const val PRIVACY = "تراکنش‌ها، دسته‌بندی‌ها و پیامک‌های بانکی فقط روی همین گوشی ذخیره می‌شوند و هیچ‌جا ارسال نمی‌شوند. برنامه تنها برای فعال‌سازی، بررسی اعتبار کد و پشتیبانی به اینترنت وصل می‌شود و در آن فقط کد فعال‌سازی و یک شناسه‌ی ناشناس دستگاه به سرور می‌رسد. پیامک‌ها فقط برای تشخیص تراکنش بانکی خوانده می‌شوند و پیامک‌های غیرمالی ذخیره نمی‌شوند. گزارش‌ها و پشتیبان‌ها فقط وقتی که خودت دکمه‌ی ارسال را بزنی و برنامه‌ی مقصد را انتخاب کنی بیرون می‌روند."

class MainActivity : Activity() {
    private var tab = 0
    private var dFrom = ""
    private var dTo = ""
    private var filterCat = ""
    private var filterBank = ""
    private var query = ""
    private var withSummary = false
    private val exportCats = linkedSetOf<String>()   // دسته‌های انتخاب‌شده برای گزارش متنی (خالی = همه)
    private var savedScroll = 0
    private var animateNext = true   // فقط هنگام باز شدن، عوض شدن تب یا تم، صفحه نرم ظاهر می‌شود
    private var scroller: ScrollView? = null
    private var navInit = false
    private var prevTab = -1   // برای حرکت لغزان لایه‌ی شیشه‌ای تب انتخاب‌شده
    private val sp by lazy { getSharedPreferences("prefs", MODE_PRIVATE) }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (!Activation.isActive(this)) { startActivity(Intent(this, ActivationActivity::class.java)); finish(); return }
        C.load(this)
        C.style(window)
        val r = Dates.thisMonth(); dFrom = r.first; dTo = r.second
        // بازگرداندن وضعیت قبلی (بعد از تغییر تم سیستم، چرخش صفحه یا بسته شدن توسط سیستم)
        if (b != null) {
            tab = b.getInt("tab", 0)
            dFrom = b.getString("dFrom", dFrom) ?: dFrom
            dTo = b.getString("dTo", dTo) ?: dTo
            filterCat = b.getString("filterCat", "") ?: ""
            filterBank = b.getString("filterBank", "") ?: ""
            query = b.getString("query", "") ?: ""
            withSummary = b.getBoolean("withSummary", false)
            b.getString("exportCats", "")?.split('\u0001')?.filter { it.isNotEmpty() }?.let { exportCats.addAll(it) }
            savedScroll = b.getInt("scrollY", 0)
        }
        if (!sp.getBoolean("setup_done", false)) startActivity(Intent(this, PermissionsActivity::class.java))
    }

    override fun onSaveInstanceState(o: Bundle) {
        super.onSaveInstanceState(o)
        o.putInt("tab", tab); o.putString("dFrom", dFrom); o.putString("dTo", dTo)
        o.putString("filterCat", filterCat); o.putString("filterBank", filterBank)
        o.putString("query", query); o.putBoolean("withSummary", withSummary)
        o.putString("exportCats", exportCats.joinToString("\u0001"))
        o.putInt("scrollY", scroller?.scrollY ?: savedScroll)
    }

    override fun onResume() {
        super.onResume()
        if (!Activation.isActive(this)) { startActivity(Intent(this, ActivationActivity::class.java)); finish(); return }
        Launcher.startService(this)
        Activation.recheckIfDue(this) { why ->
            startActivity(Intent(this, ActivationActivity::class.java).putExtra("reason", why)); finish()
        }
        render()
    }

    private fun openLink(url: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (e: Exception) { toast("مرورگری برای باز کردن لینک پیدا نشد") }
    }

    private fun openTx(id: Long) = startActivity(Intent(this, EditActivity::class.java).putExtra("id", id))

    private fun share(text: String) = startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"; putExtra(Intent.EXTRA_TEXT, text)
    }, null))

    // ───────────── قالب اصلی: محتوا + نوار پایین + دکمه شناور ─────────────
    private fun render() {
        scroller?.let { savedScroll = it.scrollY }   // جای اسکرول فعلی را نگه می‌داریم
        val db = Db(this)
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(if (!C.lite) 124 else if (tab <= 1) 96 else 24))
        }
        when (tab) { 0 -> home(db, page); 1 -> txs(db, page); 2 -> stats(db, page); else -> settings(db, page) }

        val root = FrameLayout(this).apply { setBackgroundColor(C.bg); layoutDirection = View.LAYOUT_DIRECTION_RTL }
        if (!C.lite) root.addView(GlassBg(this), FrameLayout.LayoutParams(-1, -1))
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val content = FrameLayout(this)
        val sv = ScrollView(this).apply { isFillViewport = true; addView(centered(page)); restoreScroll(savedScroll) }
        scroller = sv
        if (animateNext) { animateNext = false; page.fadeIn() }
        content.addView(sv, FrameLayout.LayoutParams(-1, -1))

        val fab: View? = if (tab <= 1) TextView(this).apply {
            text = "＋"; textSize = 28f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            background = fabBg()
            elevation = dp(if (C.lite) 6 else 8).toFloat(); pressable()
            setOnClickListener { startActivity(Intent(this@MainActivity, EditActivity::class.java).putExtra("new", true)) }
        } else null
        if (fab != null) {
            val lp = FrameLayout.LayoutParams(dp(58), dp(58), Gravity.BOTTOM or Gravity.START)
            lp.setMargins(dp(20), 0, dp(20), dp(if (C.lite) 20 else 100))
            content.addView(fab, lp)
        }
        col.put(content, 0, -1, 1f, 0, 0)
        val nav = navBar()
        // حالت شیشه‌ای: نوار جزیره‌ای روی محتوا شناور است تا محتوا از پشت شیشه دیده شود
        if (C.lite) col.put(nav) else content.addView(nav, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        root.addView(col, FrameLayout.LayoutParams(-1, -1))

        // وقتی کیبورد باز است، نوار پایین و دکمه ＋ پنهان شوند
        root.viewTreeObserver.addOnGlobalLayoutListener {
            val r = Rect(); root.getWindowVisibleDisplayFrame(r)
            val h = root.rootView.height
            val vis = if (h - r.bottom > h * 0.15) View.GONE else View.VISIBLE
            nav.visibility = vis
            fab?.visibility = vis
        }
        setContentView(root)
    }

    private fun navBar(): View {
        val items = listOf("🏠" to "خانه", "📋" to "تراکنش‌ها", "📊" to "آمار", "⚙️" to "تنظیمات")
        val inner = LinearLayout(this).apply { clipChildren = false }
        items.forEachIndexed { i, kv ->
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; minimumHeight = dp(52)
                setPadding(0, dp(5), 0, dp(5))
                addView(tv(kv.first, if (i == tab && !C.lite) 22f else 20f).apply { gravity = Gravity.CENTER })
                addView(tv(kv.second, 11f, if (i == tab) C.primary else C.muted, i == tab).apply {
                    maxLines = 1; ellipsize = TextUtils.TruncateAt.END; gravity = Gravity.CENTER
                })
                pressable()
                setOnClickListener { if (tab != i) { prevTab = tab; tab = i; savedScroll = 0; animateNext = true; render() } }
            }
            inner.put(item, 0, 0, 1f)
        }
        val holder = MaxWidth(this@MainActivity, dp(640)).apply {
            clipChildren = false
            addView(inner, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        if (C.lite) {
            // حالت سبک: همان نوار ساده
            return LinearLayout(this).apply {
                background = shape(C.card, 0); elevation = dp(8).toFloat()
                setPadding(0, dp(8), 0, dp(8))
                addView(holder, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
            }
        }

        // حالت شیشه‌ای: لایه‌ی دوم شیشه (لنز) زیر تب انتخاب‌شده می‌لغزد
        val lens = View(this).apply { background = lensGlass(24); visibility = View.INVISIBLE }
        val stack = FrameLayout(this).apply {
            clipChildren = false
            addView(lens, FrameLayout.LayoutParams(0, -1, Gravity.START))
            addView(holder, FrameLayout.LayoutParams(-1, -2))
        }
        inner.post {
            val w = inner.width / items.size
            if (w <= 0) return@post
            val sign = if (inner.layoutDirection == View.LAYOUT_DIRECTION_RTL) -1f else 1f
            val off = (stack.width - inner.width) / 2f
            lens.layoutParams = (lens.layoutParams as FrameLayout.LayoutParams).apply { width = w }
            lens.visibility = View.VISIBLE
            val to = sign * (tab * w + off)
            if (prevTab in items.indices && prevTab != tab) {
                lens.translationX = sign * (prevTab * w + off)
                lens.scaleX = 1.06f; lens.scaleY = 0.92f
                lens.animate().translationX(to).scaleX(1f).scaleY(1f).setDuration(320)
                    .setInterpolator(android.view.animation.OvershootInterpolator(0.9f)).start()
            } else if (!navInit) {
                lens.translationX = to
                lens.alpha = 0f; lens.scaleX = 0.8f; lens.scaleY = 0.8f
                lens.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(260).start()
            } else lens.translationX = to
            navInit = true
            prevTab = tab
        }
        val bar = FrameLayout(this).apply {
            clipChildren = false
            background = islandGlass(34); setPadding(dp(8), dp(7), dp(8), dp(7))
            addView(stack, FrameLayout.LayoutParams(-1, -2))
        }
        return FrameLayout(this).apply {
            clipChildren = false; clipToPadding = false
            setPadding(dp(18), dp(4), dp(18), dp(14))
            addView(bar, FrameLayout.LayoutParams(-1, -2))
        }
    }

    // ───────────── اجزای مشترک ─────────────
    private fun txRow(t: Tx, onClick: () -> Unit, onLong: (() -> Unit)? = null): View {
        val inc = t.type == "deposit"
        val row = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(8), 0, dp(8))
            setOnClickListener { onClick() }
        }
        if (onLong != null) row.setOnLongClickListener { onLong(); true }
        val icon = tv(if (inc) "＋" else "－", 18f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(if (inc) C.green else C.red) }
        }
        row.put(icon, 0, dp(40), 0f, 0, 40)
        val title = t.desc.ifEmpty { t.merchant }.ifEmpty { Parser.label(t.type) }
        val sub = listOf(t.cat, t.bank, Dates.fmtTime(t.time)).filter { it.isNotEmpty() }.joinToString("  •  ")
        val mid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        mid.put(tv(title, 15f, C.text, true))
        mid.put(tv(sub, 12f, C.muted))
        row.put(mid, 0, 0, 1f, 12)
        row.put(tv(Parser.fmt(t.amount), 14f, if (inc) C.green else C.text, true), 0, -2, 0f, 8)
        return row
    }

    // میله‌های افقی هزینه بر اساس کلید دلخواه (دسته، بانک، ...)
    private fun bars(list: List<Tx>, key: (Tx) -> String): LinearLayout {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val sums = list.filter { it.type != "deposit" }.groupBy(key)
            .mapValues { e -> e.value.sumOf { it.amount } }.entries.sortedByDescending { it.value }
        val max = sums.firstOrNull()?.value ?: 0L
        if (max == 0L) { box.put(tv("هنوز هزینه‌ای ثبت نشده", 13f, C.muted)); return box }
        sums.forEachIndexed { i, e ->
            val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
            head.put(tv(e.key, 14f), 0, 0, 1f)
            head.put(tv(Parser.fmt(e.value), 13f, C.muted), 0, -2)
            box.put(head, if (i == 0) 0 else 14)
            val frac = (e.value.toFloat() / max).coerceIn(0.03f, 1f)
            val track = LinearLayout(this).apply { background = trackBg() }
            track.put(View(this).apply { background = shape(C.palette[i % C.palette.size], 4) }, 0, 0, frac, 0, 8)
            track.put(View(this), 0, 0, 1f - frac, 0, 8)
            box.put(track, 6)
        }
        return box
    }

    private fun statCard(label: String, value: String, color: Int): LinearLayout {
        val c = card(14)
        c.put(tv(label, 12f, C.muted))
        c.put(tv(value, 17f, color, true).apply { fit(11, 17) }, 4)
        return c
    }

    private fun legendRow(color: Int, name: String, v: Long, total: Long): View {
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        row.put(View(this).apply {
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(color) }
        }, 0, dp(10), 0f, 0, 10)
        row.put(tv(name, 14f), 0, 0, 1f, 10)
        row.put(tv(Parser.fmt(v), 13f, C.muted), 0, -2, 0f, 8)
        row.put(tv("${if (total > 0) v * 100 / total else 0}٪", 13f, C.text, true), 0, -2, 0f, 8)
        return row
    }

    // ───────────── تب خانه ─────────────
    private fun home(db: Db, p: LinearLayout) {
        val brand = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        brand.put(ImageView(this).apply { setImageResource(R.drawable.ic_logo) }, 0, dp(36), 0f, 0, 36)
        brand.put(tv("جیب‌چک", 20f, C.text, true), 0, -2, 0f, 10)
        p.put(brand)

        val range = Dates.monthRange()
        val month = db.done().filter { it.time >= range.first && it.time < range.second }
        val exp = month.filter { it.type != "deposit" }.sumOf { it.amount }
        val inc = month.filter { it.type == "deposit" }.sumOf { it.amount }
        val light = Color.parseColor("#DDE3FF")

        val h = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = heroBg(26)
            setPadding(dp(20), dp(20), dp(20), dp(20))
        }
        h.put(tv("هزینه این ماه", 13f, light))
        h.put(tv(Parser.fmt(exp), 30f, Color.WHITE, true).apply { fit(16, 30) }, 4)

        val budget = sp.getLong("budget", 0L)
        if (budget > 0) {
            val f = maxOf((exp.toFloat() / budget).coerceIn(0f, 1f), 0.02f)
            val track = LinearLayout(this).apply { background = shape(Color.parseColor("#33FFFFFF"), 4) }
            track.put(View(this).apply {
                background = shape(if (exp > budget) Color.parseColor("#FFB4AB") else Color.WHITE, 4)
            }, 0, 0, f, 0, 8)
            track.put(View(this), 0, 0, 1f - f, 0, 8)
            h.put(track, 14)
            h.put(tv(if (exp <= budget) "${exp * 100 / budget}٪ از بودجه • مانده ${Parser.fmt(budget - exp)}"
                else "از بودجه ${Parser.fmt(exp - budget)} بیشتر شده", 12f, light), 6)
        }

        val row = LinearLayout(this)
        fun stat(l: String, v: String): LinearLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(tv(l, 12f, light)); addView(tv(v, 15f, Color.WHITE, true))
        }
        row.put(stat("درآمد این ماه", Parser.fmt(inc)), 0, 0, 1f)
        row.put(stat("تراز", Parser.fmt(inc - exp)), 0, 0, 1f)
        h.put(row, 16)
        p.put(h, 12)

        Expiry.message(this)?.takeIf { Activation.isActive(this) }?.let { msg ->
            val w = card(14).apply { background = tintBox(C.redBg, 0xE6, C.red, 0x66, 20) }
            w.put(tv("⏳ پایان اشتراک نزدیک است", 15f, C.red, true))
            w.put(tv("$msg می‌توانی از همین حالا کد جدید بخری تا برنامه قطع نشود.", 13f, C.text).apply { setLineSpacing(0f, 1.25f) }, 4)
            w.put(pill("تمدید (خرید کد جدید)") { openLink(Config.BUY_URL) }, 10)
            w.put(pill("خروجی CSV از تراکنش‌ها", C.chipBg, C.text) { exportCsv(db) }, 8)
            p.put(w, 12)
        }

        val missing = buildList {
            if (checkSelfPermission(Manifest.permission.RECEIVE_SMS) != PackageManager.PERMISSION_GRANTED) add("دریافت پیامک")
            if (!Settings.canDrawOverlays(this@MainActivity)) add("نمایش روی برنامه‌ها")
            if (!getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(packageName)) add("بدون محدودیت باتری")
            if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) add("اعلان‌ها")
        }
        if (missing.isNotEmpty()) {
            val w = card()
            w.put(tv("⚠️ چند مجوز هنوز داده نشده", 15f, C.text, true))
            w.put(tv("بدون این مجوزها ثبت خودکار تراکنش‌ها ممکن است کار نکند: " + missing.joinToString("، "), 13f, C.muted).apply { setLineSpacing(0f, 1.25f) }, 4)
            w.put(pill("تنظیم مجوزها") {
                startActivity(Intent(this@MainActivity, PermissionsActivity::class.java).putExtra("fromSettings", true))
            }, 10)
            p.put(w, 12)
        }

        val open = db.open()
        if (open.isNotEmpty()) {
            val c = card(12)
            c.put(tv("در انتظار ثبت (${open.size})", 16f, C.text, true))
            open.forEach { t -> c.put(txRow(t, { openTx(t.id) })) }
            p.put(c, 12)
        }

        val c2 = card()
        c2.put(tv("هزینه این ماه به تفکیک دسته", 16f, C.text, true))
        c2.put(bars(month) { it.cat.ifEmpty { "بدون دسته" } }, 12)
        p.put(c2, 12)

        if (month.any { it.bank.isNotEmpty() && it.type != "deposit" }) {
            val c4 = card()
            c4.put(tv("هزینه این ماه به تفکیک بانک", 16f, C.text, true))
            c4.put(bars(month) { it.bank.ifEmpty { "نقدی / نامشخص" } }, 12)
            p.put(c4, 12)
        }

        val c3 = card(12)
        c3.put(tv("آخرین تراکنش‌ها", 16f, C.text, true))
        val last = db.done().take(5)
        if (last.isEmpty()) c3.put(tv("هنوز تراکنشی ثبت نشده. با دکمه ＋ یکی اضافه کن.", 13f, C.muted), 8)
        last.forEach { t -> c3.put(txRow(t, { openTx(t.id) })) }
        p.put(c3, 12)
    }

    // ───────────── تب تراکنش‌ها ─────────────
    private fun txs(db: Db, p: LinearLayout) {
        p.put(tv("تراکنش‌ها", 22f, C.text, true))
        val (searchView, search) = searchBox("جست‌وجو در توضیح، پذیرنده، دسته یا بانک", query)
        p.put(searchView, 8)

        val fl = Flow(this)
        fl.addView(chip("همه", filterCat == "") { filterCat = ""; render() })
        db.cats().forEach { n -> fl.addView(chip(n, filterCat == n) { filterCat = n; render() }) }
        fl.addView(chip(Backup.NO_CAT, filterCat == NONE_FILTER) { filterCat = NONE_FILTER; render() })
        p.put(fl, 8)
        val banks = db.banks()
        if (banks.isNotEmpty()) {
            val bl = Flow(this)
            bl.addView(chip("همه بانک‌ها", filterBank == "") { filterBank = ""; render() })
            banks.forEach { n -> bl.addView(chip("🏦 $n", filterBank == n) { filterBank = n; render() }) }
            p.put(bl, 8)
        }

        val summary = tv("", 12f, C.muted)
        p.put(summary, 10)
        val listCard = card(12)
        p.put(listCard, 4)

        fun fill() {
            listCard.removeAllViews()
            val q = Parser.norm(query).trim()
            val list = db.done().filter { t ->
                (filterCat == "" || t.cat == filterCat || (filterCat == NONE_FILTER && t.cat.isEmpty())) &&
                    (filterBank == "" || t.bank == filterBank) &&
                    (q.isEmpty() || listOf(t.desc, t.merchant, t.cat.ifEmpty { Backup.NO_CAT }, t.bank)
                        .any { Parser.norm(it).contains(q, ignoreCase = true) })
            }
            summary.text = "${list.size} تراکنش • هزینه: ${Parser.fmt(list.filter { it.type != "deposit" }.sumOf { it.amount })}"
            if (list.isEmpty()) listCard.put(tv("تراکنشی پیدا نشد", 13f, C.muted))
            list.take(300).forEach { t ->
                listCard.put(txRow(t, { openTx(t.id) }, { confirm("حذف شود؟") { db.delete(t.id); render() } }))
            }
        }
        search.onText { query = it; fill() }
        fill()

        val ign = db.ignored()
        if (ign.isNotEmpty()) {
            val g = card(12)
            g.put(tv("نادیده‌گرفته‌شده‌ها (${ign.size}) — در آمار حساب نمی‌شوند", 14f, C.muted, true))
            ign.forEach { t -> g.put(txRow(t, { openTx(t.id) }, { confirm("برای همیشه حذف شود؟") { db.delete(t.id); render() } })) }
            p.put(g, 12)
        }
        p.put(tv("بزن = ویرایش (برای نادیده‌ها: ثبت دوباره)  •  نگه‌دار = حذف", 12f, C.muted), 8)
    }

    // ───────────── تب آمار ─────────────
    private fun stats(db: Db, p: LinearLayout) {
        p.put(tv("آمار", 22f, C.text, true))

        val rc = card()
        rc.put(tv("بازه زمانی (تاریخ شمسی)", 13f, C.muted))
        val fl = Flow(this)
        listOf("این ماه" to Dates.thisMonth(), "ماه قبل" to Dates.prevMonth(),
            "۷ روز اخیر" to Dates.lastDays(7), "۳۰ روز اخیر" to Dates.lastDays(30)).forEach { kv ->
            fl.addView(chip(kv.first, dFrom == kv.second.first && dTo == kv.second.second) {
                dFrom = kv.second.first; dTo = kv.second.second; render()
            })
        }
        rc.put(fl, 8)
        val dates = LinearLayout(this)
        dates.put(field("از (1405/07/01)", dFrom).apply { onText { dFrom = it } }, 0, 0, 1f)
        dates.put(field("تا (1405/07/30)", dTo).apply { onText { dTo = it } }, 0, 0, 1f, 8)
        rc.put(dates, 8)
        rc.put(pill("نمایش", C.chipBg, C.text) { render() }, 8)
        p.put(rc, 12)

        val a = Dates.parseDay(dFrom); val b = Dates.parseDay(dTo)
        if (a == null || b == null || b < a) {
            p.put(tv("تاریخ‌ها را درست بنویس (مثل 1405/07/01)", 13f, C.red), 12)
            return
        }
        val end = b + Dates.DAY
        val inRange = db.done().filter { it.time >= a && it.time < end }
        val exp = inRange.filter { it.type != "deposit" }
        val expSum = exp.sumOf { it.amount }
        val incSum = inRange.filter { it.type == "deposit" }.sumOf { it.amount }
        val days = ((end - a) / Dates.DAY).toInt().coerceAtLeast(1)
        val prevSum = db.expenses(a - (end - a), a).sumOf { it.amount }

        val r1 = LinearLayout(this)
        r1.put(statCard("هزینه", Parser.fmt(expSum), C.red), 0, 0, 1f)
        r1.put(statCard("درآمد", Parser.fmt(incSum), C.green), 0, 0, 1f, 10)
        p.put(r1, 12)
        val r2 = LinearLayout(this)
        r2.put(statCard("تراز", Parser.fmt(incSum - expSum), if (incSum >= expSum) C.green else C.red), 0, 0, 1f)
        r2.put(statCard("میانگین روزانه", Parser.fmt(expSum / days), C.text), 0, 0, 1f, 10)
        p.put(r2, 10)
        if (prevSum > 0) {
            val diff = expSum - prevSum
            val pct = Math.abs(diff) * 100 / prevSum
            p.put(tv(if (diff > 0) "▲ ${pct}٪ بیشتر از دوره قبل (${Parser.fmt(prevSum)})"
                else if (diff < 0) "▼ ${pct}٪ کمتر از دوره قبل (${Parser.fmt(prevSum)})" else "برابر با دوره قبل",
                13f, if (diff > 0) C.red else C.green), 10)
        }

        // نمودار دایره‌ای دسته‌ها
        val catData = exp.groupBy { it.cat.ifEmpty { "بدون دسته" } }.mapValues { e -> e.value.sumOf { it.amount } }
            .entries.sortedByDescending { it.value }.map { Pair(it.key, it.value) }
        val dc = card()
        dc.put(tv("هزینه به تفکیک دسته", 16f, C.text, true))
        if (catData.isEmpty()) dc.put(tv("در این بازه هزینه‌ای ثبت نشده", 13f, C.muted), 8)
        else {
            val box = FrameLayout(this)
            box.addView(Donut(this, catData), FrameLayout.LayoutParams(dp(170), dp(170), Gravity.CENTER))
            box.addView(tv(Parser.fmt(expSum), 13f, C.text, true).apply { gravity = Gravity.CENTER; fit(9, 13) },
                FrameLayout.LayoutParams(dp(100), -2, Gravity.CENTER))
            dc.put(box, 12)
            catData.forEachIndexed { i, d -> dc.put(legendRow(C.palette[i % C.palette.size], d.first, d.second, expSum), 10) }
        }
        p.put(dc, 12)

        // به تفکیک بانک
        if (exp.isNotEmpty()) {
            val bc = card()
            bc.put(tv("هزینه به تفکیک بانک", 16f, C.text, true))
            bc.put(bars(exp) { it.bank.ifEmpty { "نقدی / نامشخص" } }, 12)
            p.put(bc, 12)
        }

        // روند هزینه
        val step = when { days <= 31 -> 1; days <= 186 -> 7; else -> 30 }
        val nb = (days + step - 1) / step
        val vals = LongArray(nb)
        exp.forEach { t ->
            val i = ((t.time - a) / Dates.DAY / step).toInt().coerceIn(0, nb - 1)
            vals[i] += t.amount
        }
        val cc = card()
        cc.put(tv("روند هزینه (${when (step) { 1 -> "روزانه"; 7 -> "هفتگی"; else -> "۳۰ روزه" }})", 16f, C.text, true))
        cc.put(DayBars(this, vals.toList()), 12, -1, 0f, 0, 120)
        val lbl = LinearLayout(this)
        lbl.put(tv(Dates.fmtDay(a), 11f, C.muted), 0, 0, 1f)
        lbl.put(tv(Dates.fmtDay(b), 11f, C.muted), 0, -2)
        cc.put(lbl, 4)
        cc.put(tv("بیشترین: ${Parser.fmt(vals.maxOrNull() ?: 0L)}", 12f, C.muted), 4)
        p.put(cc, 12)

        // بزرگ‌ترین هزینه‌ها
        val top = exp.sortedByDescending { it.amount }.take(5)
        if (top.isNotEmpty()) {
            val tc = card(12)
            tc.put(tv("بزرگ‌ترین هزینه‌ها", 16f, C.text, true))
            top.forEach { t -> tc.put(txRow(t, { openTx(t.id) })) }
            p.put(tc, 12)
        }

        // خروجی متنی: انتخاب دسته‌ها (بدون انتخاب = همه)
        val ec = card()
        ec.put(tv("خروجی متنی (برای ارسال)", 16f, C.text, true))
        ec.put(tv("کدام دسته‌ها در گزارش باشند؟ اگر هیچ‌کدام را انتخاب نکنی، همه ارسال می‌شوند.", 12f, C.muted), 2)
        val cf = Flow(this)
        cf.addView(chip("همه دسته‌ها", exportCats.isEmpty()) { exportCats.clear(); render() })
        (db.cats() + Backup.NO_CAT).forEach { n ->
            cf.addView(chip(n, n in exportCats) { if (!exportCats.add(n)) exportCats.remove(n); render() })
        }
        ec.put(cf, 8)
        val picked = exp.filter { exportCats.isEmpty() || it.cat.ifEmpty { Backup.NO_CAT } in exportCats }
        ec.put(tv("${picked.size} تراکنش • جمع: ${Parser.fmt(picked.sumOf { it.amount })}", 12f, C.muted), 8)
        val ef = Flow(this)
        ef.addView(chip("همراه با خلاصه دسته‌ها", withSummary) { withSummary = !withSummary; render() })
        ec.put(ef, 8)
        ec.put(pill("📤 ارسال گزارش متنی") { exportText(picked.sortedBy { it.time }, a, b) }, 12)
        p.put(ec, 12)
    }

    private fun exportText(list: List<Tx>, a: Long, b: Long) {
        if (list.isEmpty()) { toast(if (exportCats.isEmpty()) "در این بازه خرجی ثبت نشده" else "در دسته‌های انتخاب‌شده خرجی نیست"); return }
        val sb = StringBuilder("گزارش خرج‌ها\nاز ${Dates.fmtDay(a)} تا ${Dates.fmtDay(b)}\n")
        if (exportCats.isNotEmpty()) sb.append("دسته‌ها: ${exportCats.joinToString("، ")}\n")
        sb.append("\n")
        list.forEachIndexed { i, t ->
            val title = t.desc.ifEmpty { t.merchant }.ifEmpty { Parser.label(t.type) }
            val extra = listOf(t.cat, t.bank).filter { it.isNotEmpty() }.joinToString("، ")
            sb.append("${i + 1}. ${Dates.fmtDay(t.time)} — $title${if (extra.isEmpty()) "" else " ($extra)"}: ${Parser.fmt(t.amount)}\n")
        }
        sb.append("\nجمع کل: ${Parser.fmt(list.sumOf { it.amount })}")
        if (withSummary) {
            sb.append("\n\nجمع به تفکیک دسته:\n")
            list.groupBy { it.cat.ifEmpty { "بدون دسته" } }.mapValues { e -> e.value.sumOf { it.amount } }
                .entries.sortedByDescending { it.value }.forEach { sb.append("• ${it.key}: ${Parser.fmt(it.value)}\n") }
        }
        share(sb.toString())
    }

    // ───────────── بازیابی پشتیبان ─────────────
    private fun pickBackup() {
        try {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
            }, REQ_IMPORT)
        } catch (e: Exception) { toast("برنامه‌ای برای انتخاب فایل پیدا نشد") }
    }

    private fun pasteBackup() {
        val et = field("متن CSV را اینجا بچسبان").apply { minLines = 6; gravity = Gravity.TOP or Gravity.START }
        dialog().setTitle("بازیابی از متن").setView(et)
            .setPositiveButton("بازیابی") { _, _ -> val txt = et.text.toString(); runImport { Backup.readTable(txt.toByteArray()) } }
            .setNegativeButton("لغو", null).show()
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val uri = data?.data
        if (req != REQ_IMPORT || res != RESULT_OK || uri == null) return
        runImport {
            val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() }
                ?: throw IllegalArgumentException("فایل خوانده نشد")
            Backup.readTable(bytes)
        }
    }

    private fun runImport(read: () -> List<List<String>>) {
        Thread {
            val msg = try {
                val r = Backup.import(Db(this), read())
                if (r.added + r.existed == 0) "تراکنشی در این فایل پیدا نشد؛ ستون‌ها باید به ترتیب «تاریخ، نوع، مبلغ، دسته، بانک، توضیح» باشند"
                else "${r.added} تراکنش بازیابی شد" + (if (r.newCats > 0) " (${r.newCats} دسته برگشت)" else "") +
                    (if (r.existed > 0) "؛ ${r.existed} تراکنش از قبل بود" else "") + (if (r.bad > 0) "؛ ${r.bad} ردیف نامعتبر" else "")
            } catch (e: Exception) { e.message ?: "خواندن فایل ناموفق بود" }
            runOnUiThread { toast(msg); render() }
        }.start()
    }

    private fun exportCsv(db: Db) = Export.share(this, Export.csvText(db))

    // ───────────── تب تنظیمات ─────────────
    private fun settings(db: Db, p: LinearLayout) {
        p.put(tv("تنظیمات", 22f, C.text, true))

        val th = card()
        th.put(tv("نمایش", 16f, C.text, true))
        val tf = Flow(this)
        listOf("خودکار (سیستم)", "روشن", "تاریک").forEachIndexed { i, label ->
            tf.addView(chip(label, C.mode(this) == i) { C.setMode(this, i); C.load(this); C.style(window); animateNext = true; render() })
        }
        th.put(tf, 8)
        p.put(th, 12)

        val lc = card()
        lc.put(tv("ظاهر و عملکرد", 16f, C.text, true))
        lc.put(tv("«شیشه‌ای» ظاهر کامل با پس‌زمینه‌ی متحرک و کارت‌های نیمه‌شفاف است. اگر گوشی‌ات ضعیف است یا کند می‌شود، «سبک» را انتخاب کن: شیشه و انیمیشن‌ها خاموش می‌شوند و رنگ‌ها ساده و سریع می‌شوند.", 12f, C.muted).apply { setLineSpacing(0f, 1.25f) }, 2)
        val lf = Flow(this)
        lf.addView(chip("✨ شیشه‌ای (کامل)", !C.lite) { C.setLite(this, false); C.load(this); C.style(window); animateNext = true; render() })
        lf.addView(chip("⚡ سبک (گوشی ضعیف)", C.lite) { C.setLite(this, true); C.load(this); C.style(window); animateNext = true; render() })
        lc.put(lf, 8)
        p.put(lc, 12)

        val pc = card()
        pc.put(tv("پاپ‌آپ بعد از خرید", 16f, C.text, true))
        pc.put(tv("وقتی خاموش باشد، تراکنش‌های جدید بدون نمایش پاپ‌آپ مستقیم به «در انتظار ثبت» در صفحه‌ی خانه می‌روند؛ دقیقاً مثل زدن دکمه «بعداً در اپ».", 12f, C.muted).apply { setLineSpacing(0f, 1.25f) }, 2)
        val pf = Flow(this)
        val autoPopup = sp.getBoolean("auto_popup", true)
        pf.addView(chip("روشن", autoPopup) { sp.edit().putBoolean("auto_popup", true).apply(); animateNext = true; render() })
        pf.addView(chip("خاموش", !autoPopup) { sp.edit().putBoolean("auto_popup", false).apply(); animateNext = true; render() })
        pc.put(pf, 8)
        p.put(pc, 12)

        val bc = card()
        bc.put(tv("بودجه ماهانه", 16f, C.text, true))
        bc.put(tv("اگر مبلغی بنویسی، پیشرفت هزینه نسبت به بودجه در صفحه خانه نشان داده می‌شود. خالی یا صفر یعنی غیرفعال.", 12f, C.muted), 2)
        val bf = field("مثلاً 20000000 (تومان)", sp.getLong("budget", 0L).takeIf { it > 0 }?.toString() ?: "", true)
        bc.put(bf, 8)
        bc.put(pill("ذخیره بودجه") {
            val v = Parser.norm(bf.text.toString()).replace(",", "").toLongOrNull() ?: 0L
            sp.edit().putLong("budget", v).apply()
            toast("ذخیره شد")
        }, 8)
        p.put(bc, 12)

        val rules = db.rules()
        val rc = card()
        rc.put(tv("بانک‌ها و فرمت پیامک", 16f, C.text, true))
        rc.put(tv("${rules.count { it.enabled }} فرمت فعال از ${rules.size}  •  بانک‌ها: ${db.banks().joinToString("، ").ifEmpty { "—" }}", 13f, C.muted), 4)
        rc.put(pill("مدیریت بانک‌ها و فرمت‌ها") { startActivity(Intent(this, RulesActivity::class.java)) }, 10)
        p.put(rc, 12)

        val c = card()
        c.put(tv("دسته‌بندی‌ها", 16f, C.text, true))
        c.put(tv("برای حذف روی دسته بزن", 12f, C.muted))
        val fl = Flow(this)
        db.cats().forEach { n ->
            fl.addView(chip("$n  ✕", false) { confirm("دسته «$n» حذف شود؟") { db.delCat(n); render() } })
        }
        c.put(fl, 8)
        val et = field("دسته جدید")
        c.put(et, 12)
        c.put(pill("افزودن دسته") {
            val s = et.text.toString().trim()
            if (s.isNotEmpty()) { db.addCat(s); render() }
        }, 8)
        p.put(c, 12)

        val ex = card()
        ex.put(tv("پشتیبان‌گیری", 16f, C.text, true))
        ex.put(tv("همه تراکنش‌ها را به‌صورت متن CSV (قابل چسباندن در اکسل) می‌فرستد.", 12f, C.muted), 2)
        ex.put(pill("ارسال همه تراکنش‌ها (CSV)", C.chipBg, C.text) { exportCsv(db) }, 8)
        ex.put(tv("بازیابی: فایل پشتیبان (CSV یا Excel با پسوند xlsx) یا متنی که قبلاً فرستاده بودی را برگردان. تراکنش‌هایی که الان در برنامه هست دوباره اضافه نمی‌شوند؛ پس هر چقدر هم تکرار کنی مشکلی نیست.", 12f, C.muted), 14)
        ex.put(pill("📥 بازیابی از فایل") { pickBackup() }, 8)
        ex.put(pill("📋 بازیابی از متن چسبانده‌شده", C.chipBg, C.text) { pasteBackup() }, 8)
        p.put(ex, 12)

        val ac = card()
        ac.put(tv("حساب و پشتیبانی", 16f, C.text, true))
        val exp = Activation.expires(this)
        val code = Activation.code(this)
        ac.put(tv("وضعیت: فعال" + (if (exp > 0) " تا ${Dates.fmtDay(exp * 1000)}" else " (بدون انقضا)"), 13f, C.green, true), 6)
        if (code.isNotEmpty()) ac.put(tv("کد فعال‌سازی: " + code.substring(0, 7) + "-••••-••••", 13f, C.muted).apply { layoutDirection = View.LAYOUT_DIRECTION_LTR; gravity = Gravity.START }, 4)
        ac.put(pill("💬 پشتیبانی و ارسال تیکت") { openLink(Config.SUPPORT_URL) }, 12)
        ac.put(pill("پنل کاربری و کدهای من", C.chipBg, C.text) { openLink(Config.PANEL_URL) }, 8)
        ac.put(pill("بررسی و تنظیم مجوزها", C.chipBg, C.text) {
            startActivity(Intent(this, PermissionsActivity::class.java).putExtra("fromSettings", true))
        }, 8)
        val ver = try { packageManager.getPackageInfo(packageName, 0).versionName } catch (e: Exception) { "" }
        ac.put(tv("جیب‌چک • نسخه $ver", 12f, C.muted), 12)
        p.put(ac, 12)

        val pv = card()
        pv.put(tv("حریم خصوصی", 16f, C.text, true))
        pv.put(tv(PRIVACY, 13f, C.muted), 4)
        p.put(pv, 12)
    }
}
