package com.example.banksms

import android.app.Activity
import android.content.ClipboardManager
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

// صفحه‌ی ورود کد فعال‌سازی؛ تا وقتی برنامه فعال نشده، بقیه‌ی برنامه باز نمی‌شود
class ActivationActivity : Activity() {
    private var busy = false

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        C.load(this); C.style(window)
        if (Activation.isActive(this)) { next(); return }

        val p = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(20), dp(36), dp(20), dp(32))
        }
        p.put(ImageView(this).apply { setImageResource(R.drawable.ic_logo) }, 0, dp(76), 0f, 0, 76)
        p.put(tv("جیب‌چک", 28f, C.text, true).apply { gravity = Gravity.CENTER }, 12)
        p.put(tv("ثبت خودکار هزینه‌ها از روی پیامک بانک", 14f, C.muted).apply { gravity = Gravity.CENTER }, 4)

        val why = intent.getStringExtra("reason")
            ?: if (Expiry.daysLeft(this) == 0) "اعتبار اشتراک تو تمام شده است. برای ادامه، کد فعال‌سازی جدید وارد کن." else null
        why?.let { r ->
            val w = card(14).apply { background = shape(C.redBg, 14) }
            w.put(tv(r, 13f, C.red, true))
            p.put(w, 18)
        }

        val c = card()
        c.put(tv("فعال‌سازی برنامه", 18f, C.text, true))
        c.put(tv("برای شروع، کد فعال‌سازی را وارد کن. این کد بعد از خرید، هم در پیامک برایت ارسال می‌شود و هم در پنل کاربری سایت قابل دیدن است.", 13f, C.muted).apply { setLineSpacing(0f, 1.25f) }, 6)
        val codeF = field("JC-XXXX-XXXX-XXXX").apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            layoutDirection = View.LAYOUT_DIRECTION_LTR; gravity = Gravity.CENTER; textSize = 18f
            setSingleLine(true)
        }
        c.put(codeF, 14)
        val err = tv("", 13f, C.red).apply { visibility = View.GONE }
        c.put(err, 8)

        val go = pill("فعال‌سازی") {}
        fun setBusy(on: Boolean) { busy = on; (go as TextView).text = if (on) "در حال بررسی…" else "فعال‌سازی"; go.alpha = if (on) 0.6f else 1f }
        go.setOnClickListener {
            if (busy) return@setOnClickListener
            err.visibility = View.GONE
            setBusy(true)
            Activation.activate(this, codeF.text.toString()) { r ->
                setBusy(false)
                if (r.ok) { toast("برنامه با موفقیت فعال شد 🎉"); next() }
                else { err.text = r.msg; err.visibility = View.VISIBLE }
            }
        }
        c.put(go, 12)
        c.put(pill("چسباندن کد از کلیپ‌بورد", C.chipBg, C.text) {
            val t = getSystemService(ClipboardManager::class.java).primaryClip?.getItemAt(0)?.text?.toString() ?: ""
            val k = Activation.canonical(t) ?: Activation.canonical(t.trim().split(Regex("\\s+")).firstOrNull { Activation.canonical(it) != null } ?: "")
            if (k != null) codeF.setText(k) else toast("کدی در کلیپ‌بورد پیدا نشد")
        }, 8)
        p.put(c, 20)

        val buy = card()
        buy.put(tv("هنوز کد نداری؟", 16f, C.text, true))
        buy.put(tv("از سایت جیب‌چک می‌توانی با درگاه پرداخت یا کارت‌به‌کارت کد فعال‌سازی بخری. هر کد حداکثر روی دو گوشی قابل فعال‌سازی است.", 13f, C.muted).apply { setLineSpacing(0f, 1.25f) }, 6)
        buy.put(pill("خرید کد فعال‌سازی") { open(Config.BUY_URL) }, 12)
        buy.put(pill("پنل کاربری (دیدن کدهای خریداری‌شده)", C.chipBg, C.text) { open(Config.PANEL_URL) }, 8)
        p.put(buy, 12)

        val saved = Export.count(this)
        if (saved > 0) {
            val ex = card()
            ex.put(tv("تراکنش‌هایت پیش خودت است", 16f, C.text, true))
            ex.put(tv("حتی بدون اشتراک فعال می‌توانی همه‌ی تراکنش‌های ذخیره‌شده‌ات (${Expiry.faNum(saved)} مورد) را به‌صورت CSV، قابل چسباندن در اکسل، خروجی بگیری.", 13f, C.muted).apply { setLineSpacing(0f, 1.25f) }, 6)
            ex.put(pill("ارسال همه تراکنش‌ها (CSV)", C.chipBg, C.text) { Export.share(this, Export.csvText(Db(this))) }, 12)
            p.put(ex, 12)
        }

        p.put(tv("مشکلی داری؟ پشتیبانی", 13f, C.primary, true).apply {
            gravity = Gravity.CENTER; setPadding(0, dp(10), 0, dp(10)); setOnClickListener { open(Config.SUPPORT_URL) }
        }, 12)
        p.put(tv("برنامه فقط برای فعال‌سازی و پشتیبانی به اینترنت وصل می‌شود؛ اطلاعات مالی تو هیچ‌وقت از گوشی خارج نمی‌شود.", 11f, C.muted).apply { gravity = Gravity.CENTER }, 8)

        setContentView(screen(ScrollView(this).apply { setBackgroundColor(C.scrollBg); isFillViewport = true; addView(centered(p, 480)) }))
    }

    private fun open(url: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (e: Exception) { toast("مرورگری برای باز کردن لینک پیدا نشد") }
    }

    private fun next() {
        val setupDone = getSharedPreferences("prefs", MODE_PRIVATE).getBoolean("setup_done", false)
        startActivity(Intent(this, if (setupDone) MainActivity::class.java else PermissionsActivity::class.java))
        finish()
    }
}
