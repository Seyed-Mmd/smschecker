package com.example.banksms

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony

class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (!Activation.isActive(c)) return   // برنامه فعال نشده؛ پیامکی پردازش نمی‌شود
        val msgs = Telephony.Sms.Intents.getMessagesFromIntent(i) ?: return
        val body = msgs.joinToString("") { it.messageBody ?: "" }
        val db = Db(c)
        val p = Parser.parse(body, db.rules())
        if (p == null) {
            if (Parser.looksFinancial(body)) db.addUnknown(body)
            return
        }
        if (db.isDup(p.type, p.amount)) return
        // اگر پاپ‌آپ خودکار در تنظیمات خاموش باشد، تراکنش مستقیم به «در انتظار ثبت» می‌رود؛ دقیقاً مثل زدن دکمه «بعداً در اپ»
        val autoPopup = c.getSharedPreferences("prefs", Context.MODE_PRIVATE).getBoolean("auto_popup", true)
        db.add(p.type, p.amount, p.merchant, p.bank, if (autoPopup) 0 else 2)
        Launcher.startService(c)
        // اگر همین الان با گوشی کار می‌کنی، فوری نشان بده؛ وگرنه منتظر باز شدن قفل می‌ماند
        if (autoPopup && Launcher.usingPhone(c)) Launcher.showPopupIfPending(c)
    }
}
