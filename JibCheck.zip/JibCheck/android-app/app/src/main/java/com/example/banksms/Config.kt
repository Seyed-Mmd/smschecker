package com.example.banksms

// ⚠️ قبل از ساخت نسخه نهایی، آدرس سایت خودت را اینجا بگذار (حتماً با https)
object Config {
    const val SITE = "https://jibcheck.ir"
    const val BUY_URL = "$SITE/buy.php"
    const val PANEL_URL = "$SITE/panel.php"
    const val SUPPORT_URL = "$SITE/ticket.php"
    const val CODE_PAGE_DIR = "$SITE/c"            // صفحه‌های استاتیک کد (بعد از هر خرید ساخته می‌شود)
    const val ACTIVATE_API = "$SITE/api/activate.php"
    const val CHECK_EVERY_MS = 24L * 60 * 60 * 1000  // بررسی دوباره اعتبار کد، حداکثر روزی یک بار
}
