package com.example.banksms

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import java.util.TimeZone

// هشدار نزدیک شدن به پایان اشتراک (و تمام شدن آن)
object Expiry {
    const val WARN_DAYS = 7          // از چند روز مانده به انقضا هشدار داده شود
    private const val CH = "expiry"

    fun faNum(n: Int): String = n.toString().map { if (it in '0'..'9') '۰' + (it - '0') else it }.joinToString("")

    // روزهای باقی‌مانده (گرد به بالا). ۰ = تمام شده. null = بدون انقضا یا هنوز فعال نشده
    fun daysLeft(c: Context): Int? {
        if (Activation.code(c).isEmpty()) return null
        val exp = Activation.expires(c)
        if (exp <= 0L) return null
        val ms = exp * 1000 - System.currentTimeMillis()
        return if (ms <= 0) 0 else ((ms + Dates.DAY - 1) / Dates.DAY).toInt()
    }

    // متن هشدار؛ null یعنی لازم نیست چیزی نشان داده شود
    fun message(c: Context): String? {
        val d = daysLeft(c) ?: return null
        return when {
            d == 0 -> "اشتراک جیب‌چک تمام شده است. برای ادامه، کد جدید بخر؛ تا آن موقع می‌توانی از تراکنش‌هایت خروجی CSV بگیری."
            !Activation.isActive(c) -> null   // کد لغو شده؛ پیام «نزدیک به پایان» معنی ندارد
            d == 1 -> "اشتراک جیب‌چک کمتر از ۲۴ ساعت دیگر تمام می‌شود."
            d <= WARN_DAYS -> "اشتراک جیب‌چک ${faNum(d)} روز دیگر تمام می‌شود."
            else -> null
        }
    }

    // اعلان؛ تا وقتی ${WARN_DAYS} روز به انقضا مانده حداکثر روزی یک بار، و بعد از تمام شدن فقط یک بار.
    // با باز شدن قفل گوشی، شروع سرویس و بوت صدا زده می‌شود.
    fun notifyIfDue(c: Context) {
        val msg = message(c) ?: return
        val d = daysLeft(c) ?: return
        val nm = c.getSystemService(NotificationManager::class.java) ?: return
        if (!nm.areNotificationsEnabled()) return   // اجازه‌ی اعلان نیست؛ بعداً دوباره تلاش می‌شود
        val sp = c.getSharedPreferences("license", Context.MODE_PRIVATE)
        val today = (System.currentTimeMillis() + TimeZone.getDefault().rawOffset) / Dates.DAY
        val key = if (d == 0) "end:" + Activation.expires(c) else "day:$today"
        if (sp.getString("warned", "") == key) return
        nm.createNotificationChannel(NotificationChannel(CH, "یادآوری پایان اشتراک", NotificationManager.IMPORTANCE_DEFAULT))
        val open = PendingIntent.getActivity(c, 7,
            Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(c, CH).setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("اشتراک جیب‌چک").setContentText(msg)
            .setStyle(Notification.BigTextStyle().bigText(msg))
            .setContentIntent(open).setAutoCancel(true).build()
        try { nm.notify(2, n); sp.edit().putString("warned", key).apply() } catch (_: Exception) {}
    }
}
