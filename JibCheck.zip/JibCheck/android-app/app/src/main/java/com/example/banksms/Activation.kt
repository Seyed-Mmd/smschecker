package com.example.banksms

import android.content.Context
import android.os.Build
import android.provider.Settings
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

// فعال‌سازی با کد خرید.
// ۱) اول صفحه‌ی استاتیک کد روی هاست بررسی می‌شود (ارزان؛ کدِ اشتباه هیچ‌وقت به پایگاه داده نمی‌رسد)
// ۲) بعد دستگاه روی سرور ثبت می‌شود (هر کد حداکثر روی دو دستگاه)
object Activation {
    class Res(val ok: Boolean, val msg: String)

    private fun sp(c: Context) = c.getSharedPreferences("license", Context.MODE_PRIVATE)

    fun isActive(c: Context): Boolean {
        val s = sp(c)
        if (!s.getBoolean("active", false)) return false
        val exp = s.getLong("expires", 0L)
        return exp == 0L || exp * 1000 > System.currentTimeMillis()
    }
    fun code(c: Context): String = sp(c).getString("code", "") ?: ""
    fun expires(c: Context): Long = sp(c).getLong("expires", 0L)   // ثانیه؛ ۰ = بدون انقضا

    // کد را به شکل استاندارد JC-XXXX-XXXX-XXXX درمی‌آورد؛ اگر فرمتش غلط بود null
    fun canonical(input: String): String? {
        val s = Parser.norm(input).uppercase().filter { it.isLetterOrDigit() }
        if (s.length != 14 || !s.startsWith("JC")) return null
        return "JC-" + s.substring(2, 6) + "-" + s.substring(6, 10) + "-" + s.substring(10, 14)
    }

    private fun sha256(s: String) = MessageDigest.getInstance("SHA-256").digest(s.toByteArray())
        .joinToString("") { "%02x".format(it) }

    private fun deviceId(c: Context): String =
        sha256("jibcheck|" + Settings.Secure.getString(c.contentResolver, Settings.Secure.ANDROID_ID))

    // خروجی: کد وضعیت HTTP و متن پاسخ؛ null یعنی اینترنت/سرور در دسترس نیست
    private fun http(method: String, url: String, body: String? = null): Pair<Int, String>? = try {
        val con = URL(url).openConnection() as HttpURLConnection
        con.requestMethod = method; con.connectTimeout = 10_000; con.readTimeout = 12_000
        con.setRequestProperty("Accept", "application/json")
        con.setRequestProperty("User-Agent", "JibCheck-Android")
        if (body != null) {
            con.doOutput = true; con.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            con.outputStream.use { it.write(body.toByteArray()) }
        }
        val code = con.responseCode
        val txt = (if (code in 200..299) con.inputStream else con.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
        con.disconnect()
        Pair(code, txt)
    } catch (e: Exception) { null }

    private fun pageUrl(code: String) = Config.CODE_PAGE_DIR + "/" + sha256(code) + ".json"

    private const val NO_NET = "اتصال به اینترنت یا سرور برقرار نشد. اینترنتت را بررسی کن و دوباره امتحان کن."

    // وضعیت صفحه‌ی استاتیک: null = خطای شبکه
    private fun checkPage(code: String): Res? {
        val r = http("GET", pageUrl(code)) ?: return null
        if (r.first == 404) return Res(false, "این کد وجود ندارد. کد را دوباره و با دقت وارد کن.")
        if (r.first != 200) return null
        val j = try { JSONObject(r.second) } catch (e: Exception) { return null }
        if (!j.optBoolean("ok", false)) return Res(false, "این کد لغو شده است. برای پیگیری از بخش پشتیبانی تیکت بفرست.")
        val exp = j.optLong("expires", 0L)
        if (exp != 0L && exp * 1000 <= System.currentTimeMillis()) return Res(false, "اعتبار این کد تمام شده است. برای تمدید، از سایت کد جدید بخر.")
        return Res(true, exp.toString())
    }

    fun activate(c: Context, input: String, cb: (Res) -> Unit) {
        val code = canonical(input)
        if (code == null) { cb(Res(false, "فرمت کد درست نیست. کد به شکل JC-XXXX-XXXX-XXXX است.")); return }
        val app = c.applicationContext
        Thread {
            val res: Res = run {
                val page = checkPage(code) ?: return@run Res(false, NO_NET)
                if (!page.ok) return@run page
                val body = JSONObject().put("code", code).put("device", deviceId(app))
                    .put("name", (Build.MANUFACTURER + " " + Build.MODEL).take(60)).toString()
                val r = http("POST", Config.ACTIVATE_API, body) ?: return@run Res(false, NO_NET)
                val j = try { JSONObject(r.second) } catch (e: Exception) { return@run Res(false, "پاسخ سرور نامعتبر بود. چند دقیقه بعد دوباره امتحان کن.") }
                if (j.optBoolean("ok", false)) {
                    sp(app).edit().putBoolean("active", true).putString("code", code)
                        .putLong("expires", j.optLong("expires", 0L)).putLong("checked", System.currentTimeMillis()).apply()
                    Res(true, "برنامه فعال شد.")
                } else Res(false, when (j.optString("error")) {
                    "limit" -> "ظرفیت فعال‌سازی این کد تمام شده است. هر کد حداکثر روی دو گوشی فعال می‌شود."
                    "revoked" -> "این کد لغو شده است. برای پیگیری از بخش پشتیبانی تیکت بفرست."
                    "expired" -> "اعتبار این کد تمام شده است."
                    "rate" -> "تعداد تلاش‌ها زیاد بود. یک ساعت بعد دوباره امتحان کن."
                    "invalid" -> "این کد وجود ندارد. کد را دوباره و با دقت وارد کن."
                    else -> "فعال‌سازی انجام نشد. دوباره امتحان کن."
                })
            }
            android.os.Handler(android.os.Looper.getMainLooper()).post { cb(res) }
        }.start()
    }

    fun deactivate(c: Context) { sp(c).edit().putBoolean("active", false).apply() }

    // حداکثر روزی یک بار صفحه‌ی کد را دوباره می‌خواند؛ اگر لغو یا منقضی شده بود برنامه قفل می‌شود.
    // اگر اینترنت نبود هیچ اتفاقی نمی‌افتد.
    fun recheckIfDue(c: Context, onLocked: (String) -> Unit) {
        val s = sp(c)
        if (!s.getBoolean("active", false)) return
        if (System.currentTimeMillis() - s.getLong("checked", 0L) < Config.CHECK_EVERY_MS) return
        val app = c.applicationContext; val code = code(app)
        Thread {
            val r = checkPage(code) ?: return@Thread
            android.os.Handler(android.os.Looper.getMainLooper()).post {
                if (r.ok) sp(app).edit().putLong("checked", System.currentTimeMillis()).putLong("expires", r.msg.toLongOrNull() ?: 0L).apply()
                else { deactivate(app); onLocked(r.msg) }
            }
        }.start()
    }
}
