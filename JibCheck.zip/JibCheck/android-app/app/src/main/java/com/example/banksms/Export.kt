package com.example.banksms

import android.app.Activity
import android.content.Context
import android.content.Intent

// خروجی CSV از همه‌ی تراکنش‌های ثبت‌شده (قابل چسباندن در اکسل).
// هم در «تنظیمات» و کارت هشدار صفحه‌ی خانه استفاده می‌شود، هم در صفحه‌ی فعال‌سازی (بعد از پایان اشتراک).
object Export {
    private fun csv(s: String) = "\"" + s.replace("\"", "\"\"") + "\""

    fun count(c: Context): Int = Db(c).done().size

    fun csvText(db: Db): String {
        val sb = StringBuilder("date,type,amount_toman,category,bank,description\n")
        db.done().sortedBy { it.time }.forEach { t ->
            sb.append("${Dates.fmtDay(t.time)},${Parser.label(t.type)},${t.amount},${csv(t.cat)},${csv(t.bank)},${csv(t.desc.ifEmpty { t.merchant })}\n")
        }
        return sb.toString()
    }

    fun share(c: Context, text: String) {
        val i = Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"; putExtra(Intent.EXTRA_TEXT, text)
        }, null)
        if (c !is Activity) i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        c.startActivity(i)
    }
}
