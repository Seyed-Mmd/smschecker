package com.example.banksms

import android.Manifest
import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView

private const val WHY_SMS = "برای ثبت خودکار تراکنش‌ها، جیب‌چک پیامک‌های بانکی که به گوشی‌ات می‌رسند را می‌خواند. فقط پیامک‌هایی که شبیه تراکنش بانکی باشند پردازش می‌شوند و پیامک‌های دیگر ذخیره نمی‌شوند. همه اطلاعات فقط روی همین گوشی می‌ماند."

// راهنمای قدم‌به‌قدم مجوزها: پیامک، اعلان، نمایش روی برنامه‌ها، باتری و شروع خودکار
class PermissionsActivity : Activity() {
    private class Item(val title: String, val why: String, val required: Boolean, val btn: String,
                       val ok: () -> Boolean, val action: () -> Unit, val manualKey: String? = null)

    private val sp by lazy { getSharedPreferences("prefs", MODE_PRIVATE) }
    private val fromSettings get() = intent.getBooleanExtra("fromSettings", false)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (!Activation.isActive(this)) { startActivity(Intent(this, ActivationActivity::class.java)); finish(); return }
        C.load(this); C.style(window)
    }

    override fun onResume() { super.onResume(); if (Activation.isActive(this)) render() }

    private fun smsOk() = checkSelfPermission(Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_GRANTED
    private fun notifOk() = Build.VERSION.SDK_INT < 33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
    private fun overlayOk() = Settings.canDrawOverlays(this)
    private fun batteryOk() = getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(packageName)

    private fun appDetails() = startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))

    // درخواست مجوز؛ اگر قبلاً رد شده و سیستم دیگر دیالوگ نشان نمی‌دهد، به تنظیمات برنامه می‌رویم
    private fun ask(perm: String, key: String) {
        if (sp.getBoolean(key, false) && !shouldShowRequestPermissionRationale(perm)) { appDetails(); return }
        sp.edit().putBoolean(key, true).apply()
        requestPermissions(arrayOf(perm), 1)
    }

    private fun autostart() {
        val tries = listOf(
            "com.miui.securitycenter" to "com.miui.permcenter.autostart.AutoStartManagementActivity",
            "com.huawei.systemmanager" to "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity",
            "com.coloros.safecenter" to "com.coloros.safecenter.permission.startup.StartupAppListActivity",
            "com.oppo.safe" to "com.oppo.safe.permission.startup.StartupAppListActivity",
            "com.vivo.permissionmanager" to "com.vivo.permissionmanager.activity.BgStartUpManagerActivity",
            "com.samsung.android.lool" to "com.samsung.android.sm.ui.battery.BatteryActivity"
        )
        for ((pkg, cls) in tries) {
            try { startActivity(Intent().setComponent(ComponentName(pkg, cls))); return } catch (_: Exception) {}
        }
        appDetails()
    }

    private fun items(): List<Item> = buildList {
        add(Item("۱) دریافت پیامک", WHY_SMS, true, "اجازه دریافت پیامک", { smsOk() }, { ask(Manifest.permission.RECEIVE_SMS, "asked_sms") }))
        add(Item("۲) نمایش روی برنامه‌ها",
            "بعد از باز کردن قفل گوشی، پنجره‌ی کوچک «این تراکنش چی بود؟» روی هر برنامه‌ای که باز است نشان داده می‌شود. بدون این اجازه پنجره‌ی ثبت خودکار باز نمی‌شود.",
            true, "باز کردن تنظیمات", { overlayOk() },
            { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) }))
        add(Item("۳) بدون محدودیت باتری",
            "بعضی گوشی‌ها برای صرفه‌جویی در باتری برنامه‌های پس‌زمینه را می‌بندند و جیب‌چک پیامک بانک را از دست می‌دهد. «اجازه بده» را بزن تا برنامه همیشه آماده بماند.",
            true, "اجازه بده", { batteryOk() }, {
                try { startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))) }
                catch (_: Exception) { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
            }))
        if (Build.VERSION.SDK_INT >= 33) add(Item("۴) اعلان‌ها",
            "جیب‌چک برای زنده ماندن در پس‌زمینه یک اعلان کوچک و بی‌صدا نشان می‌دهد. بدون اجازه‌ی اعلان، ممکن است سیستم آن را زودتر ببندد.",
            false, "اجازه اعلان", { notifOk() }, { ask(Manifest.permission.POST_NOTIFICATIONS, "asked_notif") }))
        add(Item("۵) شروع خودکار بعد از روشن شدن گوشی",
            "در گوشی‌های شیائومی، سامسونگ، هوآوی، اوپو و ویوو، «شروع خودکار» (Autostart) یا «اجرا در پس‌زمینه» را برای جیب‌چک روشن کن. بعد از انجام، دکمه‌ی «انجام دادم» را بزن.",
            false, "باز کردن تنظیمات", { sp.getBoolean("auto_ok", false) }, { autostart() }, "auto_ok"))
        add(Item("۶) اجازه‌ی تنظیمات محدودشده",
            "اگر برنامه را از بیرون فروشگاه نصب کرده‌ای و گزینه‌ی پیامک خاکستری یا غیرفعال بود: «تنظیمات برنامه» ← سه‌نقطه‌ی بالا ← «Allow restricted settings» را بزن و دوباره اجازه‌ی پیامک را بده. اگر مشکلی نداشتی، «انجام دادم» را بزن.",
            false, "باز کردن تنظیمات برنامه", { sp.getBoolean("restricted_ok", false) }, { appDetails() }, "restricted_ok"))
    }

    private fun render() {
        val list = items()
        val p = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(16), dp(20), dp(16), dp(32))
        }
        p.put(tv(if (fromSettings) "مجوزهای برنامه" else "آماده‌سازی جیب‌چک", 22f, C.text, true))
        p.put(tv("برای اینکه ثبت خودکار تراکنش‌ها بدون مشکل کار کند، این مجوزها لازم است. هر مورد را بزن و اجازه بده؛ وضعیت هر مورد همین‌جا نشان داده می‌شود.", 13f, C.muted).apply { setLineSpacing(0f, 1.25f) }, 6)
        val done = list.count { it.ok() }
        p.put(tv("$done از ${list.size} مورد انجام شده", 13f, C.primary, true), 10)

        list.forEach { it ->
            val ok = it.ok()
            val c = card()
            val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
            head.put(tv(it.title, 16f, C.text, true), 0, 0, 1f)
            head.put(tv(if (ok) "✓ انجام شد" else if (it.required) "لازم" else "پیشنهادی", 12f, if (ok) C.green else if (it.required) C.red else C.muted, true), 0, -2)
            c.put(head)
            c.put(tv(it.why, 13f, C.muted).apply { setLineSpacing(0f, 1.25f) }, 6)
            if (!ok || it.manualKey != null) {
                val row = LinearLayout(this)
                if (!ok) row.put(pill(it.btn) { it.action() }, 0, 0, 1f)
                if (it.manualKey != null) {
                    val k = it.manualKey!!
                    val on = sp.getBoolean(k, false)
                    row.put(pill(if (on) "برگردان به انجام‌نشده" else "انجام دادم", C.chipBg, C.text) {
                        sp.edit().putBoolean(k, !on).apply(); render()
                    }, 0, 0, 1f, if (!ok) 8 else 0)
                }
                c.put(row, 10)
            }
            p.put(c, 12)
        }

        val next = pill(if (fromSettings) "بازگشت" else "ادامه و ورود به برنامه") {
            val missing = list.filter { it.required && !it.ok() }
            if (fromSettings || missing.isEmpty()) finishSetup()
            else confirm("این مجوزها هنوز داده نشده:\n• " + missing.joinToString("\n• ") { it.title.substringAfter(") ") } +
                "\n\nبدون آن‌ها ثبت خودکار تراکنش‌ها درست کار نمی‌کند. با این حال ادامه بدهم؟") { finishSetup() }
        }
        p.put(next, 20)
        if (!fromSettings) p.put(tv("هر وقت خواستی از «تنظیمات ← مجوزهای برنامه» می‌توانی دوباره این صفحه را ببینی.", 12f, C.muted).apply { gravity = Gravity.CENTER }, 10)

        setContentView(screen(ScrollView(this).apply { setBackgroundColor(C.scrollBg); isFillViewport = true; addView(centered(p)) }))
    }

    private fun finishSetup() {
        sp.edit().putBoolean("setup_done", true).apply()
        Launcher.startService(this)
        if (!fromSettings) startActivity(Intent(this, MainActivity::class.java))
        finish()
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        render()
    }
}
