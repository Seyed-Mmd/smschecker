package com.example.banksms

import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import android.animation.ValueAnimator
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.LayerDrawable
import android.graphics.drawable.StateListDrawable
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.graphics.drawable.GradientDrawable
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

object C {
    var dark = false
    var lite = false                       // حالت سبک برای گوشی‌های ضعیف (بدون شیشه و انیمیشن)
    var stroke = Color.parseColor("#B8C2E0")   // رنگ لبه‌ی کادرهای ورودی
    var scrollBg = Color.TRANSPARENT           // پس‌زمینه‌ی ScrollView (در حالت شیشه‌ای شفاف)
    var bg = Color.parseColor("#F3F5FA")
    var card = Color.WHITE
    var primary = Color.parseColor("#4263EB")
    var hdrA = Color.parseColor("#4263EB")
    var hdrB = Color.parseColor("#7048E8")
    var green = Color.parseColor("#12B76A")
    var red = Color.parseColor("#F04438")
    var redBg = Color.parseColor("#FEE4E2")
    var text = Color.parseColor("#101828")
    var muted = Color.parseColor("#667085")
    var chipBg = Color.parseColor("#EEF1F6")
    var input = Color.parseColor("#F2F4F7")
    val palette = intArrayOf(
        Color.parseColor("#4263EB"), Color.parseColor("#12B76A"), Color.parseColor("#F79009"),
        Color.parseColor("#7048E8"), Color.parseColor("#F04438"), Color.parseColor("#0BA5EC"), Color.parseColor("#EE46BC")
    )

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("prefs", Context.MODE_PRIVATE)
    // 0 = خودکار (سیستم)، 1 = روشن، 2 = تاریک
    fun mode(ctx: Context): Int = prefs(ctx).getInt("theme", 0)
    fun setMode(ctx: Context, m: Int) { prefs(ctx).edit().putInt("theme", m).apply() }

    // اگر کاربر چیزی انتخاب نکرده باشد، روی گوشی‌های کم‌حافظه خودکار «سبک» می‌شود
    fun liteMode(ctx: Context): Boolean {
        val p = prefs(ctx)
        if (p.contains("lite")) return p.getBoolean("lite", false)
        return try { ctx.getSystemService(android.app.ActivityManager::class.java)?.isLowRamDevice == true } catch (_: Exception) { false }
    }
    fun setLite(ctx: Context, v: Boolean) { prefs(ctx).edit().putBoolean("lite", v).apply() }

    fun load(ctx: Context) {
        val sys = (ctx.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        val m = mode(ctx)
        dark = if (m == 0) sys else m == 2
        lite = liteMode(ctx)
        if (dark) {
            bg = Color.parseColor("#0E1117"); card = Color.parseColor("#1A1F2B"); primary = Color.parseColor("#5B7BFF")
            hdrA = Color.parseColor("#3B54C9"); hdrB = Color.parseColor("#5B3DB8")
            green = Color.parseColor("#32D583"); red = Color.parseColor("#F97066"); redBg = Color.parseColor("#4A1D1D")
            text = Color.parseColor("#F2F4F7"); muted = Color.parseColor("#98A2B3")
            chipBg = Color.parseColor("#2A3140"); input = Color.parseColor("#252C3A")
            stroke = Color.argb(0x66, 255, 255, 255)
        } else {
            bg = Color.parseColor("#F3F5FA"); card = Color.WHITE; primary = Color.parseColor("#4263EB")
            hdrA = Color.parseColor("#4263EB"); hdrB = Color.parseColor("#7048E8")
            green = Color.parseColor("#12B76A"); red = Color.parseColor("#F04438"); redBg = Color.parseColor("#FEE4E2")
            text = Color.parseColor("#101828"); muted = Color.parseColor("#667085")
            chipBg = Color.parseColor("#EEF1F6"); input = Color.parseColor("#F2F4F7")
            stroke = Color.parseColor("#9AA8D6")
        }
        scrollBg = if (lite) bg else Color.TRANSPARENT
    }

    // رنگ نوار وضعیت و نوار پایین سیستم
    fun style(w: Window) {
        w.statusBarColor = bg
        w.navigationBarColor = if (lite) card else bg
        var f = w.decorView.systemUiVisibility
        f = if (dark) f and View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR.inv() and View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR.inv()
        else f or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        w.decorView.systemUiVisibility = f
    }
}

// فونت برنامه: SF Arabic برای فارسی/عربی + Inter برای لاتین (معمولی / ضخیم)
fun Context.appFont(bold: Boolean = false): Typeface =
    try { Typeface.create(resources.getFont(R.font.jibsans), if (bold) Typeface.BOLD else Typeface.NORMAL) }
    catch (_: Exception) { Typeface.defaultFromStyle(if (bold) Typeface.BOLD else Typeface.NORMAL) }

// انیمیشن ساده فشردن: دکمه هنگام لمس کمی کوچک می‌شود
@android.annotation.SuppressLint("ClickableViewAccessibility")
fun <T : View> T.pressable(): T {
    if (C.lite) return this
    setOnTouchListener { v, e ->
        when (e.actionMasked) {
            android.view.MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.96f).scaleY(0.96f).setDuration(80).start()
            android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_CANCEL ->
                v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
        }
        false
    }
    return this
}

// ظاهر شدن نرم یک صفحه (محو شدن + کمی حرکت از پایین)
fun View.fadeIn(ms: Long = 220) {
    if (C.lite) return
    alpha = 0f; translationY = 12f * resources.displayMetrics.density
    animate().alpha(1f).translationY(0f).setDuration(ms).setInterpolator(android.view.animation.DecelerateInterpolator()).start()
}

fun Context.dp(x: Int): Int = (x * resources.displayMetrics.density).toInt()

fun Context.shape(color: Int, r: Int): GradientDrawable = GradientDrawable().apply {
    setColor(color); cornerRadius = dp(r).toFloat()
}

fun Context.tv(s: String, size: Float = 15f, color: Int = C.text, bold: Boolean = false): TextView = TextView(this).apply {
    text = s; textSize = size; setTextColor(color)
    typeface = appFont(bold)
}

// ═════════════ سیستم شیشه‌ای (Liquid Glass) ═════════════
// اندروید برای View معمولی «محو کردن پس‌زمینه» ندارد؛ پس شیشه با این ترکیب ساخته می‌شود:
// پس‌زمینه‌ی رنگی با نورهای نرم و متحرک + سطح نیمه‌شفاف + لبه‌ی درخشان + بازتاب نور بالای هر دکمه.
private fun argb(a: Int, rgb: Int) = (a shl 24) or (rgb and 0x00FFFFFF)

// سطح ۰ = ملایم (چیپ)، ۱ = کارت، ۲ = پررنگ (نوار پایین/پاپ‌آپ)، ۳ = تقریباً مات (پاپ‌آپ بدون بلور)
fun Context.glass(r: Int, level: Int = 1): Drawable {
    if (C.lite) return shape(if (level == 0) C.chipBg else C.card, r)
    val tops = if (C.dark) intArrayOf(0x24, 0x2E, 0x45, 0xF2) else intArrayOf(0x8C, 0xA6, 0xC8, 0xF4)
    val bots = if (C.dark) intArrayOf(0x10, 0x14, 0x24, 0xE8) else intArrayOf(0x5A, 0x70, 0x99, 0xE8)
    val rgb = if (C.dark && level == 3) 0x1A1F2B else 0xFFFFFF
    val rr = dp(r).toFloat()
    val border = GradientDrawable(
        GradientDrawable.Orientation.TL_BR,
        if (C.dark) intArrayOf(Color.argb(0x8C, 255, 255, 255), Color.argb(0x14, 255, 255, 255))
        else intArrayOf(Color.argb(0xFF, 255, 255, 255), Color.argb(0x8C, 160, 176, 235))
    ).apply { cornerRadius = rr }
    val fill = GradientDrawable(
        GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(argb(tops[level], rgb), argb(bots[level], rgb))
    ).apply { cornerRadius = (rr - dp(1)).coerceAtLeast(0f) }
    return LayerDrawable(arrayOf(border, fill)).apply { val i = dp(1); setLayerInset(1, i, i, i, i) }
}

// جعبه‌ی رنگی نیمه‌شفاف با لبه (برای هشدارها و دکمه‌های قرمز)
fun Context.tintBox(fill: Int, fa: Int, stroke: Int, sa: Int, r: Int): Drawable {
    if (C.lite) return shape(fill, r)
    return GradientDrawable().apply {
        setColor(argb(fa, fill)); cornerRadius = dp(r).toFloat()
        if (sa > 0) setStroke(dp(1), argb(sa, stroke))
    }
}

fun Context.trackBg(): Drawable = if (C.lite) shape(C.chipBg, 4) else tintBox(C.muted, 0x33, 0, 0, 4)

// دکمه‌ی اصلی: گرادیان رنگی + بازتاب نور بالا + حلقه‌ی سفید
fun Context.primaryGlass(r: Int, gloss: Int = 20): Drawable {
    if (C.lite) return shape(C.primary, r)
    val rr = dp(r).toFloat()
    val base = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(C.primary, C.hdrB)).apply { cornerRadius = rr }
    val shine = GradientDrawable(
        GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Color.argb(0x66, 255, 255, 255), Color.argb(0, 255, 255, 255))
    ).apply { cornerRadii = floatArrayOf(rr, rr, rr, rr, 0f, 0f, 0f, 0f) }
    val ring = GradientDrawable().apply { setColor(0); setStroke(dp(1), Color.argb(0x80, 255, 255, 255)); cornerRadius = rr }
    return LayerDrawable(arrayOf(base, shine, ring)).apply {
        setLayerInset(1, dp(1), dp(1), dp(1), 0); setLayerGravity(1, Gravity.TOP); setLayerHeight(1, dp(gloss))
    }
}

// کارت بزرگ بالای صفحه‌ی خانه
fun Context.heroBg(r: Int): Drawable {
    val rr = dp(r).toFloat()
    val base = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(C.hdrA, C.hdrB)).apply { cornerRadius = rr }
    if (C.lite) return base
    val shine = GradientDrawable(
        GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Color.argb(0x4D, 255, 255, 255), Color.argb(0, 255, 255, 255))
    ).apply { cornerRadii = floatArrayOf(rr, rr, rr, rr, 0f, 0f, 0f, 0f) }
    val ring = GradientDrawable().apply { setColor(0); setStroke(dp(1), Color.argb(0x73, 255, 255, 255)); cornerRadius = rr }
    return LayerDrawable(arrayOf(base, shine, ring)).apply {
        setLayerInset(1, dp(1), dp(1), dp(1), 0); setLayerGravity(1, Gravity.TOP); setLayerHeight(1, dp(84))
    }
}

fun Context.fabBg(): Drawable {
    val base = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(C.primary, C.hdrB)).apply { shape = GradientDrawable.OVAL }
    if (C.lite) return GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(C.primary) }
    val ring = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0); setStroke(dp(2), Color.argb(0x99, 255, 255, 255)) }
    return LayerDrawable(arrayOf(base, ring))
}

// نوار «جزیره‌ای»: شیشه‌ی بسیار شفاف تا محتوای پشتش دیده شود، با لبه‌ی روشن و بازتاب نور
fun Context.islandGlass(r: Int): Drawable {
    val rr = dp(r).toFloat()
    val border = GradientDrawable(
        GradientDrawable.Orientation.TL_BR,
        if (C.dark) intArrayOf(Color.argb(0xA6, 255, 255, 255), Color.argb(0x26, 255, 255, 255), Color.argb(0x73, 255, 255, 255))
        else intArrayOf(Color.argb(0xFF, 255, 255, 255), Color.argb(0x99, 150, 168, 235), Color.argb(0xE6, 255, 255, 255))
    ).apply { cornerRadius = rr }
    val fill = GradientDrawable(
        GradientDrawable.Orientation.TOP_BOTTOM,
        if (C.dark) intArrayOf(Color.argb(0x33, 255, 255, 255), Color.argb(0x1A, 255, 255, 255))
        else intArrayOf(Color.argb(0x99, 255, 255, 255), Color.argb(0x66, 255, 255, 255))
    ).apply { cornerRadius = rr - dp(1) }
    val shine = GradientDrawable(
        GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Color.argb(if (C.dark) 0x38 else 0x66, 255, 255, 255), Color.argb(0, 255, 255, 255))
    ).apply { cornerRadii = floatArrayOf(rr, rr, rr, rr, 0f, 0f, 0f, 0f) }
    return LayerDrawable(arrayOf(border, fill, shine)).apply {
        val i = dp(1)
        setLayerInset(1, i, i, i, i)
        setLayerInset(2, i, i, i, 0); setLayerGravity(2, Gravity.TOP); setLayerHeight(2, dp(26))
    }
}

// «لایه‌ی شیشه‌ای دوم» که روی تب انتخاب‌شده می‌نشیند (مثل لنز شیشه‌ای iOS)
fun Context.lensGlass(r: Int): Drawable {
    val rr = dp(r).toFloat()
    val pr = Color.red(C.primary); val pg = Color.green(C.primary); val pb = Color.blue(C.primary)
    val border = GradientDrawable(
        GradientDrawable.Orientation.TL_BR,
        if (C.dark) intArrayOf(Color.argb(0xCC, 255, 255, 255), Color.argb(0x33, 255, 255, 255))
        else intArrayOf(Color.argb(0xFF, 255, 255, 255), Color.argb(0xA6, pr, pg, pb))
    ).apply { cornerRadius = rr }
    val fill = GradientDrawable(
        GradientDrawable.Orientation.TOP_BOTTOM,
        if (C.dark) intArrayOf(Color.argb(0x52, 255, 255, 255), Color.argb(0x26, 255, 255, 255))
        else intArrayOf(Color.argb(0xE6, 255, 255, 255), Color.argb(0x99, 255, 255, 255))
    ).apply { cornerRadius = rr - dp(1) }
    val tint = GradientDrawable().apply { setColor(Color.argb(if (C.dark) 0x38 else 0x26, pr, pg, pb)); cornerRadius = rr - dp(1) }
    val shine = GradientDrawable(
        GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Color.argb(0x80, 255, 255, 255), Color.argb(0, 255, 255, 255))
    ).apply { cornerRadii = floatArrayOf(rr, rr, rr, rr, 0f, 0f, 0f, 0f) }
    return LayerDrawable(arrayOf(border, fill, tint, shine)).apply {
        val i = dp(1)
        setLayerInset(1, i, i, i, i); setLayerInset(2, i, i, i, i)
        setLayerInset(3, i, i, i, 0); setLayerGravity(3, Gravity.TOP); setLayerHeight(3, dp(20))
    }
}

// پس‌زمینه‌ی صفحه: گرادیان + چهار «نور» نرم که آهسته شناورند (فقط در حالت کامل)
class GlassBg(c: Context) : View(c) {
    private val paints = Array(4) { Paint(Paint.ANTI_ALIAS_FLAG) }
    private val base = Paint()
    private val phase = floatArrayOf(0f, 1.7f, 3.1f, 4.6f)
    private val ax = floatArrayOf(0.15f, 0.88f, 0.25f, 0.80f)
    private val ay = floatArrayOf(0.20f, 0.34f, 0.70f, 0.90f)
    private var t = 0f
    private var anim: ValueAnimator? = null

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        if (w == 0 || h == 0) return
        val dk = C.dark
        base.shader = LinearGradient(0f, 0f, 0f, h.toFloat(),
            if (dk) intArrayOf(C.bg, Color.parseColor("#0A0F1F")) else intArrayOf(C.bg, Color.parseColor("#E6EBFB")), null, Shader.TileMode.CLAMP)
        val cols = if (dk) intArrayOf(Color.argb(0x73, 0x42, 0x63, 0xEB), Color.argb(0x66, 0x70, 0x48, 0xE8), Color.argb(0x40, 0xEE, 0x46, 0xBC), Color.argb(0x47, 0x0B, 0xA5, 0xEC))
        else intArrayOf(Color.argb(0x66, 0x42, 0x63, 0xEB), Color.argb(0x5A, 0x70, 0x48, 0xE8), Color.argb(0x45, 0xEE, 0x46, 0xBC), Color.argb(0x52, 0x0B, 0xA5, 0xEC))
        val rad = minOf(w, h) * 0.85f
        for (i in 0..3) paints[i].shader = RadialGradient(0f, 0f, rad, cols[i], cols[i] and 0x00FFFFFF, Shader.TileMode.CLAMP)
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        cv.drawRect(0f, 0f, w, h, base)
        val a = t * 6.2831855f
        val rad = minOf(w, h) * 0.85f
        for (i in 0..3) {
            val dx = (Math.sin((a + phase[i]).toDouble()) * w * 0.07).toFloat()
            val dy = (Math.cos((a * 1.0f + phase[i]).toDouble()) * h * 0.04).toFloat()
            cv.save(); cv.translate(w * ax[i] + dx, h * ay[i] + dy)
            cv.drawCircle(0f, 0f, rad, paints[i]); cv.restore()
        }
    }

    private fun go() {
        if (anim != null || C.lite) return
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 28000L; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
            addUpdateListener { t = it.animatedValue as Float; invalidate() }
            start()
        }
    }
    private fun stop() { anim?.cancel(); anim = null }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); go() }
    override fun onDetachedFromWindow() { stop(); super.onDetachedFromWindow() }
    override fun onWindowVisibilityChanged(v: Int) { super.onWindowVisibilityChanged(v); if (v == View.VISIBLE) go() else stop() }
}

// صفحه را روی پس‌زمینه‌ی شیشه‌ای می‌گذارد (در حالت سبک همان رنگ ساده)
fun Context.screen(content: View): View {
    if (C.lite) { content.setBackgroundColor(C.bg); return content }
    return FrameLayout(this).apply {
        addView(GlassBg(this@screen), FrameLayout.LayoutParams(-1, -1))
        addView(content, FrameLayout.LayoutParams(-1, -1))
    }
}

fun Context.card(pad: Int = 16): LinearLayout = LinearLayout(this).apply {
    orientation = LinearLayout.VERTICAL
    background = glass(20, 1)
    setPadding(dp(pad), dp(pad), dp(pad), dp(pad))
    elevation = if (C.lite) dp(2).toFloat() else 0f
}

fun Context.pill(s: String, bg: Int = C.primary, fg: Int = Color.WHITE, onClick: () -> Unit): TextView = TextView(this).apply {
    text = s; textSize = 15f; setTextColor(fg); typeface = appFont(true)
    gravity = Gravity.CENTER
    background = when {
        C.lite -> shape(bg, 24)
        bg == C.primary -> primaryGlass(24)
        bg == C.chipBg -> glass(24, 1)
        else -> tintBox(bg, 0xDD, fg, 0x73, 24)
    }
    setPadding(dp(18), dp(12), dp(18), dp(12))
    minimumHeight = dp(48)
    setOnClickListener { onClick() }
    pressable()
}

fun Context.chip(s: String, selected: Boolean, onClick: () -> Unit): TextView = TextView(this).apply {
    text = s; textSize = 13f; typeface = appFont(selected)
    setTextColor(if (selected) Color.WHITE else C.text)
    background = if (selected) primaryGlass(20, 14) else glass(20, 0)
    setPadding(dp(14), dp(10), dp(14), dp(10))
    minimumHeight = dp(40); gravity = Gravity.CENTER_VERTICAL
    setOnClickListener { onClick() }
    pressable()
}

// پس‌زمینه‌ی کادر ورودی: همیشه یک خط دور دارد؛ با فوکوس، خط رنگی و ضخیم‌تر می‌شود
fun Context.fieldBg(): Drawable {
    fun box(color: Int, w: Int) = GradientDrawable().apply {
        setColor(if (C.lite) C.input else if (C.dark) Color.argb(0x33, 0, 0, 0) else Color.argb(0xB8, 255, 255, 255))
        cornerRadius = dp(14).toFloat(); setStroke(w, color)
    }
    return StateListDrawable().apply {
        addState(intArrayOf(android.R.attr.state_focused), box(C.primary, dp(2)))
        addState(intArrayOf(), box(C.stroke, maxOf(dp(1), 2)))
    }
}

fun Context.field(hint: String, value: String = "", number: Boolean = false): EditText = EditText(this).apply {
    this.hint = hint; setText(value); textSize = 15f; typeface = appFont(false)
    setTextColor(C.text); setHintTextColor(C.muted)
    background = fieldBg()
    setPadding(dp(14), dp(12), dp(14), dp(12))
    if (number) inputType = InputType.TYPE_CLASS_NUMBER
}

// جعبه‌ی جست‌وجو: خط دور رنگی و پررنگ + آیکن ذره‌بین + دکمه‌ی پاک‌کردن + درخشش هنگام فوکوس
fun Context.searchBox(hint: String, value: String = ""): Pair<View, EditText> {
    fun bg(focused: Boolean): Drawable {
        val glow = GradientDrawable().apply {
            cornerRadius = dp(19).toFloat(); setColor(0)
            if (focused) setStroke(dp(3), Color.argb(0x4D, Color.red(C.primary), Color.green(C.primary), Color.blue(C.primary)))
        }
        val main = GradientDrawable().apply {
            cornerRadius = dp(16).toFloat()
            setColor(if (C.lite) C.input else if (C.dark) Color.argb(0x40, 0, 0, 0) else Color.argb(0xD0, 255, 255, 255))
            setStroke(dp(2), if (focused) C.primary else Color.argb(0xB3, Color.red(C.primary), Color.green(C.primary), Color.blue(C.primary)))
        }
        return LayerDrawable(arrayOf(glow, main)).apply { val i = dp(3); setLayerInset(1, i, i, i, i) }
    }
    val et = EditText(this).apply {
        this.hint = hint; setText(value); textSize = 15f; typeface = appFont(false)
        setTextColor(C.text); setHintTextColor(C.muted); background = null
        setPadding(dp(8), dp(12), dp(8), dp(12)); isSingleLine = true
        imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH
    }
    val box = LinearLayout(this).apply {
        gravity = Gravity.CENTER_VERTICAL; setPadding(dp(17), dp(3), dp(11), dp(3)); background = bg(false)
    }
    box.put(tv("🔍", 16f))
    box.put(et, 0, 0, 1f, 6)
    val clear = tv("✕", 15f, C.muted, true).apply {
        setPadding(dp(8), dp(6), dp(8), dp(6)); visibility = if (value.isEmpty()) View.GONE else View.VISIBLE
        setOnClickListener { et.setText("") }
    }
    box.put(clear)
    et.setOnFocusChangeListener { _, f -> box.background = bg(f) }
    et.onText { clear.visibility = if (it.isEmpty()) View.GONE else View.VISIBLE }
    return box to et
}

// افزودن view به LinearLayout با فاصله از بالا (dp)، عرض، وزن، فاصله شروع و ارتفاع
fun LinearLayout.put(v: View, top: Int = 0, w: Int = -1, weight: Float = 0f, start: Int = 0, h: Int = -2): View {
    val k = resources.displayMetrics.density
    val lp = LinearLayout.LayoutParams(w, if (h > 0) (h * k).toInt() else h, weight)
    lp.topMargin = (top * k).toInt()
    lp.marginStart = (start * k).toInt()
    addView(v, lp)
    return v
}

fun EditText.onText(f: (String) -> Unit) {
    addTextChangedListener(object : TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        override fun afterTextChanged(s: Editable?) { f(s.toString()) }
    })
}

// چیدمان «چندخطی» برای چیپ‌ها
class Flow(c: Context) : ViewGroup(c) {
    private val gap = (8 * c.resources.displayMetrics.density).toInt()

    override fun onMeasure(ws: Int, hs: Int) {
        val maxW = View.MeasureSpec.getSize(ws)
        var x = 0; var y = 0; var rowH = 0
        for (i in 0 until childCount) {
            val v = getChildAt(i)
            v.measure(
                View.MeasureSpec.makeMeasureSpec(maxW, View.MeasureSpec.AT_MOST),
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
            )
            if (x > 0 && x + v.measuredWidth > maxW) { x = 0; y += rowH + gap; rowH = 0 }
            x += v.measuredWidth + gap
            rowH = maxOf(rowH, v.measuredHeight)
        }
        setMeasuredDimension(maxW, y + rowH)
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val w = r - l
        val rtl = layoutDirection == View.LAYOUT_DIRECTION_RTL
        var x = 0; var y = 0; var rowH = 0
        for (i in 0 until childCount) {
            val v = getChildAt(i)
            val cw = v.measuredWidth; val chh = v.measuredHeight
            if (x > 0 && x + cw > w) { x = 0; y += rowH + gap; rowH = 0 }
            val left = if (rtl) w - x - cw else x
            v.layout(left, y, left + cw, y + chh)
            x += cw + gap
            rowH = maxOf(rowH, chh)
        }
    }
}

// متن تک‌خطی که برای جا شدن در عرض، خودکار کوچک می‌شود
fun TextView.fit(minSp: Int, maxSp: Int) {
    maxLines = 1
    setAutoSizeTextTypeUniformWithConfiguration(minSp, maxSp, 1, TypedValue.COMPLEX_UNIT_SP)
}

// نگه‌دارنده‌ای که فرزندش را با حداکثر عرض مشخص و دقیقاً وسط قرار می‌دهد.
// عرض را از خودِ پنجره می‌گیرد (نه از اندازه صفحه نمایش)، پس هیچ‌وقت کج یا بیرون‌زده نمی‌شود.
class MaxWidth(c: Context, private val maxPx: Int) : ViewGroup(c) {
    override fun onMeasure(ws: Int, hs: Int) {
        val mode = View.MeasureSpec.getMode(ws)
        val w = if (mode == View.MeasureSpec.UNSPECIFIED) maxPx else View.MeasureSpec.getSize(ws)
        val cw = minOf(w, maxPx)
        val v = getChildAt(0)
        if (v == null) { setMeasuredDimension(w, 0); return }
        v.measure(
            View.MeasureSpec.makeMeasureSpec(cw, View.MeasureSpec.EXACTLY),
            getChildMeasureSpec(hs, 0, v.layoutParams.height)
        )
        setMeasuredDimension(w, resolveSize(v.measuredHeight, hs))
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val v = getChildAt(0) ?: return
        val left = ((r - l) - v.measuredWidth) / 2
        v.layout(left, 0, left + v.measuredWidth, v.measuredHeight)
    }
}

// محتوا را وسط صفحه و با حداکثر عرض نگه می‌دارد (تبلت/حالت افقی)
fun Context.centered(content: View, maxDp: Int = 640): View =
    MaxWidth(this, dp(maxDp)).apply {
        addView(content, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    }

// بعد از ساخته‌شدن دوباره صفحه، اسکرول را به همان جای قبلی برمی‌گرداند
fun android.widget.ScrollView.restoreScroll(y: Int) {
    if (y <= 0) return
    viewTreeObserver.addOnPreDrawListener(object : android.view.ViewTreeObserver.OnPreDrawListener {
        override fun onPreDraw(): Boolean {
            viewTreeObserver.removeOnPreDrawListener(this)
            scrollTo(0, y)
            return true
        }
    })
}

// دیالوگ هماهنگ با تم روشن/تاریک
fun Context.dialog(): android.app.AlertDialog.Builder = android.app.AlertDialog.Builder(this,
    if (C.dark) R.style.DialogDark else R.style.DialogLight)

fun Context.confirm(msg: String, ok: () -> Unit) {
    dialog().setMessage(msg).setPositiveButton("بله") { _, _ -> ok() }.setNegativeButton("خیر", null).show()
}

fun Context.toast(s: String) = android.widget.Toast.makeText(this, s, android.widget.Toast.LENGTH_LONG).show()
