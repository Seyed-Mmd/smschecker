<?php
require dirname(__DIR__) . '/inc/bootstrap.php';
if (is_admin()) redirect(u('admin/'));
$err = ''; $ip = client_ip();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    if (rate_count("adminfail:$ip", 900) >= 8) $err = 'تلاش‌های ناموفق زیاد بود. ۱۵ دقیقه بعد دوباره امتحان کن.';
    else {
        $a = row('SELECT * FROM admins WHERE username=?', [post('username')]);
        if ($a && password_verify(post('password'), $a['pass_hash'])) {
            session_regenerate_id(true);
            $keep = $_SESSION; $_SESSION = ['csrf' => bin2hex(random_bytes(16)), 'aid' => (int) $a['id'], 'atime' => time()];
            if (!empty($keep['uid'])) $_SESSION['uid'] = $keep['uid'];
            redirect(u('admin/'));
        }
        rate_hit("adminfail:$ip");
        $err = 'نام کاربری یا رمز عبور اشتباه است.';
    }
}
page_head('ورود مدیریت', ['admin' => 1]);
?>
<div class="card narrow">
  <h2>ورود به پنل مدیریت</h2>
  <?php if ($err): ?><div class="alert bad"><?= e($err) ?></div><?php endif; ?>
  <form method="post"><?= csrf_field() ?>
    <label>نام کاربری</label><input type="text" name="username" class="ltr" autocomplete="username" required autofocus>
    <label>رمز عبور</label><input type="password" name="password" class="ltr" autocomplete="current-password" required>
    <p><button class="btn btn-wide" type="submit">ورود</button></p>
  </form>
</div>
<?php page_foot(['admin' => 1]); ?>
