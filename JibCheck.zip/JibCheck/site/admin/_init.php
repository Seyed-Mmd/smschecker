<?php
require dirname(__DIR__) . '/inc/bootstrap.php';
if (!is_admin()) redirect(u('admin/login.php'));
$_SESSION['atime'] = time();   // با هر فعالیت، ۸ ساعت دیگر معتبر می‌ماند
