<?php
require __DIR__ . '/_init.php';
$secret = ['sms_api_key', 'zarinpal_merchant'];
$checks = ['pay_gateway_on', 'pay_card_on', 'admin_notify'];
$nums = ['price' => [1000, 100000000], 'license_days' => [0, 36500], 'max_uses' => [1, 20]];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $act = post('act');
    if ($act === 'save') {
        foreach (array_keys(setting_defaults()) as $k) {
            if (in_array($k, $checks, true)) { set_setting($k, post($k) === '1' ? '1' : '0'); continue; }
            if (isset($nums[$k])) { set_setting($k, (string) max($nums[$k][0], min($nums[$k][1], (int) en_digits(post($k))))); continue; }
            if (in_array($k, $secret, true) && post($k) === '') continue;   // خالی = بدون تغییر
            $v = trim((string) ($_POST[$k] ?? ''));
            if (in_array($k, ['card_number', 'admin_phone', 'sms_line'], true) || str_starts_with($k, 'sms_tpl_')) $v = preg_replace('/\D/', '', en_digits($v));
            set_setting($k, mb_substr($v, 0, 1000));
        }
        flash('تنظیمات ذخیره شد.', 'ok');
    } elseif ($act === 'test_sms') {
        $m = norm_mobile(setting('admin_phone'));
        if (!$m) flash('اول شماره موبایل ادمین را ذخیره کن.', 'bad');
        else { $ok = sms_send('otp', $m, '12345'); flash($ok ? 'پیامک آزمایشی ارسال شد.' : 'ارسال پیامک ناموفق بود. کلید API، خط یا قالب را بررسی کن (جزئیات در storage/app.log).', $ok ? 'ok' : 'bad'); }
    } elseif ($act === 'pass') {
        $a = row('SELECT * FROM admins WHERE id=?', [(int) $_SESSION['aid']]);
        if (!$a || !password_verify(post('cur'), $a['pass_hash'])) flash('رمز فعلی اشتباه است.', 'bad');
        elseif (strlen(post('new')) < 8) flash('رمز جدید باید حداقل ۸ کاراکتر باشد.', 'bad');
        elseif (post('new') !== post('new2')) flash('تکرار رمز جدید یکسان نیست.', 'bad');
        else { update('admins', ['pass_hash' => password_hash(post('new'), PASSWORD_DEFAULT)], 'id=?', [$a['id']]); flash('رمز عبور تغییر کرد.', 'ok'); }
    }
    redirect(u('admin/settings.php'));
}
$S = settings_all();
function fld(string $k, string $label, string $hint = '', string $type = 'text', bool $ltr = false): void {
    global $S;
    echo '<label>' . e($label) . '</label><input type="' . $type . '" name="' . e($k) . '" value="' . e(in_array($k, ['sms_api_key', 'zarinpal_merchant'], true) ? '' : ($S[$k] ?? '')) . '"'
        . ($ltr ? ' class="ltr"' : '') . (in_array($k, ['sms_api_key', 'zarinpal_merchant'], true) && ($S[$k] ?? '') !== '' ? ' placeholder="ثبت شده (برای تغییر، مقدار جدید را بنویس)"' : '') . '>';
    if ($hint) echo '<div class="hint">' . e($hint) . '</div>';
}
function chk(string $k, string $label): void { global $S; echo '<label class="check"><input type="checkbox" name="' . e($k) . '" value="1" ' . (($S[$k] ?? '') === '1' ? 'checked' : '') . '><span>' . e($label) . '</span></label>'; }
page_head('تنظیمات', ['admin' => 1]);
?>
<h2>تنظیمات</h2>
<form method="post"><?= csrf_field() ?><input type="hidden" name="act" value="save">
<div class="grid g2" style="align-items:start">
  <div>
    <div class="card"><h3>محصول و قیمت</h3>
      <?php fld('site_name', 'نام سایت'); fld('price', 'قیمت کد (تومان)', '', 'number'); fld('license_days', 'مدت اعتبار هر کد (روز)', 'عدد ۰ یعنی بدون انقضا. برای یک سال ۳۶۵ بنویس.', 'number');
            fld('max_uses', 'حداکثر تعداد فعال‌سازی هر کد (گوشی)', 'تغییر این مقدار فقط روی کدهای جدید اثر دارد.', 'number');
            fld('app_download_url', 'لینک دانلود برنامه', 'اختیاری؛ در پنل کاربر و صفحه‌ی خرید نمایش داده می‌شود.', 'url', true);
            echo '<label>یادداشت اضافه در صفحه‌ی خرید (اختیاری)</label><textarea name="buy_note" style="min-height:70px">' . e($S['buy_note']) . '</textarea>';
            echo '<label>متن راهنمای پشتیبانی</label><textarea name="support_note" style="min-height:70px">' . e($S['support_note']) . '</textarea>'; ?>
    </div>
    <div class="card"><h3>روش‌های پرداخت</h3>
      <?php chk('pay_gateway_on', 'پرداخت با درگاه (زرین‌پال) فعال باشد'); fld('zarinpal_merchant', 'مرچنت‌کد زرین‌پال', 'کد ۳۶ کاراکتری درگاه. آدرس بازگشت: ' . site_url('callback.php'), 'text', true);
            echo '<hr style="border:0;border-top:1px solid var(--ln);margin:18px 0">';
            chk('pay_card_on', 'پرداخت کارت‌به‌کارت فعال باشد'); fld('card_number', 'شماره کارت (۱۶ رقم)', '', 'text', true); fld('card_holder', 'نام صاحب کارت'); fld('card_bank', 'نام بانک'); ?>
    </div>
  </div>
  <div>
    <div class="card"><h3>پیامک (SMS.ir)</h3>
      <div class="alert info">
        <b>اگر SMS.ir می‌گوید «باید قالب تعریف کنی»:</b> یعنی خط شما برای ارسال پیامک آزاد (با متن دلخواه) تایید نشده، و باید برای هر نوع پیام یک «الگو» در پنل SMS.ir بسازی. مراحل کامل را پایین همین صفحه نوشته‌ام.
      </div>
      <?php fld('sms_api_key', 'کلید API', 'از پنل SMS.ir ← بخش توسعه‌دهندگان / API', 'password', true); fld('sms_line', 'شماره خط ارسال', 'فقط برای ارسال معمولی (پیام با متن آزاد) لازم است؛ اگر برای همه‌ی پیام‌ها پایین «شناسه قالب» بگذاری، دیگر لازم نیست.', 'text', true); ?>
      <p class="hint">برای هر نوع پیام زیر، یا «شناسه قالب» بگذار (توصیه می‌شود؛ نیازی به تاییدیه‌ی خط ندارد) یا متن آزاد بنویس (نیاز به خط تاییدشده دارد). اگر شناسه قالب بگذاری، همان اولویت دارد و متن آزاد نادیده گرفته می‌شود.</p>
      <?php foreach (sms_types() as $k => $t): ?>
        <details style="margin-top:10px"><summary><b><?= e($t['title']) ?></b> <span class="hint">— متغیر قالب: <code class="ltr" style="display:inline-block"><?= e($t['param']) ?></code></span></summary>
        <?php fld('sms_tpl_' . $k, 'شناسه قالب (Template ID)', 'عدد شناسه‌ای که بعد از تایید الگو در SMS.ir می‌گیری.', 'text', true);
              echo '<label>یا متن آزاد (فقط اگر خطت تاییدشده است؛ به‌جای {v} مقدار قرار می‌گیرد)</label><textarea name="sms_txt_' . e($k) . '" style="min-height:70px" placeholder="' . e($t['text']) . '">' . e($S['sms_txt_' . $k]) . '</textarea>'; ?></details>
      <?php endforeach; ?>
      <details style="margin-top:14px"><summary><b>راهنما: چطور در SMS.ir الگو (قالب) بسازم؟</b></summary>
        <ol style="padding-right:18px;color:var(--mu);font-size:.9rem;line-height:2">
          <li>وارد پنل کاربری‌ات در <a href="https://app.sms.ir" target="_blank" rel="noopener">app.sms.ir</a> شو.</li>
          <li>از منو برو به «سرویس‌های پیامکی» ← «ارسال سریع» (یا «وریفای / Verify») ← «مدیریت الگوها».</li>
          <li>«ایجاد الگوی جدید» را بزن. برای هر نوع پیام بالا یک الگوی جدا بساز.</li>
          <li>متن الگو را بنویس و دقیقاً همان متغیری که بالا نوشته شده (مثلاً <code>Code</code> برای کد ورود/فعال‌سازی، <code>Order</code> برای سفارش، <code>Ticket</code> برای تیکت) را با همان حروف بزرگ/کوچک و بین دو درصد بگذار؛ مثلاً: <code class="ltr" style="display:inline-block">کد ورود شما: %Code%</code>.</li>
          <li>الگو را ثبت کن. SMS.ir معمولاً طی چند دقیقه تا چند ساعت آن را بررسی و تایید می‌کند؛ وضعیتش در همان صفحه‌ی «مدیریت الگوها» دیده می‌شود.</li>
          <li>بعد از تایید، کنار الگو یک عدد «شناسه الگو» (Template ID) می‌بینی؛ همان عدد را در کادر «شناسه قالب» بالا، برای همان نوع پیام، وارد و ذخیره کن.</li>
          <li>با دکمه‌ی «ارسال پیامک آزمایشی» پایین همین صفحه تست کن.</li>
        </ol>
        <p class="hint">منوهای پنل SMS.ir گاهی کمی جابه‌جا می‌شوند؛ اگر دقیقاً همین اسم‌ها را ندیدی، دنبال «الگو»، «Pattern» یا «Verify» در منوی سرویس‌های پیامکی بگرد، یا از پشتیبانی خودِ SMS.ir بپرس.</p>
      </details>
    </div>
    <div class="card"><h3>اطلاع‌رسانی به ادمین</h3>
      <?php fld('admin_phone', 'شماره موبایل ادمین', 'پیامک «سفارش در انتظار تایید» و «تیکت جدید» به این شماره می‌رود.', 'tel', true); chk('admin_notify', 'ارسال پیامک اطلاع‌رسانی به ادمین فعال باشد'); ?>
    </div>
  </div>
</div>
<p><button class="btn" type="submit">ذخیره‌ی تنظیمات</button></p>
</form>
<div class="grid g2" style="align-items:start">
  <div class="card"><h3>آزمایش پیامک</h3><p class="muted">بعد از ذخیره‌ی تنظیمات، یک پیامک آزمایشی به شماره‌ی ادمین می‌فرستد.</p>
    <form method="post"><?= csrf_field() ?><input type="hidden" name="act" value="test_sms"><button class="btn btn-ghost" type="submit">ارسال پیامک آزمایشی</button></form></div>
  <div class="card"><h3>تغییر رمز عبور ادمین</h3>
    <form method="post"><?= csrf_field() ?><input type="hidden" name="act" value="pass">
      <label>رمز فعلی</label><input type="password" name="cur" class="ltr" required><label>رمز جدید (حداقل ۸ کاراکتر)</label><input type="password" name="new" class="ltr" required>
      <label>تکرار رمز جدید</label><input type="password" name="new2" class="ltr" required><p><button class="btn btn-ghost" type="submit">تغییر رمز</button></p></form></div>
</div>
<?php page_foot(['admin' => 1]); ?>
