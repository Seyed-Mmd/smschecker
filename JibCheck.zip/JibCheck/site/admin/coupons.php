<?php
require __DIR__ . '/_init.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $act = post('act');
    if ($act === 'add') {
        $code = coupon_norm(post('code'));
        if ($code === '') { $al = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789'; for ($i = 0; $i < 8; $i++) $code .= $al[random_int(0, strlen($al) - 1)]; }   // خالی = ساخت خودکار
        $kind = post('kind') === 'fixed' ? 'fixed' : 'percent';
        $value = (int) en_digits(post('value'));
        $max = max(0, min(1000000, (int) en_digits(post('max_uses'))));
        $perUser = max(0, min(1000, (int) en_digits(post('per_user_max', '1'))));
        $days = max(0, min(3650, (int) en_digits(post('days'))));
        if (strlen($code) < 3 || strlen($code) > 20) flash('طول کد باید ۳ تا ۲۰ حرف یا عدد انگلیسی باشد.', 'bad');
        elseif ($kind === 'percent' && ($value < 1 || $value > 100)) flash('درصد تخفیف باید بین ۱ تا ۱۰۰ باشد.', 'bad');
        elseif ($kind === 'fixed' && ($value < 1 || $value > 100000000)) flash('مبلغ تخفیف معتبر نیست.', 'bad');
        elseif (val('SELECT COUNT(*) FROM coupons WHERE code=?', [$code])) flash('این کد تخفیف قبلاً ثبت شده است.', 'bad');
        else {
            insert('coupons', ['code' => $code, 'kind' => $kind, 'value' => $value, 'max_uses' => $max, 'per_user_max' => $perUser,
                'expires_at' => $days > 0 ? time() + $days * 86400 : 0, 'active' => 1, 'created_at' => time()]);
            flash('کد تخفیف ' . $code . ' ساخته شد.', 'ok');
        }
    } else {
        $c = row('SELECT * FROM coupons WHERE id=?', [(int) post('id')]);
        if ($c) {
            if ($act === 'toggle') { update('coupons', ['active' => (int) $c['active'] ? 0 : 1], 'id=?', [$c['id']]); flash((int) $c['active'] ? 'کد تخفیف غیرفعال شد.' : 'کد تخفیف فعال شد.', 'ok'); }
            elseif ($act === 'setmax') { update('coupons', ['max_uses' => max(0, min(1000000, (int) en_digits(post('max_uses'))))], 'id=?', [$c['id']]); flash('سقف کلی تعداد استفاده تغییر کرد.', 'ok'); }
            elseif ($act === 'setperuser') { update('coupons', ['per_user_max' => max(0, min(1000, (int) en_digits(post('per_user_max'))))], 'id=?', [$c['id']]); flash('سقف استفاده‌ی هر کاربر تغییر کرد.', 'ok'); }
            elseif ($act === 'delete') {
                if (coupon_used((int) $c['id']) > 0) flash('این کد قبلاً استفاده شده؛ به‌جای حذف، آن را غیرفعال کن.', 'bad');
                else { q('DELETE FROM coupons WHERE id=?', [$c['id']]); flash('کد تخفیف حذف شد.', 'ok'); }
            }
        }
    }
    redirect(u('admin/coupons.php'));
}
$list = rows('SELECT * FROM coupons ORDER BY id DESC LIMIT 200');
page_head('کدهای تخفیف', ['admin' => 1]);
?>
<h2>کدهای تخفیف</h2>
<div class="card"><h3>ساخت کد تخفیف</h3>
  <form method="post"><?= csrf_field() ?><input type="hidden" name="act" value="add">
    <div class="grid g2" style="align-items:start">
      <div><label>کد (خالی = ساخت خودکار)</label><input type="text" name="code" class="ltr" maxlength="20" placeholder="مثلاً YALDA"></div>
      <div><label>نوع تخفیف</label><select name="kind"><option value="percent">درصدی</option><option value="fixed">مبلغ ثابت (تومان)</option></select></div>
      <div><label>مقدار</label><input type="number" name="value" min="1" required><div class="hint">برای درصدی ۱ تا ۱۰۰؛ برای مبلغ ثابت، تومان. اگر تخفیف قیمت را به صفر برساند، کد بدون پرداخت صادر می‌شود.</div></div>
      <div><label>سقف کلی تعداد استفاده</label><input type="number" name="max_uses" min="0" value="0"><div class="hint">۰ یعنی نامحدود (کل کاربران روی‌هم).</div></div>
      <div><label>سقف استفاده‌ی هر کاربر</label><input type="number" name="per_user_max" min="0" value="1"><div class="hint">۱ یعنی هر کاربر فقط یک‌بار؛ ۰ یعنی هر کاربر هر چند بار بخواهد.</div></div>
      <div><label>اعتبار (روز از همین الان)</label><input type="number" name="days" min="0" value="0"><div class="hint">۰ یعنی بدون انقضا.</div></div>
    </div>
    <p><button class="btn btn-sm" type="submit">ساخت کد تخفیف</button></p>
  </form></div>
<div class="card scroll">
<table class="tbl"><thead><tr><th>کد</th><th>تخفیف</th><th>وضعیت</th><th>استفاده (کل)</th><th>سقف هرکاربر</th><th>انقضا</th><th>عملیات</th></tr></thead><tbody>
<?php foreach ($list as $c): $st = coupon_state($c); $used = coupon_used((int) $c['id']); ?>
<tr><td class="ltr" style="font-family:monospace"><?= e($c['code']) ?></td>
<td><?= $c['kind'] === 'percent' ? e(fa((int) $c['value'])) . '٪' : toman($c['value']) ?></td>
<td><?= badge($st[0], $st[1]) ?></td>
<td><?= fa($used) ?> از <?= (int) $c['max_uses'] > 0 ? fa($c['max_uses']) : 'نامحدود' ?></td>
<td><?= (int) ($c['per_user_max'] ?? 1) > 0 ? fa((int) $c['per_user_max']) . ' بار' : 'نامحدود' ?></td>
<td><?= (int) $c['expires_at'] ? jdate((int) $c['expires_at']) : 'بدون انقضا' ?></td>
<td><div class="row">
  <form method="post"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $c['id'] ?>"><input type="hidden" name="act" value="toggle"><button class="btn btn-sm <?= (int) $c['active'] ? 'btn-bad' : 'btn-ok' ?>" type="submit"><?= (int) $c['active'] ? 'غیرفعال‌سازی' : 'فعال‌سازی' ?></button></form>
  <form method="post" class="row"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $c['id'] ?>"><input type="hidden" name="act" value="setmax"><input type="number" name="max_uses" value="<?= (int) $c['max_uses'] ?>" min="0" style="width:72px" title="سقف کل"><button class="btn btn-sm btn-ghost" type="submit">ثبت سقف کل</button></form>
  <form method="post" class="row"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $c['id'] ?>"><input type="hidden" name="act" value="setperuser"><input type="number" name="per_user_max" value="<?= (int) ($c['per_user_max'] ?? 1) ?>" min="0" style="width:64px" title="سقف هرکاربر"><button class="btn btn-sm btn-ghost" type="submit">ثبت سقف هرکاربر</button></form>
  <?php if ($used === 0): ?><form method="post"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $c['id'] ?>"><input type="hidden" name="act" value="delete"><button class="btn btn-sm btn-ghost" type="submit" onclick="return confirm('کد تخفیف حذف شود؟')">حذف</button></form><?php endif; ?>
</div></td></tr>
<?php endforeach; if (!$list): ?><tr><td colspan="7" class="muted">هنوز کد تخفیفی ساخته نشده است.</td></tr><?php endif; ?></tbody></table></div>
<?php page_foot(['admin' => 1]); ?>
