<?php
require __DIR__ . '/_init.php';
const PAGE = 'admin/orders.php';
function back_qs(): string { $p = []; if (get('s')) $p['s'] = get('s'); if (get('q')) $p['q'] = get('q'); return $p ? '?' . http_build_query($p) : ''; }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $act = post('act');
    if ($act === 'confirm_cancel') { unset($_SESSION['pending_confirm']); flash('درخواست لغو شد.', 'ok'); redirect(u(PAGE . back_qs())); }
    if ($act === 'confirm_apply') {
        $p = confirm_pending(PAGE);
        if (!$p || !hash_equals($p['token'], post('token'))) { flash('این درخواست منقضی شده یا نامعتبر است.', 'bad'); redirect(u(PAGE)); }
        unset($_SESSION['pending_confirm']);
        if ($p['kind'] === 'delete_order') {
            q('DELETE FROM orders WHERE id=?', [$p['order_id']]);
            flash('سفارش حذف شد. توجه: اگر کد فعال‌سازی صادر شده بود، خودِ کد همچنان باقی است (از «کدها» جداگانه حذف کن).', 'ok');
        }
        redirect(u(PAGE . back_qs()));
    }
    $o = row('SELECT * FROM orders WHERE id=?', [(int) post('id')]);
    if ($o) {
        if ($act === 'approve') {
            $c = approve_order((int) $o['id']);
            flash($c ? 'سفارش تایید شد و کد ' . $c['code'] . ' برای کاربر پیامک شد.' : 'سفارش قبلاً تایید شده بود.', 'ok');
        } elseif ($act === 'reject' && $o['status'] !== 'approved') {
            update('orders', ['status' => 'rejected', 'note' => mb_substr(post('note'), 0, 200) ?: 'رسید معتبر نبود', 'updated_at' => time()], 'id=?', [$o['id']]);
            flash('سفارش رد شد. کاربر دلیل را در پنل خودش می‌بیند.', 'ok');
        } elseif ($act === 'delete') {
            confirm_request(PAGE, 'delete_order', 'سفارش شماره ' . fa($o['id']) . ' (' . toman($o['amount']) . ') برای همیشه از پایگاه‌داده حذف شود؟ این کار قابل بازگشت نیست.', ['order_id' => $o['id']]);
        }
    }
    redirect(u(PAGE . back_qs()));
}
$s = get('s'); $qs = en_digits(trim(get('q')));
$tabs = ['' => 'همه', 'awaiting_review' => 'در انتظار تایید', 'pending_payment' => 'در انتظار پرداخت', 'approved' => 'تایید شده', 'rejected' => 'رد شده', 'failed' => 'ناموفق'];
$where = []; $params = [];
if ($s && isset($tabs[$s])) { $where[] = 'o.status=?'; $params[] = $s; }
if ($qs !== '') { $where[] = '(u.mobile LIKE ? OR o.id = ?)'; $params[] = '%' . $qs . '%'; $params[] = (int) $qs; }
$sql = 'SELECT o.*, u.mobile, cp.code AS coupon_code FROM orders o JOIN users u ON u.id=o.user_id LEFT JOIN coupons cp ON cp.id=o.coupon_id'
     . ($where ? ' WHERE ' . implode(' AND ', $where) : '') . ' ORDER BY o.id DESC LIMIT 150';
$list = rows($sql, $params);
page_head('سفارش‌ها', ['admin' => 1]);
?>
<h2>سفارش‌ها</h2>
<?php confirm_box(PAGE); ?>
<div class="tabs"><?php foreach ($tabs as $k => $v): ?><a class="<?= $s === $k ? 'on' : '' ?>" href="orders.php<?= $k ? '?s=' . $k : '' ?>"><?= e($v) ?></a><?php endforeach; ?></div>
<form class="row" style="margin:12px 0"><?php if ($s): ?><input type="hidden" name="s" value="<?= e($s) ?>"><?php endif; ?><input type="text" name="q" value="<?= e(get('q')) ?>" class="ltr" placeholder="جست‌وجوی شماره موبایل یا شماره سفارش" style="max-width:280px"><button class="btn btn-sm" type="submit">جست‌وجو</button><?php if ($qs !== ''): ?><a class="btn btn-sm btn-ghost" href="orders.php<?= $s ? '?s=' . $s : '' ?>">پاک کردن</a><?php endif; ?></form>
<div class="card scroll">
<table class="tbl"><thead><tr><th>شماره</th><th>کاربر</th><th>مبلغ</th><th>روش</th><th>وضعیت</th><th>تاریخ</th><th>رسید</th><th>عملیات</th></tr></thead><tbody>
<?php foreach ($list as $o): $st = order_status_label($o['status']); ?>
<tr><td><?= fa($o['id']) ?></td><td class="ltr"><?= e(fa($o['mobile'])) ?></td><td><?= toman($o['amount']) ?><?php if (!empty($o['plan_name'])): ?><div class="hint"><?= e($o['plan_name']) ?></div><?php endif; ?><?php if ((int) $o['discount'] > 0): ?><div class="hint">تخفیف <?= toman($o['discount']) ?><?= $o['coupon_code'] ? ' • ' . e($o['coupon_code']) : '' ?></div><?php endif; ?></td><td><?= e(method_label($o['method'])) ?><?php if ($o['ref_id']): ?><div class="hint">کد پیگیری: <?= e(fa($o['ref_id'])) ?></div><?php endif; ?></td>
<td><?= badge($st[0], $st[1]) ?><?php if ($o['note']): ?><div class="hint"><?= e($o['note']) ?></div><?php endif; ?></td><td><?= jdate((int) $o['created_at'], true) ?></td>
<td><?php if ($o['receipt_file']): ?><a href="<?= e(u('receipt.php?id=' . $o['id'])) ?>" target="_blank"><img src="<?= e(u('receipt.php?id=' . $o['id'])) ?>" alt="رسید" style="height:56px;border-radius:8px;border:1px solid var(--ln)"></a><?php else: ?>—<?php endif; ?></td>
<td><?php if ($o['status'] !== 'approved'): ?>
  <form method="post" style="margin-bottom:6px" onsubmit="return confirm('سفارش تایید شود و کد برای کاربر ارسال شود؟')"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $o['id'] ?>"><input type="hidden" name="act" value="approve"><button class="btn btn-ok btn-sm" type="submit">تایید و ارسال کد</button></form>
  <?php if ($o['method'] === 'card'): ?><form method="post" style="margin-bottom:6px"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $o['id'] ?>"><input type="hidden" name="act" value="reject"><input type="text" name="note" placeholder="دلیل رد (اختیاری)" style="margin-bottom:4px"><button class="btn btn-bad btn-sm" type="submit">رد</button></form><?php endif; ?>
<?php endif; ?>
  <form method="post"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $o['id'] ?>"><input type="hidden" name="act" value="delete"><button class="btn btn-sm btn-ghost" type="submit" title="نیاز به تایید دومرحله‌ای دارد">حذف سفارش</button></form>
</td></tr>
<?php endforeach; if (!$list): ?><tr><td colspan="8" class="muted"><?= $qs !== '' ? 'چیزی پیدا نشد.' : 'سفارشی وجود ندارد.' ?></td></tr><?php endif; ?></tbody></table></div>
<?php page_foot(['admin' => 1]); ?>
