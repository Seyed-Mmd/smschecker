<?php
require __DIR__ . '/_init.php';
const PAGE = 'admin/tickets.php';
$id = (int) get('id');
$t = $id ? row('SELECT t.*, u.mobile FROM tickets t JOIN users u ON u.id=t.user_id WHERE t.id=?', [$id]) : null;
if (!$t) {   // بعد از confirm_request آدرس به همین صفحه بدون ?id برمی‌گردد؛ تیکت را از روی درخواستِ معلق پیدا می‌کنیم تا جعبه‌ی تایید همچنان دیده شود
    $pc = confirm_pending(PAGE);
    if ($pc && $pc['kind'] === 'delete_ticket') $t = row('SELECT t.*, u.mobile FROM tickets t JOIN users u ON u.id=t.user_id WHERE t.id=?', [$pc['ticket_id']]);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (upload_overflow()) { flash('حجم کل عکس‌ها بیشتر از حد مجاز سرور است. عکس‌های کوچک‌تر یا کمتری بفرست.', 'bad'); redirect(u($t ? PAGE . '?id=' . $t['id'] : PAGE)); }
    csrf_check();
    $act = post('act');
    if ($act === 'confirm_cancel') { unset($_SESSION['pending_confirm']); flash('درخواست لغو شد.', 'ok'); redirect(u($t ? PAGE . '?id=' . $t['id'] : PAGE)); }
    if ($act === 'confirm_apply') {
        $p = confirm_pending(PAGE);
        if (!$p || !hash_equals($p['token'], post('token'))) { flash('این درخواست منقضی شده یا نامعتبر است.', 'bad'); redirect(u(PAGE)); }
        unset($_SESSION['pending_confirm']);
        if ($p['kind'] === 'delete_ticket') {
            ticket_delete_files((int) $p['ticket_id']);   // اول عکس‌های پیوست پاک شوند (قبل از پاک‌شدن پیام‌ها)
            q('DELETE FROM ticket_msgs WHERE ticket_id=?', [$p['ticket_id']]);
            q('DELETE FROM tickets WHERE id=?', [$p['ticket_id']]);
            flash('تیکت برای همیشه حذف شد.', 'ok');
        }
        redirect(u(PAGE));
    }
    if ($t && $act === 'delete') {
        confirm_request(PAGE, 'delete_ticket', 'تیکت «' . $t['subject'] . '» و تمام پیام‌هایش برای همیشه حذف شود؟ این کار قابل بازگشت نیست.', ['ticket_id' => $t['id']]);
    }
    if ($t && $act === 'reply') {
        $body = mb_substr(post('body'), 0, 3000);
        [$imgs, $ierr] = ticket_save_images();
        if ($ierr) flash($ierr, 'bad');
        elseif (mb_strlen($body) < 2 && !$imgs) flash('متن پاسخ خالی است.', 'bad');
        else {
            $mid = insert('ticket_msgs', ['ticket_id' => $t['id'], 'is_admin' => 1, 'body' => $body, 'created_at' => time()]);
            ticket_attach($mid, $imgs);
            update('tickets', ['status' => post('close') === '1' ? 'closed' : 'answered', 'updated_at' => time()], 'id=?', [$t['id']]);
            $sent = sms_send('ticket_reply', $t['mobile'], (string) $t['id']);
            flash('پاسخ ثبت شد' . ($sent ? ' و پیامک اطلاع‌رسانی برای کاربر رفت.' : ' (ارسال پیامک به کاربر انجام نشد).'), $sent ? 'ok' : 'warn');
        }
    } elseif ($t && ($act === 'close' || $act === 'open')) {
        update('tickets', ['status' => $act === 'close' ? 'closed' : 'open', 'updated_at' => time()], 'id=?', [$t['id']]);
    }
    redirect(u("admin/tickets.php?id={$t['id']}"));
}
page_head('تیکت‌ها', ['admin' => 1]);
if ($t):
    $s = ticket_status_label($t['status']); $msgs = rows('SELECT * FROM ticket_msgs WHERE ticket_id=? ORDER BY id', [$t['id']]); $files = ticket_files_for(array_column($msgs, 'id')); ?>
<p><a href="tickets.php">← همه‌ی تیکت‌ها</a></p>
<?php confirm_box(PAGE); ?>
<div class="card">
  <div class="row between"><h2 style="margin:0"><?= e($t['subject']) ?></h2><?= badge($s[0], $s[1]) ?></div>
  <p class="muted">تیکت <?= fa($t['id']) ?> • کاربر: <span class="ltr" style="display:inline-block"><?= e(fa($t['mobile'])) ?></span> • <?= jdate((int) $t['created_at'], true) ?></p>
  <?php foreach ($msgs as $m): ?><div class="msg <?= $m['is_admin'] ? 'me' : 'admin' ?>"><small><?= $m['is_admin'] ? 'پشتیبانی' : 'کاربر' ?> • <?= jdate((int) $m['created_at'], true) ?></small><?= e($m['body']) ?><?= ticket_images_html($files[$m['id']] ?? []) ?></div><?php endforeach; ?>
  <form method="post" enctype="multipart/form-data" data-once><?= csrf_field() ?><input type="hidden" name="act" value="reply">
    <label>پاسخ (بعد از ثبت، به کاربر پیامک می‌شود)</label><textarea name="body"></textarea>
    <?= ticket_image_input() ?>
    <label class="check"><input type="checkbox" name="close" value="1"> بعد از پاسخ، تیکت بسته شود</label>
    <button class="btn" type="submit">ثبت پاسخ</button></form>
  <div class="row" style="margin-top:10px">
    <form method="post"><?= csrf_field() ?><input type="hidden" name="act" value="<?= $t['status'] === 'closed' ? 'open' : 'close' ?>"><button class="btn btn-ghost btn-sm" type="submit"><?= $t['status'] === 'closed' ? 'بازکردن تیکت' : 'بستن بدون پاسخ' ?></button></form>
    <form method="post"><?= csrf_field() ?><input type="hidden" name="act" value="delete"><button class="btn btn-ghost btn-sm" type="submit" title="نیاز به تایید دومرحله‌ای دارد">حذف تیکت</button></form>
  </div>
</div>
<?php else:
    $s = get('s'); $qs = trim(get('q')); $tabs = ['' => 'همه', 'open' => 'در انتظار پاسخ', 'answered' => 'پاسخ داده شده', 'closed' => 'بسته'];
    $where = []; $params = [];
    if ($s && isset($tabs[$s])) { $where[] = 't.status=?'; $params[] = $s; }
    if ($qs !== '') { $where[] = '(t.subject LIKE ? OR u.mobile LIKE ?)'; $params[] = '%' . $qs . '%'; $params[] = '%' . en_digits($qs) . '%'; }
    $sql = 'SELECT t.*, u.mobile FROM tickets t JOIN users u ON u.id=t.user_id' . ($where ? ' WHERE ' . implode(' AND ', $where) : '') . ' ORDER BY t.updated_at DESC LIMIT 150';
    $list = rows($sql, $params); ?>
<h2>تیکت‌های پشتیبانی</h2>
<div class="tabs"><?php foreach ($tabs as $k => $v): ?><a class="<?= $s === $k ? 'on' : '' ?>" href="tickets.php<?= $k ? '?s=' . $k : '' ?>"><?= e($v) ?></a><?php endforeach; ?></div>
<form class="row" style="margin:12px 0"><?php if ($s): ?><input type="hidden" name="s" value="<?= e($s) ?>"><?php endif; ?><input type="text" name="q" value="<?= e($qs) ?>" placeholder="جست‌وجوی موضوع یا شماره موبایل" style="max-width:280px"><button class="btn btn-sm" type="submit">جست‌وجو</button><?php if ($qs !== ''): ?><a class="btn btn-sm btn-ghost" href="tickets.php<?= $s ? '?s=' . $s : '' ?>">پاک کردن</a><?php endif; ?></form>
<div class="card scroll"><table class="tbl"><thead><tr><th>شماره</th><th>موضوع</th><th>کاربر</th><th>وضعیت</th><th>آخرین به‌روزرسانی</th></tr></thead><tbody>
<?php foreach ($list as $x): $st = ticket_status_label($x['status']); ?>
<tr><td><?= fa($x['id']) ?></td><td><a href="tickets.php?id=<?= $x['id'] ?>"><?= e($x['subject']) ?></a></td><td class="ltr"><?= e(fa($x['mobile'])) ?></td><td><?= badge($st[0], $st[1]) ?></td><td><?= jdate((int) $x['updated_at'], true) ?></td></tr>
<?php endforeach; if (!$list): ?><tr><td colspan="5" class="muted"><?= $qs !== '' ? 'چیزی پیدا نشد.' : 'تیکتی وجود ندارد.' ?></td></tr><?php endif; ?></tbody></table></div>
<?php endif; page_foot(['admin' => 1]); ?>
