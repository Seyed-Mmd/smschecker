<?php
require __DIR__ . '/_init.php';
$now = time(); $day = strtotime('today');
$pending = (int) val("SELECT COUNT(*) FROM orders WHERE status='awaiting_review'");
$tickets = (int) val("SELECT COUNT(*) FROM tickets WHERE status='open'");
$users = (int) val('SELECT COUNT(*) FROM users');
$activeCodes = 0;
foreach (rows('SELECT revoked, expires_at FROM codes') as $c) if (code_status($c) === 'active') $activeCodes++;
$sumToday = (int) val("SELECT COALESCE(SUM(amount),0) FROM orders WHERE status='approved' AND updated_at>=?", [$day]);
$sum30 = (int) val("SELECT COALESCE(SUM(amount),0) FROM orders WHERE status='approved' AND updated_at>=?", [$now - 30 * 86400]);
$sumAll = (int) val("SELECT COALESCE(SUM(amount),0) FROM orders WHERE status='approved'");
$recent = rows('SELECT o.*, u.mobile FROM orders o JOIN users u ON u.id=o.user_id ORDER BY o.id DESC LIMIT 8');
$todo = [];
if (setting('sms_api_key') === '') $todo[] = 'کلید API سامانه SMS.ir را در تنظیمات وارد کن (بدون آن کد ورود و پیامک‌ها ارسال نمی‌شود).';
if (setting('sms_line') === '' && (int) setting('sms_tpl_otp') === 0) $todo[] = 'شماره خط SMS.ir یا شناسه قالب پیامک‌ها را وارد کن.';
if (setting('pay_gateway_on') === '1' && setting('zarinpal_merchant') === '') $todo[] = 'مرچنت‌کد زرین‌پال را وارد کن یا درگاه پرداخت را غیرفعال کن.';
if (setting('pay_card_on') === '1' && setting('card_number') === '') $todo[] = 'شماره کارت را وارد کن یا کارت‌به‌کارت را غیرفعال کن.';
if (norm_mobile(setting('admin_phone')) === null) $todo[] = 'شماره موبایل ادمین را برای دریافت پیامک سفارش و تیکت وارد کن.';
if (setting('app_download_url') === '') $todo[] = 'لینک دانلود برنامه را در تنظیمات بگذار تا در پنل کاربران نمایش داده شود.';
page_head('داشبورد', ['admin' => 1]);
?>
<h2>داشبورد</h2>
<?php if ($todo): ?><div class="alert warn"><b>برای آماده شدن سایت:</b><ul style="margin:6px 0 0"><?php foreach ($todo as $t): ?><li><?= e($t) ?></li><?php endforeach; ?></ul></div><?php endif; ?>
<div class="grid g4" style="margin-bottom:18px">
  <a class="stat" href="orders.php?s=awaiting_review"><b><?= fa($pending) ?></b><span>سفارش در انتظار تایید</span></a>
  <a class="stat" href="tickets.php?s=open"><b><?= fa($tickets) ?></b><span>تیکت بدون پاسخ</span></a>
  <a class="stat" href="codes.php"><b><?= fa($activeCodes) ?></b><span>کد فعال</span></a>
  <a class="stat" href="users.php"><b><?= fa($users) ?></b><span>کاربر</span></a>
</div>
<div class="grid g3" style="margin-bottom:18px">
  <div class="stat"><b><?= toman($sumToday) ?></b><span>فروش امروز</span></div>
  <div class="stat"><b><?= toman($sum30) ?></b><span>فروش ۳۰ روز اخیر</span></div>
  <div class="stat"><b><?= toman($sumAll) ?></b><span>فروش کل</span></div>
</div>
<div class="card scroll"><h3>آخرین سفارش‌ها</h3>
<table class="tbl"><thead><tr><th>شماره</th><th>کاربر</th><th>مبلغ</th><th>روش</th><th>وضعیت</th><th>تاریخ</th></tr></thead><tbody>
<?php foreach ($recent as $o): $s = order_status_label($o['status']); ?>
<tr><td><?= fa($o['id']) ?></td><td class="ltr"><?= e(fa($o['mobile'])) ?></td><td><?= toman($o['amount']) ?></td><td><?= e(method_label($o['method'])) ?></td><td><?= badge($s[0], $s[1]) ?></td><td><?= jdate((int) $o['created_at'], true) ?></td></tr>
<?php endforeach; if (!$recent): ?><tr><td colspan="6" class="muted">هنوز سفارشی ثبت نشده است.</td></tr><?php endif; ?></tbody></table></div>
<?php page_foot(['admin' => 1]); ?>
