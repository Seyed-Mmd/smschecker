<?php
require __DIR__ . '/_init.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $act = post('act');
    if ($act === 'add') {
        $name = mb_substr(trim(post('name')), 0, 60);
        $price = max(0, min(100000000, (int) en_digits(post('price'))));
        $days = max(0, min(36500, (int) en_digits(post('days'))));
        $max = max(1, min(50, (int) en_digits(post('max_uses'))));
        if ($name === '') flash('نام پلن را بنویس (مثلاً «یک ماهه» یا «نامحدود»).', 'bad');
        else {
            $sort = (int) val('SELECT COALESCE(MAX(sort_order),0)+1 FROM plans');
            insert('plans', ['name' => $name, 'price' => $price, 'days' => $days, 'max_uses' => $max, 'active' => 1, 'sort_order' => $sort, 'created_at' => time()]);
            flash('پلن «' . $name . '» ساخته شد.', 'ok');
        }
    } else {
        $p = row('SELECT * FROM plans WHERE id=?', [(int) post('id')]);
        if ($p) {
            if ($act === 'toggle') { update('plans', ['active' => (int) $p['active'] ? 0 : 1], 'id=?', [$p['id']]); flash((int) $p['active'] ? 'پلن از صفحه‌ی خرید پنهان شد.' : 'پلن دوباره نمایش داده می‌شود.', 'ok'); }
            elseif ($act === 'edit') {
                $name = mb_substr(trim(post('name')), 0, 60);
                $price = max(0, min(100000000, (int) en_digits(post('price'))));
                $days = max(0, min(36500, (int) en_digits(post('days'))));
                $max = max(1, min(50, (int) en_digits(post('max_uses'))));
                if ($name === '') flash('نام پلن نمی‌تواند خالی باشد.', 'bad');
                else { update('plans', ['name' => $name, 'price' => $price, 'days' => $days, 'max_uses' => $max], 'id=?', [$p['id']]); flash('پلن «' . $name . '» به‌روز شد.', 'ok'); }
            } elseif ($act === 'delete') {
                if (val('SELECT COUNT(*) FROM orders WHERE plan_id=?', [$p['id']])) flash('این پلن قبلاً خریداری شده؛ به‌جای حذف، آن را پنهان کن.', 'bad');
                else { q('DELETE FROM plans WHERE id=?', [$p['id']]); flash('پلن حذف شد.', 'ok'); }
            } elseif ($act === 'up' || $act === 'down') {
                $dir = $act === 'up' ? '<' : '>'; $ord = $act === 'up' ? 'DESC' : 'ASC';
                $nb = row("SELECT * FROM plans WHERE sort_order $dir ? ORDER BY sort_order $ord LIMIT 1", [$p['sort_order']]);
                if ($nb) { update('plans', ['sort_order' => $nb['sort_order']], 'id=?', [$p['id']]); update('plans', ['sort_order' => $p['sort_order']], 'id=?', [$nb['id']]); }
            }
        }
    }
    redirect(u('admin/plans.php'));
}
$list = rows('SELECT * FROM plans ORDER BY sort_order ASC, id ASC');
page_head('پلن‌های خرید', ['admin' => 1]);
?>
<h2>پلن‌های خرید</h2>
<p class="muted">چند نوع اشتراک برای خرید تعریف کن (مثلاً یک‌ماهه، سه‌ماهه، یک‌ساله، نامحدود). همه‌ی پلن‌های «فعال» در صفحه‌ی خرید و صفحه‌ی اول سایت نمایش داده می‌شوند.</p>
<div class="card"><h3>افزودن پلن تازه</h3>
  <form method="post"><?= csrf_field() ?><input type="hidden" name="act" value="add">
    <div class="grid g4" style="align-items:start">
      <div><label>نام پلن</label><input type="text" name="name" placeholder="مثلاً سه ماهه" required></div>
      <div><label>قیمت (تومان)</label><input type="number" name="price" min="0" required></div>
      <div><label>مدت اعتبار (روز)</label><input type="number" name="days" min="0" value="30"><div class="hint">۰ یعنی نامحدود (بدون انقضا).</div></div>
      <div><label>سقف تعداد گوشی</label><input type="number" name="max_uses" min="1" value="2"></div>
    </div>
    <p><button class="btn btn-sm" type="submit">افزودن پلن</button></p>
  </form></div>
<div class="card scroll">
<table class="tbl"><thead><tr><th>ترتیب</th><th>نام</th><th>قیمت</th><th>مدت</th><th>سقف گوشی</th><th>وضعیت</th><th>خرید</th><th>عملیات</th></tr></thead><tbody>
<?php foreach ($list as $i => $p): $bought = (int) val('SELECT COUNT(*) FROM orders WHERE plan_id=?', [$p['id']]); ?>
<tr><td><div class="row">
    <form method="post"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $p['id'] ?>"><input type="hidden" name="act" value="up"><button class="btn btn-sm btn-ghost" type="submit" <?= $i === 0 ? 'disabled' : '' ?>>▲</button></form>
    <form method="post"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $p['id'] ?>"><input type="hidden" name="act" value="down"><button class="btn btn-sm btn-ghost" type="submit" <?= $i === count($list) - 1 ? 'disabled' : '' ?>>▼</button></form>
  </div></td>
  <td colspan="4">
  <form method="post" class="row"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $p['id'] ?>"><input type="hidden" name="act" value="edit">
    <input type="text" name="name" value="<?= e($p['name']) ?>" style="max-width:140px" required>
    <input type="number" name="price" value="<?= (int) $p['price'] ?>" min="0" style="max-width:110px">
    <input type="number" name="days" value="<?= (int) $p['days'] ?>" min="0" style="max-width:80px" title="روز">
    <input type="number" name="max_uses" value="<?= (int) $p['max_uses'] ?>" min="1" style="max-width:70px" title="سقف گوشی">
    <button class="btn btn-sm btn-ghost" type="submit">ذخیره</button>
  </form></td>
  <td><?= badge((int) $p['active'] ? 'نمایش داده می‌شود' : 'پنهان', (int) $p['active'] ? 'ok' : 'muted') ?></td>
  <td><?= fa($bought) ?></td>
  <td><div class="row">
    <form method="post"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $p['id'] ?>"><input type="hidden" name="act" value="toggle"><button class="btn btn-sm <?= (int) $p['active'] ? 'btn-bad' : 'btn-ok' ?>" type="submit"><?= (int) $p['active'] ? 'پنهان‌سازی' : 'نمایش' ?></button></form>
    <?php if ($bought === 0): ?><form method="post"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $p['id'] ?>"><input type="hidden" name="act" value="delete"><button class="btn btn-sm btn-ghost" type="submit" onclick="return confirm('این پلن حذف شود؟')">حذف</button></form><?php endif; ?>
  </div></td></tr>
<?php endforeach; if (!$list): ?><tr><td colspan="8" class="muted">هنوز پلنی ساخته نشده است.</td></tr><?php endif; ?></tbody></table></div>
<?php page_foot(['admin' => 1]); ?>
