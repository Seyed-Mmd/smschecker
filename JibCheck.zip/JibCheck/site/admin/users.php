<?php
require __DIR__ . '/_init.php';
const PAGE = 'admin/users.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $act = post('act');
    $qs = get('q') ? '?q=' . urlencode(get('q')) : '';
    if ($act === 'note') {
        $x = row('SELECT * FROM users WHERE id=?', [(int) post('id')]);
        if ($x) { update('users', ['note' => mb_substr(post('note'), 0, 500)], 'id=?', [$x['id']]); flash('یادداشت ذخیره شد.', 'ok'); }
        redirect(u(PAGE . $qs));
    }
    if ($act === 'confirm_cancel') { unset($_SESSION['pending_confirm']); flash('درخواست لغو شد.', 'ok'); redirect(u(PAGE . $qs)); }
    if ($act === 'confirm_apply') {
        $p = confirm_pending(PAGE);
        if (!$p || !hash_equals($p['token'], post('token'))) { flash('این درخواست منقضی شده یا نامعتبر است.', 'bad'); redirect(u(PAGE)); }
        unset($_SESSION['pending_confirm']);
        if ($p['kind'] === 'delete_user') {
            $uid = $p['user_id'];
            foreach (rows('SELECT id, code FROM codes WHERE user_id=?', [$uid]) as $c) { q('DELETE FROM activations WHERE code_id=?', [$c['id']]); @unlink(code_page_file($c['code'])); }
            q('DELETE FROM codes WHERE user_id=?', [$uid]);
            foreach (rows('SELECT id FROM tickets WHERE user_id=?', [$uid]) as $t) { ticket_delete_files((int) $t['id']); q('DELETE FROM ticket_msgs WHERE ticket_id=?', [$t['id']]); }
            q('DELETE FROM tickets WHERE user_id=?', [$uid]);
            q('DELETE FROM orders WHERE user_id=?', [$uid]);
            q('DELETE FROM remember_tokens WHERE user_id=?', [$uid]);
            q('DELETE FROM users WHERE id=?', [$uid]);
            flash('کاربر و تمام سفارش‌ها، کدها و تیکت‌هایش برای همیشه حذف شد.', 'ok');
        }
        redirect(u(PAGE . $qs));
    }
    if ($act === 'delete_user') {
        $x = row('SELECT * FROM users WHERE id=?', [(int) post('id')]);
        if ($x) {
            $no = (int) val('SELECT COUNT(*) FROM orders WHERE user_id=?', [$x['id']]);
            $nc = (int) val('SELECT COUNT(*) FROM codes WHERE user_id=?', [$x['id']]);
            $nt = (int) val('SELECT COUNT(*) FROM tickets WHERE user_id=?', [$x['id']]);
            confirm_request(PAGE, 'delete_user', 'کاربر ' . fa($x['mobile']) . ' به همراه ' . fa($no) . ' سفارش، ' . fa($nc) . ' کد و ' . fa($nt) . ' تیکتش برای همیشه حذف شود؟ این کار قابل بازگشت نیست.', ['user_id' => $x['id']]);
        }
        redirect(u(PAGE . $qs));
    }
    redirect(u(PAGE . $qs));
}
$qs = en_digits(trim(get('q')));
$list = $qs !== '' ? rows('SELECT * FROM users WHERE mobile LIKE ? ORDER BY id DESC LIMIT 200', ['%' . $qs . '%']) : rows('SELECT * FROM users ORDER BY id DESC LIMIT 200');
page_head('کاربران', ['admin' => 1]);
?>
<h2>کاربران</h2>
<?php confirm_box(PAGE); ?>
<form class="row" style="margin-bottom:14px"><input type="text" name="q" value="<?= e($qs) ?>" class="ltr" placeholder="جست‌وجوی شماره موبایل" style="max-width:260px"><button class="btn btn-sm" type="submit">جست‌وجو</button><?php if ($qs !== ''): ?><a class="btn btn-sm btn-ghost" href="users.php">پاک کردن</a><?php endif; ?></form>
<div class="card scroll"><table class="tbl"><thead><tr><th>شماره</th><th>موبایل</th><th>سفارش‌ها</th><th>کدها</th><th>تیکت‌ها</th><th>عضویت</th><th>آخرین ورود</th><th>یادداشت</th><th>عملیات</th></tr></thead><tbody>
<?php foreach ($list as $x): ?>
<tr><td><?= fa($x['id']) ?></td><td class="ltr"><?= e(fa($x['mobile'])) ?></td>
<td><?= fa(val('SELECT COUNT(*) FROM orders WHERE user_id=?', [$x['id']])) ?></td><td><?= fa(val('SELECT COUNT(*) FROM codes WHERE user_id=?', [$x['id']])) ?></td><td><?= fa(val('SELECT COUNT(*) FROM tickets WHERE user_id=?', [$x['id']])) ?></td>
<td><?= jdate((int) $x['created_at']) ?></td><td><?= (int) $x['last_login'] ? jdate((int) $x['last_login'], true) : '—' ?></td>
<td><form method="post" class="row" style="flex-wrap:nowrap"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $x['id'] ?>"><input type="hidden" name="act" value="note">
  <input type="text" name="note" value="<?= e($x['note'] ?? '') ?>" placeholder="یادداشت داخلی…" style="min-width:120px"><button class="btn btn-sm btn-ghost" type="submit">ذخیره</button></form></td>
<td><form method="post"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $x['id'] ?>"><input type="hidden" name="act" value="delete_user"><button class="btn btn-sm btn-bad" type="submit" title="نیاز به تایید دومرحله‌ای دارد">حذف کامل</button></form></td></tr>
<?php endforeach; if (!$list): ?><tr><td colspan="9" class="muted">کاربری پیدا نشد.</td></tr><?php endif; ?></tbody></table></div>
<?php page_foot(['admin' => 1]); ?>
