<?php
require dirname(__DIR__) . '/inc/bootstrap.php';
unset($_SESSION['aid'], $_SESSION['atime']); session_regenerate_id(true);
redirect(u('admin/login.php'));
