<?php
require __DIR__ . '/_init.php';
const PAGE = 'admin/codes.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $act = post('act');
    $qs = get('q') ? '?q=' . urlencode(get('q')) : '';

    if ($act === 'issue') {   // صدور دستی: عملِ ساخت تازه است، نه تغییر چیز موجود؛ نیاز به تایید دومرحله ندارد
        $m = norm_mobile(post('mobile'));
        if (!$m) flash('شماره موبایل درست نیست.', 'bad');
        else {
            $u = row('SELECT * FROM users WHERE mobile=?', [$m]);
            $uid = $u ? (int) $u['id'] : insert('users', ['mobile' => $m, 'created_at' => time(), 'last_login' => 0]);
            $c = issue_code($uid, null);
            if (post('sms') === '1') sms_send('code', $m, $c['code']);
            flash('کد ' . $c['code'] . ' برای ' . fa($m) . ' صادر شد' . (post('sms') === '1' ? ' و پیامک شد.' : '.'), 'ok');
        }
        redirect(u(PAGE . $qs));
    }

    if ($act === 'note') {   // یادداشت: اطلاعاتی و کم‌خطر است؛ نیاز به تایید دومرحله ندارد
        $c = row('SELECT * FROM codes WHERE id=?', [(int) post('id')]);
        if ($c) { update('codes', ['note' => mb_substr(post('note'), 0, 500)], 'id=?', [$c['id']]); flash('یادداشت ذخیره شد.', 'ok'); }
        redirect(u(PAGE . $qs));
    }

    if ($act === 'confirm_cancel') { unset($_SESSION['pending_confirm']); flash('درخواست لغو شد.', 'ok'); redirect(u(PAGE . $qs)); }

    if ($act === 'confirm_apply') {
        $p = confirm_pending(PAGE);
        if (!$p || !hash_equals($p['token'], post('token'))) { flash('این درخواست منقضی شده یا نامعتبر است؛ دوباره امتحان کن.', 'bad'); redirect(u(PAGE)); }
        unset($_SESSION['pending_confirm']);
        $c = row('SELECT * FROM codes WHERE id=?', [$p['code_id']]);
        if (!$c) { flash('این کد دیگر وجود ندارد.', 'bad'); redirect(u(PAGE)); }
        switch ($p['kind']) {
            case 'revoke': update('codes', ['revoked' => 1], 'id=?', [$c['id']]); write_code_page(row('SELECT * FROM codes WHERE id=?', [$c['id']])); flash('کد لغو شد؛ برنامه‌ها حداکثر تا یک روز بعد قفل می‌شوند.', 'ok'); break;
            case 'restore': update('codes', ['revoked' => 0], 'id=?', [$c['id']]); write_code_page(row('SELECT * FROM codes WHERE id=?', [$c['id']])); flash('کد دوباره فعال شد.', 'ok'); break;
            case 'extend': $base = max(time(), (int) $c['expires_at']); update('codes', ['expires_at' => $base + $p['amount'] * 86400], 'id=?', [$c['id']]); write_code_page(row('SELECT * FROM codes WHERE id=?', [$c['id']])); flash('اعتبار کد ' . fa($p['amount']) . ' روز تمدید شد.', 'ok'); break;
            case 'addslot': update('codes', ['max_uses' => (int) $c['max_uses'] + 1], 'id=?', [$c['id']]); write_code_page(row('SELECT * FROM codes WHERE id=?', [$c['id']])); flash('یک بار دیگر به ظرفیت فعال‌سازی کد اضافه شد.', 'ok'); break;
            case 'reset': q('DELETE FROM activations WHERE code_id=?', [$c['id']]); flash('گوشی‌های فعال‌شده‌ی این کد پاک شد و ظرفیت دوباره کامل است.', 'ok'); break;
            case 'rewrite': write_code_page($c); flash('صفحه‌ی استاتیک کد دوباره ساخته شد.', 'ok'); break;
            case 'dec_days': update('codes', ['expires_at' => $p['new_expires']], 'id=?', [$c['id']]); write_code_page(row('SELECT * FROM codes WHERE id=?', [$c['id']])); flash('اعتبار کد ' . fa($p['amount']) . ' روز کم شد.', 'ok'); break;
            case 'dec_cap': update('codes', ['max_uses' => $p['new_max']], 'id=?', [$c['id']]); write_code_page(row('SELECT * FROM codes WHERE id=?', [$c['id']])); flash('ظرفیت فعال‌سازی کد به ' . fa($p['new_max']) . ' کاهش یافت.', 'ok'); break;
            case 'delete':
                q('DELETE FROM activations WHERE code_id=?', [$c['id']]);
                q('UPDATE orders SET code_id=NULL WHERE code_id=?', [$c['id']]);
                q('DELETE FROM codes WHERE id=?', [$c['id']]);
                @unlink(code_page_file($c['code']));
                flash('کد ' . $c['code'] . ' برای همیشه حذف شد.', 'ok'); break;
        }
        redirect(u(PAGE . $qs));
    }

    // هر عمل دیگری روی یک کد، اول فقط درخواست تایید می‌سازد؛ هیچ تغییری فوراً انجام نمی‌شود
    $c = row('SELECT * FROM codes WHERE id=?', [(int) post('id')]);
    if (!$c) { flash('کد پیدا نشد.', 'bad'); redirect(u(PAGE . $qs)); }
    $used = activation_count((int) $c['id']);
    if ($act === 'revoke') confirm_request(PAGE, 'revoke', 'کد ' . $c['code'] . ' لغو شود؟ برنامه‌های نصب‌شده حداکثر تا یک روز بعد قفل می‌شوند.', ['code_id' => $c['id']]);
    elseif ($act === 'restore') confirm_request(PAGE, 'restore', 'کد ' . $c['code'] . ' دوباره فعال شود؟', ['code_id' => $c['id']]);
    elseif ($act === 'extend') { $d = max(1, min(3650, (int) post('days'))); confirm_request(PAGE, 'extend', 'اعتبار کد ' . $c['code'] . ' به مدت ' . fa($d) . ' روز تمدید شود؟', ['code_id' => $c['id'], 'amount' => $d]); }
    elseif ($act === 'addslot') confirm_request(PAGE, 'addslot', 'یک ظرفیت فعال‌سازی به کد ' . $c['code'] . ' اضافه شود؟ (ظرفیت جدید: ' . fa((int) $c['max_uses'] + 1) . ')', ['code_id' => $c['id']]);
    elseif ($act === 'reset') confirm_request(PAGE, 'reset', 'گوشی‌های فعال‌شده‌ی کد ' . $c['code'] . ' (' . fa($used) . ' گوشی) پاک شود؟ کاربر باید دوباره کد را در اپ وارد کند.', ['code_id' => $c['id']]);
    elseif ($act === 'rewrite') confirm_request(PAGE, 'rewrite', 'صفحه‌ی استاتیک کد ' . $c['code'] . ' دوباره ساخته شود؟', ['code_id' => $c['id']]);
    elseif ($act === 'dec_days') {
        $d = max(1, min(3650, (int) post('days')));
        if ((int) $c['expires_at'] === 0) { flash('این کد «نامحدود» است؛ کاهش روز معنی ندارد.', 'bad'); redirect(u(PAGE . $qs)); }
        $newExp = max(1, (int) $c['expires_at'] - $d * 86400);
        confirm_request(PAGE, 'dec_days', fa($d) . ' روز از اعتبار کد ' . $c['code'] . ' کم شود (تاریخ جدید: ' . jdate($newExp) . ')؟', ['code_id' => $c['id'], 'amount' => $d, 'new_expires' => $newExp]);
    } elseif ($act === 'dec_cap') {
        $n = max(1, min(50, (int) post('cap')));
        $newMax = max($used, (int) $c['max_uses'] - $n);
        if ($newMax === (int) $c['max_uses']) { flash('ظرفیت این کد را نمی‌توان بیشتر کم کرد (به تعداد گوشی‌های فعال‌شده‌ی فعلی رسیده).', 'bad'); redirect(u(PAGE . $qs)); }
        confirm_request(PAGE, 'dec_cap', 'ظرفیت کد ' . $c['code'] . ' از ' . fa($c['max_uses']) . ' به ' . fa($newMax) . ' کاهش یابد؟' . ($newMax > (int) $c['max_uses'] - $n ? ' (به‌خاطر ' . fa($used) . ' گوشی فعال‌شده، بیشتر از این کم نمی‌شود.)' : ''), ['code_id' => $c['id'], 'amount' => $n, 'new_max' => $newMax]);
    } elseif ($act === 'delete_code') {
        confirm_request(PAGE, 'delete', 'کد ' . $c['code'] . ($used ? ' (با ' . fa($used) . ' گوشی فعال‌شده)' : '') . ' برای همیشه حذف شود؟ این کار قابل بازگشت نیست و با لغو کد فرق دارد.', ['code_id' => $c['id']]);
    }
    redirect(u(PAGE . $qs));
}

$qs = en_digits(trim(get('q')));
$list = $qs !== ''
    ? rows("SELECT c.*, u.mobile FROM codes c JOIN users u ON u.id=c.user_id WHERE c.code LIKE ? OR u.mobile LIKE ? ORDER BY c.id DESC LIMIT 200", ['%' . $qs . '%', '%' . $qs . '%'])
    : rows('SELECT c.*, u.mobile FROM codes c JOIN users u ON u.id=c.user_id ORDER BY c.id DESC LIMIT 200');
page_head('کدها', ['admin' => 1]);
?>
<h2>کدهای فعال‌سازی</h2>
<?php confirm_box(PAGE); ?>
<div class="card"><h3>صدور دستی کد</h3>
  <form method="post" class="row"><?= csrf_field() ?><input type="hidden" name="act" value="issue">
    <input type="tel" name="mobile" class="ltr" placeholder="شماره موبایل کاربر" style="max-width:240px" required>
    <label class="check" style="margin:0"><input type="checkbox" name="sms" value="1" checked> ارسال پیامک</label>
    <button class="btn btn-sm" type="submit">صدور کد</button></form></div>
<form class="row" style="margin:14px 0"><input type="text" name="q" value="<?= e(get('q')) ?>" class="ltr" placeholder="جست‌وجوی کد یا شماره موبایل" style="max-width:260px"><button class="btn btn-sm" type="submit">جست‌وجو</button><?php if (get('q')): ?><a class="btn btn-sm btn-ghost" href="codes.php">پاک کردن</a><?php endif; ?></form>
<div class="card scroll">
<table class="tbl"><thead><tr><th>کد</th><th>کاربر</th><th>وضعیت</th><th>استفاده</th><th>انقضا</th><th>یادداشت</th><th>عملیات</th></tr></thead><tbody>
<?php foreach ($list as $c): $st = code_status($c); $lb = code_status_label($st); $used = activation_count((int) $c['id']);
    $devs = rows('SELECT device_name, last_at FROM activations WHERE code_id=?', [$c['id']]); ?>
<tr><td class="ltr" style="font-family:monospace"><?= e($c['code']) ?><div class="hint"><?= $c['order_id'] ? 'سفارش ' . fa($c['order_id']) : 'صدور دستی' ?></div></td>
<td class="ltr"><?= e(fa($c['mobile'])) ?></td><td><?= badge($lb[0], $lb[1]) ?></td>
<td><?= fa($used) ?> از <?= fa($c['max_uses']) ?><?php foreach ($devs as $d): ?><div class="hint"><?= e($d['device_name'] ?: 'نامشخص') ?></div><?php endforeach; ?></td>
<td><?= (int) $c['expires_at'] ? jdate((int) $c['expires_at']) : 'بدون انقضا' ?></td>
<td><form method="post" class="row" style="flex-wrap:nowrap"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $c['id'] ?>"><input type="hidden" name="act" value="note">
  <input type="text" name="note" value="<?= e($c['note'] ?? '') ?>" placeholder="یادداشت داخلی…" style="min-width:120px">
  <button class="btn btn-sm btn-ghost" type="submit">ذخیره</button></form></td>
<td><details class="actions"><summary>عملیات ▾</summary>
  <div class="act-grid">
    <form method="post"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $c['id'] ?>"><input type="hidden" name="act" value="<?= $c['revoked'] ? 'restore' : 'revoke' ?>"><button class="btn btn-sm <?= $c['revoked'] ? 'btn-ok' : 'btn-bad' ?>" type="submit"><?= $c['revoked'] ? 'فعال‌سازی دوباره' : 'لغو کد' ?></button></form>
    <form method="post" class="row"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $c['id'] ?>"><input type="hidden" name="act" value="extend"><input type="number" name="days" value="30" min="1" style="width:70px"><button class="btn btn-sm btn-ghost" type="submit">تمدید (روز)</button></form>
    <form method="post"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $c['id'] ?>"><input type="hidden" name="act" value="addslot"><button class="btn btn-sm btn-ghost" type="submit">+۱ ظرفیت</button></form>
    <form method="post"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $c['id'] ?>"><input type="hidden" name="act" value="reset"><button class="btn btn-sm btn-ghost" type="submit">ریست گوشی‌ها</button></form>
    <form method="post" class="row"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $c['id'] ?>"><input type="hidden" name="act" value="dec_days"><input type="number" name="days" value="30" min="1" style="width:70px"><button class="btn btn-sm btn-ghost" type="submit">کاهش روز</button></form>
    <form method="post" class="row"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $c['id'] ?>"><input type="hidden" name="act" value="dec_cap"><input type="number" name="cap" value="1" min="1" style="width:56px"><button class="btn btn-sm btn-ghost" type="submit">کاهش ظرفیت</button></form>
    <form method="post"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $c['id'] ?>"><input type="hidden" name="act" value="rewrite"><button class="btn btn-sm btn-ghost" type="submit">بازسازی صفحه‌ی استاتیک</button></form>
    <form method="post"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $c['id'] ?>"><input type="hidden" name="act" value="delete_code"><button class="btn btn-sm btn-bad" type="submit">حذف کامل کد</button></form>
  </div>
</details></td></tr>
<?php endforeach; if (!$list): ?><tr><td colspan="7" class="muted"><?= $qs !== '' ? 'چیزی پیدا نشد.' : 'هنوز کدی صادر نشده است.' ?></td></tr><?php endif; ?></tbody></table></div>
<p class="hint">همه‌ی عملیات روی کد (به‌جز یادداشت و صدور کد تازه) نیاز به تایید دومرحله‌ای دارند: اول درخواست را می‌فرستی، بعد در جعبه‌ی بالای صفحه تایید می‌کنی.</p>
<?php page_foot(['admin' => 1]); ?>
