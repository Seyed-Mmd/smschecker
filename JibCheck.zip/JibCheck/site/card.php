<?php
require __DIR__ . '/inc/bootstrap.php';
$u = require_user();
$id = (int) get('id');
$o = row('SELECT * FROM orders WHERE id=? AND user_id=? AND method=?', [$id, $u['id'], 'card']);
if (!$o) { flash('سفارش پیدا نشد.', 'bad'); redirect(u('panel.php')); }

if ($_SERVER['REQUEST_METHOD'] === 'POST' && in_array($o['status'], ['pending_payment', 'rejected', 'awaiting_review'], true)) {
    csrf_check();
    $f = $_FILES['receipt'] ?? null;
    if (!$f || $f['error'] !== UPLOAD_ERR_OK) flash('فایل رسید انتخاب نشد یا آپلود ناموفق بود.', 'bad');
    elseif ($f['size'] > 4 * 1024 * 1024) flash('حجم عکس رسید باید کمتر از ۴ مگابایت باشد.', 'bad');
    else {
        $mime = (new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);
        $ext = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'][$mime] ?? null;
        if (!$ext || !@getimagesize($f['tmp_name'])) flash('فقط عکس رسید (JPG، PNG یا WEBP) قابل قبول است.', 'bad');
        else {
            $dir = JC_ROOT . '/storage/receipts';
            if (!is_dir($dir)) @mkdir($dir, 0755, true);
            $name = $o['id'] . '_' . bin2hex(random_bytes(10)) . '.' . $ext;
            if (!move_uploaded_file($f['tmp_name'], "$dir/$name")) flash('ذخیره‌ی فایل انجام نشد. دوباره امتحان کن.', 'bad');
            else {
                if ($o['receipt_file']) @unlink("$dir/" . basename($o['receipt_file']));
                $first = $o['status'] !== 'awaiting_review';
                update('orders', ['receipt_file' => $name, 'status' => 'awaiting_review', 'note' => null, 'updated_at' => time()], 'id=?', [$o['id']]);
                if ($first) notify_admin('admin_order', (string) $o['id']);
                flash('رسید دریافت شد. بعد از بررسی، کد فعال‌سازی برایت پیامک می‌شود.', 'ok');
            }
        }
    }
    redirect(u("card.php?id={$o['id']}"));
}
$st = order_status_label($o['status']);
$cardNo = preg_replace('/\D/', '', setting('card_number'));
page_head('پرداخت کارت‌به‌کارت', ['noindex' => 1]);
?>
<div class="card narrow" style="max-width:560px">
  <div class="row between"><h2 style="margin:0">پرداخت کارت‌به‌کارت</h2><?= badge($st[0], $st[1]) ?></div>
  <p class="muted">سفارش شماره <?= fa($o['id']) ?> • مبلغ قابل پرداخت: <b><?= toman($o['amount']) ?></b></p>

  <?php if ($o['status'] === 'approved'): ?>
    <div class="alert ok">پرداخت تایید شد. کد فعال‌سازی را در پنل من ببین.</div><p><a class="btn" href="<?= e(u('panel.php')) ?>">رفتن به پنل من</a></p>
  <?php else: ?>
    <?php if ($o['status'] === 'rejected'): ?><div class="alert bad">رسید رد شد<?= $o['note'] ? ': ' . e($o['note']) : '.' ?> لطفاً رسید درست را دوباره آپلود کن.</div><?php endif; ?>
    <?php if ($o['status'] !== 'awaiting_review'): ?>
      <ol>
        <li>مبلغ <b><?= toman($o['amount']) ?></b> را به کارت زیر واریز کن.</li>
        <li>از رسید پرداخت (اسکرین‌شات یا عکس) تصویر بگیر.</li>
        <li>تصویر رسید را همین‌جا آپلود کن.</li>
      </ol>
    <?php endif; ?>
    <div class="codebox" style="font-size:1.35rem"><span><?= e(trim(chunk_split($cardNo, 4, ' '))) ?></span><button type="button" data-copy="<?= e($cardNo) ?>">کپی شماره کارت</button></div>
    <dl class="kv" style="margin-top:12px">
      <?php if (setting('card_holder') !== ''): ?><dt>به نام</dt><dd><?= e(setting('card_holder')) ?></dd><?php endif; ?>
      <?php if (setting('card_bank') !== ''): ?><dt>بانک</dt><dd><?= e(setting('card_bank')) ?></dd><?php endif; ?>
    </dl>

    <?php if ($o['status'] === 'awaiting_review'): ?>
      <div class="alert info">رسید تو دریافت شد و منتظر تایید ادمین است. بعد از تایید، کد فعال‌سازی برایت پیامک می‌شود و در پنل من هم دیده می‌شود.</div>
      <p><img src="<?= e(u('receipt.php?id=' . $o['id'])) ?>" alt="رسید" style="max-height:260px;border-radius:12px;border:1px solid var(--ln)"></p>
      <details><summary class="hint" style="cursor:pointer">رسید اشتباه بود؟ آپلود دوباره</summary>
    <?php endif; ?>
    <form method="post" enctype="multipart/form-data" data-once><?= csrf_field() ?>
      <label>عکس رسید کارت‌به‌کارت (JPG، PNG یا WEBP — حداکثر ۴ مگابایت)</label>
      <input type="file" name="receipt" accept="image/jpeg,image/png,image/webp" required>
      <p><button class="btn btn-wide" type="submit">ارسال رسید</button></p>
    </form>
    <?php if ($o['status'] === 'awaiting_review'): ?></details><?php endif; ?>
  <?php endif; ?>
  <p class="hint">مشکلی پیش آمد؟ از <a href="<?= e(u('ticket.php')) ?>">پشتیبانی</a> تیکت بفرست و شماره سفارش را بنویس.</p>
</div>
<?php page_foot(); ?>
