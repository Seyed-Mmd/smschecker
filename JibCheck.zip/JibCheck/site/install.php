<?php
// نصب‌کننده: فقط یک‌بار اجرا می‌شود و بعد از نصب خودش را قفل/حذف می‌کند
define('JC_ROOT', __DIR__);
header('Content-Type: text/html; charset=utf-8');
if (is_file(JC_ROOT . '/config.php')) { http_response_code(403); exit('<p dir="rtl" style="font-family:tahoma;padding:2em">سایت قبلاً نصب شده است. برای امنیت، فایل install.php را از هاست پاک کنید.</p>'); }
session_start();
require_once JC_ROOT . '/inc/db.php';
require_once JC_ROOT . '/inc/helpers.php';
$err = ''; $done = false;
$https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
$guess = ($https ? 'https' : 'http') . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost') . rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\');
$v = fn($k, $d = '') => htmlspecialchars((string) ($_POST[$k] ?? $d), ENT_QUOTES, 'UTF-8');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $t = $_POST['_t'] ?? '';
    if (!is_string($t) || !hash_equals($_SESSION['csrf'] ?? '', $t)) $err = 'درخواست نامعتبر است؛ صفحه را دوباره باز کن.';
    else {
        try {
            $driver = ($_POST['driver'] ?? 'mysql') === 'sqlite' ? 'sqlite' : 'mysql';
            $site = rtrim(trim($_POST['site_url'] ?? ''), '/');
            $user = trim($_POST['admin_user'] ?? ''); $pass = (string) ($_POST['admin_pass'] ?? '');
            if (!preg_match('~^https?://[^\s]+$~', $site)) throw new Exception('آدرس سایت درست نیست (مثال: https://jibcheck.ir).');
            if (!preg_match('/^[A-Za-z0-9_.-]{3,30}$/', $user)) throw new Exception('نام کاربری ادمین باید ۳ تا ۳۰ حرف انگلیسی/عدد باشد.');
            if (strlen($pass) < 8) throw new Exception('رمز عبور ادمین باید حداقل ۸ کاراکتر باشد.');
            $db = ['driver' => $driver, 'host' => trim($_POST['db_host'] ?? 'localhost'), 'name' => trim($_POST['db_name'] ?? ''),
                   'user' => trim($_POST['db_user'] ?? ''), 'pass' => (string) ($_POST['db_pass'] ?? ''), 'sqlite_path' => JC_ROOT . '/storage/data.sqlite'];
            if ($driver === 'mysql' && ($db['name'] === '' || $db['user'] === '')) throw new Exception('نام پایگاه داده و کاربر آن را وارد کن.');
            $CFG = ['db' => $db, 'site_url' => $site];
            foreach (['storage', 'storage/receipts', 'storage/tickets', 'c'] as $d) if (!is_dir(JC_ROOT . "/$d")) @mkdir(JC_ROOT . "/$d", 0755, true);
            foreach (schema_sql($driver) as $sql) { try { db()->exec($sql); } catch (PDOException $e) { if (stripos($e->getMessage(), 'already exists') === false && stripos($e->getMessage(), 'Duplicate') === false) throw $e; } }
            q('DELETE FROM admins'); insert('admins', ['username' => $user, 'pass_hash' => password_hash($pass, PASSWORD_DEFAULT)]);
            if ($driver === 'sqlite') @chmod($db['sqlite_path'], 0600);
            $cfg = "<?php\nreturn " . var_export(['db' => $db, 'site_url' => $site, 'secret' => bin2hex(random_bytes(32)), 'dev_mode' => false], true) . ";\n";
            if (file_put_contents(JC_ROOT . '/config.php', $cfg, LOCK_EX) === false) throw new Exception('نوشتن config.php ممکن نشد؛ دسترسی نوشتن پوشه را بررسی کن.');
            @chmod(JC_ROOT . '/config.php', 0640);
            $done = true;
            @unlink(__FILE__);
        } catch (Throwable $e) { $err = 'نصب انجام نشد: ' . $e->getMessage(); }
    }
}
if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(16));
?><!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>نصب جیب‌چک</title>
<link rel="stylesheet" href="assets/style.css"></head><body><main class="wrap main">
<div class="card narrow" style="max-width:560px"><h2>نصب سایت جیب‌چک</h2>
<?php if ($done): ?>
  <div class="alert ok">نصب با موفقیت انجام شد 🎉</div>
  <p>فایل <b>install.php</b> خودکار حذف شد (اگر هنوز روی هاست هست، خودت پاکش کن).</p>
  <p><a class="btn" href="admin/login.php">ورود به پنل مدیریت</a></p>
  <p class="hint">قدم بعد: در «تنظیمات»، اطلاعات SMS.ir، درگاه یا کارت، قیمت و شماره ادمین را وارد کن.</p>
<?php else: ?>
  <?php if ($err): ?><div class="alert bad"><?= htmlspecialchars($err) ?></div><?php endif; ?>
  <form method="post"><input type="hidden" name="_t" value="<?= htmlspecialchars($_SESSION['csrf']) ?>">
    <label>آدرس سایت (با https)</label><input type="text" name="site_url" class="ltr" value="<?= $v('site_url', $guess) ?>" required>
    <label>نوع پایگاه داده</label><select name="driver"><option value="mysql">MySQL (پیشنهادی، در cPanel/DirectAdmin بسازید)</option><option value="sqlite" <?= ($_POST['driver'] ?? '') === 'sqlite' ? 'selected' : '' ?>>SQLite (بدون نیاز به تنظیمات)</option></select>
    <label>MySQL: میزبان</label><input type="text" name="db_host" class="ltr" value="<?= $v('db_host', 'localhost') ?>">
    <label>MySQL: نام پایگاه داده</label><input type="text" name="db_name" class="ltr" value="<?= $v('db_name') ?>">
    <label>MySQL: نام کاربری</label><input type="text" name="db_user" class="ltr" value="<?= $v('db_user') ?>">
    <label>MySQL: رمز عبور</label><input type="password" name="db_pass" class="ltr">
    <hr style="border:0;border-top:1px solid var(--ln);margin:18px 0">
    <label>نام کاربری ادمین</label><input type="text" name="admin_user" class="ltr" value="<?= $v('admin_user', 'admin') ?>" required>
    <label>رمز عبور ادمین (حداقل ۸ کاراکتر)</label><input type="password" name="admin_pass" class="ltr" required>
    <p><button class="btn btn-wide" type="submit">نصب</button></p>
  </form>
<?php endif; ?></div></main></body></html>
