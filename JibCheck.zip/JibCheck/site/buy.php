<?php
require __DIR__ . '/inc/bootstrap.php';
$u = require_user();
$plans = rows('SELECT * FROM plans WHERE active=1 ORDER BY sort_order ASC, id ASC');
if (!$plans) { page_head('خرید کد فعال‌سازی', ['noindex' => 1]); echo '<div class="alert warn">در حال حاضر هیچ پلن خریدی فعال نیست. از بخش پشتیبانی پیگیری کن.</div>'; page_foot(); exit; }

if (isset($_GET['plan'])) {   // انتخاب پلن با لینک ساده (بدون نیاز به جاوااسکریپت)؛ بعد آدرس تمیز می‌شود
    $pid = (int) $_GET['plan'];
    if (in_array($pid, array_column($plans, 'id'), true)) $_SESSION['buy_plan'] = $pid;
    redirect(u('buy.php'));
}
$plan = null;
foreach ($plans as $pl) if ((int) $pl['id'] === (int) ($_SESSION['buy_plan'] ?? 0)) $plan = $pl;
$plan ??= $plans[0];
$_SESSION['buy_plan'] = (int) $plan['id'];

$price = (int) $plan['price']; $pdays = (int) $plan['days']; $max = max(1, (int) $plan['max_uses']);
$gw = setting('pay_gateway_on') === '1' && setting('zarinpal_merchant') !== '';
$cd = setting('pay_card_on') === '1' && preg_replace('/\D/', '', setting('card_number')) !== '';
function plan_validity(int $days): string { return $days > 0 ? ($days % 365 === 0 ? fa($days / 365) . ' ساله' : fa($days) . ' روزه') : 'نامحدود'; }
$validity = plan_validity($pdays);

// کد تخفیف اعمال‌شده (در نشست نگه داشته می‌شود و هر بار دوباره اعتبارسنجی می‌شود)
$cp = null;
if (!empty($_SESSION['coupon'])) {
    $c = coupon_find((string) $_SESSION['coupon']);
    $err = $c ? coupon_error($c, (int) $u['id']) : 'کد تخفیف دیگر معتبر نیست.';
    if (!$err) $cp = $c;
    else { unset($_SESSION['coupon']); if ($c) flash($err, 'bad'); }
}
[$final, $disc] = $cp ? coupon_apply($price, $cp) : [$price, 0];
$free = $final === 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $act = post('act');
    if ($act === 'coupon') {
        if (post('coupon') === '') flash('کد تخفیف را وارد کن.', 'bad');
        elseif (rate_count('coupon:' . $u['id'], 3600) >= 10) flash('تعداد تلاش‌ها زیاد بود. کمی بعد دوباره امتحان کن.', 'bad');
        else {
            $c = coupon_find(post('coupon'));
            $err = $c ? coupon_error($c, (int) $u['id']) : 'این کد تخفیف وجود ندارد.';
            if ($err) { rate_hit('coupon:' . $u['id']); flash($err, 'bad'); }
            else { $_SESSION['coupon'] = $c['code']; flash('کد تخفیف اعمال شد.', 'ok'); }
        }
        redirect(u('buy.php'));
    }
    if ($act === 'coupon_remove') { unset($_SESSION['coupon']); redirect(u('buy.php')); }

    $m = $free ? 'coupon' : post('method');
    if (post('terms') !== '1') flash('برای ادامه باید قوانین را بپذیری.', 'bad');
    elseif (!$free && !(($m === 'gateway' && $gw) || ($m === 'card' && $cd))) flash('روش پرداخت انتخاب‌شده در دسترس نیست.', 'bad');
    elseif (rate_count('order:' . $u['id'], 3600) >= 10) flash('تعداد سفارش‌ها در این ساعت زیاد بود. کمی بعد دوباره امتحان کن.', 'bad');
    else {
        rate_hit('order:' . $u['id']);
        $oid = insert('orders', ['user_id' => $u['id'], 'amount' => $final, 'orig_amount' => $price, 'discount' => $disc, 'coupon_id' => $cp ? (int) $cp['id'] : null,
            'plan_id' => (int) $plan['id'], 'plan_days' => $pdays, 'plan_max_uses' => $max, 'plan_name' => $plan['name'],
            'method' => $m, 'status' => 'pending_payment', 'created_at' => time(), 'updated_at' => time()]);
        if ($free) {   // تخفیف ۱۰۰٪: بدون پرداخت، کد همین الان صادر می‌شود
            approve_order($oid); unset($_SESSION['coupon']);
            flash('کد فعال‌سازی صادر شد و برایت پیامک شد.', 'ok');
            redirect(u('panel.php'));
        }
        if ($m === 'card') redirect(u("card.php?id=$oid"));
        // درگاه زرین‌پال (مبلغ به ریال)
        $ch = curl_init('https://payment.zarinpal.com/pg/v4/payment/request.json');
        curl_setopt_array($ch, [CURLOPT_POST => true, CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 15,
            CURLOPT_HTTPHEADER => ['Content-Type: application/json', 'Accept: application/json'],
            CURLOPT_POSTFIELDS => json_encode(['merchant_id' => setting('zarinpal_merchant'), 'amount' => $final * 10,
                'callback_url' => site_url("callback.php?o=$oid"), 'description' => 'خرید کد فعال‌سازی جیب‌چک (' . $plan['name'] . ')', 'metadata' => ['mobile' => $u['mobile']]], JSON_UNESCAPED_UNICODE)]);
        $res = curl_exec($ch); curl_close($ch);
        $j = json_decode((string) $res, true);
        $auth = $j['data']['authority'] ?? '';
        if (is_array($j) && (int) ($j['data']['code'] ?? 0) === 100 && $auth !== '') {
            update('orders', ['authority' => $auth, 'updated_at' => time()], 'id=?', [$oid]);
            redirect('https://payment.zarinpal.com/pg/StartPay/' . rawurlencode($auth));
        }
        update('orders', ['status' => 'failed', 'note' => 'خطا در اتصال به درگاه', 'updated_at' => time()], 'id=?', [$oid]);
        app_log('Zarinpal request failed: ' . $res);
        flash('اتصال به درگاه پرداخت انجام نشد. دوباره امتحان کن یا روش کارت‌به‌کارت را انتخاب کن.', 'bad');
    }
    redirect(u('buy.php'));
}
page_head('خرید کد فعال‌سازی', ['noindex' => 1]);
?>
<?php if (count($plans) > 1): ?>
<h2>نوع اشتراک را انتخاب کن</h2>
<div class="plans">
  <?php foreach ($plans as $pl): $sel = (int) $pl['id'] === (int) $plan['id']; ?>
  <a class="plan<?= $sel ? ' sel' : '' ?>" href="<?= e(u('buy.php?plan=' . $pl['id'])) ?>">
    <b class="plan-name"><?= e($pl['name']) ?></b>
    <span class="plan-price"><?= toman($pl['price']) ?></span>
    <span class="plan-sub"><?= e(plan_validity((int) $pl['days'])) ?> • حداکثر <?= fa(max(1, (int) $pl['max_uses'])) ?> گوشی</span>
  </a>
  <?php endforeach; ?>
</div>
<?php endif; ?>
<div class="grid g2" style="align-items:start">
  <div class="card anim-in">
    <h2><?= e($plan['name']) ?></h2>
    <div class="price"><?php if ($disc > 0): ?><s class="muted" style="font-size:.55em"><?= toman($price) ?></s> <?php endif; ?><?= $free ? 'رایگان' : toman($final) ?></div>
    <ul class="ticks">
      <li>اعتبار: <?= e($validity) ?></li>
      <li>هر کد حداکثر <b><?= fa($max) ?> بار</b> قابل وارد کردن (فعال‌سازی) است؛ یعنی روی حداکثر <?= fa($max) ?> گوشی.</li>
      <li>وارد کردن دوباره‌ی کد روی همان گوشی، ظرفیت جدید مصرف نمی‌کند.</li>
      <li>بعد از تایید پرداخت، کد برایت پیامک می‌شود و در «پنل من» هم هست.</li>
      <li>این برنامه فقط روی گوشی‌های اندرویدی (نسخه ۸ به بالا) کار می‌کند.</li>
    </ul>
    <?php if (setting('buy_note') !== ''): ?><div class="alert info"><?= nl2br(e(setting('buy_note'))) ?></div><?php endif; ?>
  </div>
  <div class="card anim-in" style="animation-delay:.08s">
    <h2>کد تخفیف</h2>
    <?php if ($cp): ?>
      <div class="alert ok row between"><span>کد <b class="ltr" style="display:inline-block"><?= e($cp['code']) ?></b> اعمال شد: <?= e(coupon_desc($cp)) ?><?= $disc > 0 ? ' (' . toman($disc) . ' کم شد)' : '' ?></span>
        <form method="post"><?= csrf_field() ?><input type="hidden" name="act" value="coupon_remove"><button class="btn btn-sm btn-ghost" type="submit">حذف</button></form></div>
    <?php else: ?>
      <form method="post" class="row"><?= csrf_field() ?><input type="hidden" name="act" value="coupon">
        <input type="text" name="coupon" class="ltr" placeholder="کد تخفیف (اختیاری)" autocomplete="off" style="max-width:240px"><button class="btn btn-sm btn-ghost" type="submit">اعمال</button></form>
    <?php endif; ?>
    <hr style="border:0;border-top:1px solid var(--ln);margin:18px 0">
    <h2><?= $free ? 'دریافت کد' : 'روش پرداخت' ?></h2>
    <?php if (!$free && !$gw && !$cd): ?>
      <div class="alert warn">در حال حاضر امکان خرید فعال نیست. لطفاً کمی بعد دوباره سر بزن یا از بخش پشتیبانی پیگیری کن.</div>
    <?php else: ?>
    <form method="post" data-once><?= csrf_field() ?>
      <?php if ($free): ?><div class="alert info">با این کد تخفیف نیازی به پرداخت نیست؛ کد فعال‌سازی بلافاصله برایت صادر می‌شود.</div><?php endif; ?>
      <?php if (!$free && $gw): ?><label class="check"><input type="radio" name="method" value="gateway" <?= $cd ? '' : 'checked' ?> required><span><b>درگاه پرداخت اینترنتی</b><br><span class="muted">پرداخت آنلاین با کارت بانکی؛ کد بلافاصله بعد از پرداخت صادر می‌شود.</span></span></label><?php endif; ?>
      <?php if (!$free && $cd): ?><label class="check"><input type="radio" name="method" value="card" <?= $gw ? '' : 'checked' ?> required><span><b>کارت‌به‌کارت</b><br><span class="muted">مبلغ را به کارت ما واریز می‌کنی و رسید را آپلود می‌کنی؛ بعد از تایید ادمین، کد برایت ارسال می‌شود.</span></span></label><?php endif; ?>
      <label class="check"><input type="checkbox" name="terms" value="1" required><span>با <a href="<?= e(u('terms.php')) ?>" target="_blank">قوانین و حریم خصوصی</a> موافقم و می‌دانم هر کد حداکثر <?= fa($max) ?> بار قابل فعال‌سازی است.</span></label>
      <p><button class="btn btn-wide" type="submit"><?= $free ? 'دریافت رایگان کد فعال‌سازی' : 'ادامه و پرداخت ' . toman($final) ?></button></p>
    </form>
    <?php endif; ?>
    <p class="hint">شماره‌ی وارد شده: <span class="ltr" style="display:inline-block"><?= e(fa($u['mobile'])) ?></span> — کد به همین شماره پیامک می‌شود.</p>
  </div>
</div>
<?php page_foot(); ?>
