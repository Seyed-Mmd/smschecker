<?php
require __DIR__ . '/inc/bootstrap.php';
$plans = rows('SELECT * FROM plans WHERE active=1 ORDER BY sort_order ASC, id ASC');
function plan_validity(int $days): string { return $days > 0 ? ($days % 365 === 0 ? fa($days / 365) . ' ساله' : fa($days) . ' روزه') : 'نامحدود'; }
$dl = setting('app_download_url');
page_head(setting('site_name'), ['body' => 'landing']);
?>
<section class="hero">
  <div>
    <h1>هزینه‌هایت را خودکار از روی پیامک بانک ثبت کن</h1>
    <p>هر بار که بانک برایت پیامک می‌فرستد، جیب‌چک تراکنش را می‌خواند و با یک لمس دسته‌بندی می‌کند. بدون وارد کردن دستی، بدون ارسال اطلاعاتت به جایی دیگر.</p>
    <div class="row"><a class="btn" href="<?= e(u('buy.php')) ?>">خرید کد فعال‌سازی</a><a class="btn btn-ghost" href="#features">ویژگی‌ها</a></div>
    <div class="pills"><span>ثبت خودکار</span><span>داده‌ها فقط روی گوشی</span><span>تاریخ شمسی</span><span>حالت تاریک</span></div>
  </div>
  <div class="center">
    <div class="phone" style="margin:0 auto"><div class="scr">
      <div class="m-hero"><small>هزینه این ماه</small><b>۱۲٬۴۵۰٬۰۰۰ تومان</b><div class="m-bar"><i></i></div><small>۶۲٪ از بودجه • مانده ۷٬۵۵۰٬۰۰۰ تومان</small></div>
      <div class="m-card"><div class="m-t">در انتظار ثبت</div>
        <div class="m-li"><div class="o" style="background:#F04438">－</div><div class="t">خرید اینترنتی<small>بانک ملت</small></div><b>۳۷۳٬۰۹۹ تومان</b></div></div>
      <div class="m-card"><div class="m-t">هزینه به تفکیک دسته</div>
        <div class="m-b"><div><span>خوراک</span><span>۴٬۷۰۰٬۰۰۰</span></div><i style="width:90%;background:#4263EB"></i></div>
        <div class="m-b"><div><span>حمل‌ونقل</span><span>۲٬۹۰۰٬۰۰۰</span></div><i style="width:60%;background:#12B76A"></i></div></div>
    </div><div class="m-fab">＋</div><div class="nav"><div class="on"><i>🏠</i>خانه</div><div><i>📋</i>تراکنش‌ها</div><div><i>📊</i>آمار</div><div><i>⚙️</i>تنظیمات</div></div></div>
  </div>
</section>

<section class="sec">
  <h2>چطور کار می‌کند؟</h2><p class="sub">در چهار قدم ساده، از خرید تا ثبت اولین تراکنش.</p>
  <div class="grid g4">
    <div class="card step"><div class="n">۱</div><h3>کد را بخر</h3><p>با درگاه پرداخت یا کارت‌به‌کارت. کد فعال‌سازی پیامک می‌شود و در پنل کاربری هم هست.</p></div>
    <div class="card step"><div class="n">۲</div><h3>برنامه را فعال کن</h3><p>جیب‌چک را نصب کن و کد را وارد کن. فقط همین یک‌بار اینترنت لازم است.</p></div>
    <div class="card step"><div class="n">۳</div><h3>مجوزها را بده</h3><p>برنامه قدم‌به‌قدم مجوزهای پیامک، نمایش روی برنامه‌ها و باتری را راهنمایی می‌کند.</p></div>
    <div class="card step"><div class="n">۴</div><h3>تمام!</h3><p>با هر پیامک بانک، پنجره‌ی کوچکی باز می‌شود و تو فقط دسته را انتخاب می‌کنی.</p></div>
  </div>
</section>

<section class="sec" id="features">
  <h2>هر چیزی که برای مدیریت خرج لازم داری</h2><p class="sub">ساده برای استفاده‌ی روزانه، قدرتمند برای گزارش‌گیری.</p>
  <div class="grid g3">
    <?php foreach ([
      ['📩','ثبت خودکار از پیامک','پیامک برداشت، واریز و خرید بانکی را می‌خواند و مبلغ و پذیرنده را خودش پیدا می‌کند.'],
      ['⚡','ثبت با یک لمس','بعد از باز کردن قفل گوشی، پنجره‌ی سریع «این چی بود؟» نشان داده می‌شود؛ دسته را بزن و تمام.'],
      ['🏷️','دسته‌بندی هوشمند','برای فروشگاه‌های تکراری، دسته‌ی قبلی خودکار پیشنهاد می‌شود. دسته‌ها را هر طور خواستی بساز.'],
      ['📊','گزارش و نمودار','نمودار دایره‌ای دسته‌ها، روند روزانه، مقایسه با دوره‌ی قبل و بزرگ‌ترین هزینه‌ها.'],
      ['🎯','بودجه ماهانه','سقف خرج ماه را بنویس و پیشرفتت را همیشه در صفحه‌ی خانه ببین.'],
      ['🏦','چند بانک، هر فرمتی','فرمت پیامک هر بانک را یک‌بار از روی نمونه یاد می‌دهی. فرمت بانک بلو آماده است.'],
      ['🔎','جست‌وجو و فیلتر','جست‌وجو در توضیح و پذیرنده، فیلتر بر اساس دسته، بانک و حتی تراکنش‌های «بدون دسته».'],
      ['💾','پشتیبان‌گیری و بازیابی','خروجی CSV و بازگردانی از CSV یا Excel؛ اگر اشتباهی پاک شد، دوباره برمی‌گردد.'],
      ['📤','گزارش متنی قابل ارسال','فقط دسته‌هایی را که می‌خواهی انتخاب کن و گزارش را برای هر کسی بفرست.'],
      ['🌙','حالت تاریک و تاریخ شمسی','ظاهر هماهنگ با سیستم، فونت وزیرمتن و تاریخ شمسی در همه‌جا.'],
      ['🔒','حریم خصوصی','تراکنش‌ها فقط روی گوشی خودت می‌ماند. برنامه برای فعال‌سازی و پشتیبانی به اینترنت وصل می‌شود، نه برای اطلاعات مالی.'],
      ['🔔','همیشه آماده','راهنمای مجوزها و محدودیت باتری، تا هیچ پیامکی از دست نرود.'],
    ] as [$ic, $t, $d]): ?>
    <div class="card feat"><div class="ic"><?= $ic ?></div><div><h3><?= e($t) ?></h3><p><?= e($d) ?></p></div></div>
    <?php endforeach; ?>
  </div>
</section>

<section class="sec">
  <h2>نگاهی به برنامه</h2><p class="sub">بخش‌های اصلی جیب‌چک (نمونه‌ی نمایشی).</p>
  <div class="shots">
    <div class="shot"><div class="phone"><div class="scr">
      <div class="m-hero"><small>هزینه این ماه</small><b>۱۲٬۴۵۰٬۰۰۰ تومان</b><div class="m-bar"><i></i></div><small>درآمد: ۲۰٬۰۰۰٬۰۰۰ • تراز: ۷٬۵۵۰٬۰۰۰</small></div>
      <div class="m-card"><div class="m-t">آخرین تراکنش‌ها</div>
        <div class="m-li"><div class="o" style="background:#F04438">－</div><div class="t">اسنپ<small>حمل‌ونقل • ملت</small></div><b>۱۸۵٬۰۰۰</b></div>
        <div class="m-li"><div class="o" style="background:#12B76A">＋</div><div class="t">واریز حقوق<small>بلو</small></div><b>۲۰٬۰۰۰٬۰۰۰</b></div>
        <div class="m-li"><div class="o" style="background:#F04438">－</div><div class="t">سوپرمارکت<small>خوراک • ملت</small></div><b>۴۲۰٬۰۰۰</b></div></div>
    </div><div class="m-fab">＋</div><div class="nav"><div class="on"><i>🏠</i>خانه</div><div><i>📋</i>تراکنش‌ها</div><div><i>📊</i>آمار</div><div><i>⚙️</i>تنظیمات</div></div></div><span>خانه</span><small>خلاصه‌ی ماه و بودجه</small></div>

    <div class="shot"><div class="phone"><div class="scr">
      <div class="m-t">تراکنش‌ها</div><div class="m-in m-search">جست‌وجو در توضیح، پذیرنده، دسته یا بانک</div>
      <div class="m-ch"><span class="on">همه</span><span>خوراک</span><span>حمل‌ونقل</span><span>قبوض</span><span>بدون دسته</span></div>
      <div class="m-card">
        <div class="m-li"><div class="o" style="background:#F04438">－</div><div class="t">رستوران<small>خوراک • ۱۴۰۵/۰۷/۱۸</small></div><b>۶۵۰٬۰۰۰</b></div>
        <div class="m-li"><div class="o" style="background:#F04438">－</div><div class="t">قبض برق<small>قبوض • ۱۴۰۵/۰۷/۱۶</small></div><b>۳۲۰٬۰۰۰</b></div>
        <div class="m-li"><div class="o" style="background:#12B76A">＋</div><div class="t">واریز<small>بلو • ۱۴۰۵/۰۷/۱۵</small></div><b>۵٬۰۰۰٬۰۰۰</b></div></div>
    </div><div class="m-fab">＋</div><div class="nav"><div><i>🏠</i>خانه</div><div class="on"><i>📋</i>تراکنش‌ها</div><div><i>📊</i>آمار</div><div><i>⚙️</i>تنظیمات</div></div></div><span>تراکنش‌ها</span><small>جست‌وجو و فیلتر</small></div>

    <div class="shot"><div class="phone"><div class="scr">
      <div class="m-t">آمار</div>
      <div class="m-ch"><span class="on">این ماه</span><span>ماه قبل</span><span>۷ روز</span></div>
      <div class="m-card"><div class="m-donut"><i>۱۲٬۴۵۰٬۰۰۰<br>تومان</i></div>
        <div class="m-b"><div><span>● خوراک</span><span>۳۸٪</span></div></div><div class="m-b"><div><span>● حمل‌ونقل</span><span>۲۴٪</span></div></div></div>
      <div class="m-card"><div class="m-t">روند هزینه</div><div style="display:flex;align-items:flex-end;gap:3px;height:40px"><i style="flex:1;height:40%;background:#4263EB;border-radius:2px"></i><i style="flex:1;height:70%;background:#4263EB;border-radius:2px"></i><i style="flex:1;height:30%;background:#4263EB;border-radius:2px"></i><i style="flex:1;height:100%;background:#4263EB;border-radius:2px"></i><i style="flex:1;height:55%;background:#4263EB;border-radius:2px"></i><i style="flex:1;height:80%;background:#4263EB;border-radius:2px"></i></div></div>
    </div><div class="nav"><div><i>🏠</i>خانه</div><div><i>📋</i>تراکنش‌ها</div><div class="on"><i>📊</i>آمار</div><div><i>⚙️</i>تنظیمات</div></div></div><span>آمار</span><small>نمودار و مقایسه‌ی دوره‌ها</small></div>

    <div class="shot"><div class="phone"><div class="scr">
      <div class="m-t">تنظیمات</div>
      <div class="m-card"><div class="m-t">بودجه ماهانه</div><div class="m-in">۲۰٬۰۰۰٬۰۰۰ تومان</div><div class="m-pill">ذخیره بودجه</div></div>
      <div class="m-card"><div class="m-t">بانک‌ها و فرمت پیامک</div><div class="m-pill g">مدیریت بانک‌ها و فرمت‌ها</div></div>
      <div class="m-card"><div class="m-t">پشتیبان‌گیری</div><div class="m-pill g">ارسال همه تراکنش‌ها (CSV)</div><div class="m-pill">📥 بازیابی از فایل</div></div>
    </div><div class="nav"><div><i>🏠</i>خانه</div><div><i>📋</i>تراکنش‌ها</div><div><i>📊</i>آمار</div><div class="on"><i>⚙️</i>تنظیمات</div></div></div><span>تنظیمات</span><small>بودجه، بانک‌ها و پشتیبان</small></div>
  </div>
</section>

<section class="sec" id="price">
  <h2>خرید کد فعال‌سازی</h2><p class="sub">یک‌بار پرداخت، بدون اشتراک ماهانه؛ هر مدتی که نیاز داری انتخاب کن.</p>
  <div class="grid g3" style="max-width:980px;margin:0 auto">
  <?php foreach ($plans as $i => $pl): ?>
  <div class="card price-card anim-in" style="animation-delay:<?= $i * .08 ?>s">
    <div class="muted" style="font-weight:700"><?= e($pl['name']) ?></div>
    <div class="price"><?= toman($pl['price']) ?></div>
    <div class="muted">اعتبار <?= e(plan_validity((int) $pl['days'])) ?></div>
    <ul class="ticks">
      <li>یک کد فعال‌سازی اختصاصی</li>
      <li>فعال‌سازی روی حداکثر <?= fa(max(1, (int) $pl['max_uses'])) ?> گوشی</li>
      <li>پرداخت امن با درگاه یا کارت‌به‌کارت</li>
      <li>ارسال کد با پیامک و نمایش در پنل کاربری</li>
    </ul>
    <a class="btn btn-wide" href="<?= e(u('buy.php?plan=' . $pl['id'])) ?>">خرید</a>
  </div>
  <?php endforeach; if (!$plans): ?><div class="card price-card">در حال حاضر خریدی فعال نیست.</div><?php endif; ?>
  </div>
  <?php if ($dl): ?><p class="hint center" style="margin-top:14px"><a href="<?= e($dl) ?>" rel="noopener">دانلود برنامه</a></p><?php endif; ?>
</section>

<section class="sec">
  <h2>سؤال‌های پرتکرار</h2><p class="sub"></p>
  <div style="max-width:760px;margin:0 auto">
    <details class="faq"><summary>آیا اطلاعات مالی من جایی ارسال می‌شود؟</summary><p>خیر. تراکنش‌ها و پیامک‌های بانکی فقط روی گوشی خودت ذخیره می‌شوند. برنامه فقط برای فعال‌سازی، بررسی اعتبار کد و پشتیبانی به اینترنت وصل می‌شود و در آن فقط کد فعال‌سازی و یک شناسه‌ی ناشناس دستگاه به سرور می‌رسد.</p></details>
    <details class="faq"><summary>کد فعال‌سازی را چطور دریافت می‌کنم؟</summary><p>بعد از تایید پرداخت، کد برایت پیامک می‌شود و در «پنل من» هم قابل دیدن است. پرداخت با درگاه بلافاصله تایید می‌شود؛ کارت‌به‌کارت بعد از بررسی رسید توسط ادمین.</p></details>
    <details class="faq"><summary>«حداکثر چند بار فعال‌سازی» یعنی چه؟</summary><p>هر کد را می‌شود روی حداکثر چند گوشی (بسته به پلنی که می‌خری) فعال کرد. وارد کردن دوباره‌ی کد روی همان گوشی (مثلاً بعد از نصب مجدد) ظرفیت جدید مصرف نمی‌کند. تعداد دفعات باقی‌مانده را در پنل کاربری می‌بینی.</p></details>
    <details class="faq"><summary>اگر گوشی‌ام را عوض کنم چه؟</summary><p>اگر هنوز ظرفیت فعال‌سازی داری، کد را روی گوشی جدید وارد کن. اگر ظرفیت تمام شده بود، از بخش پشتیبانی تیکت بفرست.</p></details>
    <details class="faq"><summary>با کدام بانک‌ها کار می‌کند؟</summary><p>با هر بانکی که برایت پیامک تراکنش می‌فرستد. فرمت پیامک بانک بلو آماده است و برای بانک‌های دیگر، یک نمونه پیامک را به برنامه نشان می‌دهی تا فرمتش را یاد بگیرد.</p></details>
    <details class="faq"><summary>روی آیفون هم کار می‌کند؟</summary><p>فعلاً فقط برای گوشی‌های اندرویدی (نسخه ۸ به بالا) ارائه می‌شود، چون خواندن پیامک در iOS ممکن نیست.</p></details>
    <details class="faq"><summary>چرا به مجوز پیامک و باتری نیاز دارد؟</summary><p>برای ثبت خودکار، برنامه باید پیامک بانکی را دریافت کند و در پس‌زمینه زنده بماند. فقط پیامک‌هایی که شبیه تراکنش بانکی باشند پردازش می‌شوند و بقیه ذخیره نمی‌شوند.</p></details>
  </div>
</section>

<section class="cta"><h2>آماده‌ای خرج‌هایت را مرتب کنی؟</h2><p>امروز شروع کن؛ از پیامک بعدی بانک، همه‌چیز خودکار ثبت می‌شود.</p><a class="btn" href="<?= e(u('buy.php')) ?>">خرید کد فعال‌سازی</a></section>
<?php page_foot(); ?>
