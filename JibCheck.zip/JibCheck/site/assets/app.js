// کپی کردن کد، شمارش معکوس ارسال دوباره‌ی کد ورود، جلوگیری از ثبت دوباره‌ی فرم
document.addEventListener('click', function (ev) {
  var b = ev.target.closest('[data-copy]');
  if (!b) return;
  var text = b.getAttribute('data-copy');
  var done = function () { var o = b.textContent; b.textContent = 'کپی شد ✓'; setTimeout(function () { b.textContent = o; }, 1500); };
  if (navigator.clipboard) navigator.clipboard.writeText(text).then(done); else {
    var t = document.createElement('textarea'); t.value = text; document.body.appendChild(t); t.select();
    try { document.execCommand('copy'); done(); } catch (e) {} document.body.removeChild(t);
  }
});
document.querySelectorAll('[data-countdown]').forEach(function (el) {
  var n = parseInt(el.getAttribute('data-countdown'), 10) || 0, link = document.querySelector(el.getAttribute('data-target'));
  if (link) link.style.display = 'none';
  var iv = setInterval(function () {
    n--; if (n <= 0) { clearInterval(iv); el.style.display = 'none'; if (link) link.style.display = ''; }
    else el.textContent = 'ارسال دوباره‌ی کد تا ' + n.toLocaleString('fa-IR') + ' ثانیه دیگر';
  }, 1000);
});
document.querySelectorAll('form[data-once]').forEach(function (f) {
  f.addEventListener('submit', function () {
    var b = f.querySelector('button[type=submit]'); if (b) { b.disabled = true; b.textContent = 'لطفاً صبر کنید…'; }
  });
});
// پیش‌نمایش عکس‌های پیوست تیکت + بررسی تعداد و حجم قبل از ارسال
document.querySelectorAll('input[type=file][data-images]').forEach(function (inp) {
  var max = parseInt(inp.getAttribute('data-images'), 10) || 3, maxMb = parseFloat(inp.getAttribute('data-maxmb')) || 5;
  var box = inp.parentNode.querySelector('.att-prev');
  inp.addEventListener('change', function () {
    if (box) box.innerHTML = '';
    var files = Array.prototype.slice.call(inp.files || []), err = '';
    if (files.length > max) err = 'حداکثر ' + max.toLocaleString('fa-IR') + ' عکس می‌توانی بفرستی.';
    files.forEach(function (f) { if (f.size > maxMb * 1048576) err = 'حجم هر عکس باید کمتر از ' + maxMb.toLocaleString('fa-IR') + ' مگابایت باشد.'; });
    if (err) { inp.value = ''; if (box) { var m = document.createElement('div'); m.className = 'alert bad'; m.textContent = err; box.appendChild(m); } return; }
    if (!box || !window.URL) return;
    files.forEach(function (f) { var im = document.createElement('img'); im.src = URL.createObjectURL(f); im.alt = ''; box.appendChild(im); });
  });
});
