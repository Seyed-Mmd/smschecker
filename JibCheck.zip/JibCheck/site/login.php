<?php
require __DIR__ . '/inc/bootstrap.php';
if (user()) redirect(u('panel.php'));
$step = isset($_SESSION['otp_mobile']) ? 'verify' : 'mobile';
$err = ''; $ip = client_ip();

function go_next(): never {
    $n = $_SESSION['next'] ?? 'panel.php'; unset($_SESSION['next']);
    $allowed = ['panel.php', 'buy.php', 'ticket.php', 'card.php'];
    $base = explode('?', $n)[0];
    redirect(u(in_array($base, $allowed, true) ? $n : 'panel.php'));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $act = post('act');
    if ($act === 'send') {
        $m = norm_mobile(post('mobile'));
        if (!$m) $err = 'شماره موبایل درست نیست. مثال: ۰۹۱۲۱۲۳۴۵۶۷';
        elseif (rate_count("otp:$m", 3600) >= 5 || rate_count("otpip:$ip", 3600) >= 20) $err = 'تعداد درخواست‌ها زیاد بود. کمی بعد دوباره امتحان کن.';
        else {
            $last = (int) val('SELECT MAX(created_at) FROM otps WHERE mobile=?', [$m]);
            if (time() - $last < 60 && isset($_SESSION['otp_mobile']) && $_SESSION['otp_mobile'] === $m) { $step = 'verify'; }
            else {
                $code = (string) random_int(10000, 99999);
                insert('otps', ['mobile' => $m, 'code_hash' => hash_hmac('sha256', $code, $CFG['secret']), 'expires_at' => time() + 120, 'attempts' => 0, 'created_at' => time()]);
                rate_hit("otp:$m"); rate_hit("otpip:$ip");
                if (sms_send('otp', $m, $code)) { $_SESSION['otp_mobile'] = $m; $_SESSION['otp_sent'] = time(); $step = 'verify'; }
                else $err = 'ارسال پیامک انجام نشد. چند دقیقه بعد دوباره امتحان کن یا از طریق پشتیبانی خبر بده.';
            }
        }
    } elseif ($act === 'verify' && isset($_SESSION['otp_mobile'])) {
        $m = $_SESSION['otp_mobile'];
        $code = preg_replace('/\D/', '', en_digits(post('code')));
        $o = row('SELECT * FROM otps WHERE mobile=? ORDER BY id DESC LIMIT 1', [$m]);
        if (!$o || (int) $o['expires_at'] < time()) $err = 'کد منقضی شده است. دوباره کد بگیر.';
        elseif ((int) $o['attempts'] >= 5) $err = 'تعداد تلاش‌ها بیش از حد بود. دوباره کد بگیر.';
        elseif (!hash_equals($o['code_hash'], hash_hmac('sha256', $code, $CFG['secret']))) {
            q('UPDATE otps SET attempts=attempts+1 WHERE id=?', [$o['id']]);
            $err = 'کد اشتباه است.';
        } else {
            q('DELETE FROM otps WHERE mobile=?', [$m]);
            $u = row('SELECT * FROM users WHERE mobile=?', [$m]);
            $uid = $u ? (int) $u['id'] : insert('users', ['mobile' => $m, 'created_at' => time(), 'last_login' => 0]);
            q('UPDATE users SET last_login=? WHERE id=?', [time(), $uid]);
            $next = $_SESSION['next'] ?? null;
            session_regenerate_id(true);
            $_SESSION = ['uid' => $uid, 'csrf' => bin2hex(random_bytes(16))];
            if ($next) $_SESSION['next'] = $next;
            remember_set($uid);   // یادش بمان؛ دیگر هر بار نیازی به ورود دوباره نیست
            go_next();
        }
        $step = 'verify';
    } elseif ($act === 'change') { unset($_SESSION['otp_mobile']); $step = 'mobile'; }
}

page_head('ورود / ثبت‌نام', ['noindex' => 1]);
?>
<div class="card narrow">
  <?php if ($step === 'mobile'): ?>
    <h2>ورود / ثبت‌نام</h2>
    <p class="muted">شماره موبایلت را بنویس تا کد ورود برایت پیامک شود. نیازی به رمز عبور نیست.</p>
    <?php if ($err): ?><div class="alert bad"><?= e($err) ?></div><?php endif; ?>
    <form method="post" data-once><?= csrf_field() ?><input type="hidden" name="act" value="send">
      <label>شماره موبایل</label><input type="tel" name="mobile" class="ltr" placeholder="09123456789" inputmode="numeric" autocomplete="tel" required autofocus>
      <p><button class="btn btn-wide" type="submit">ارسال کد ورود</button></p>
    </form>
  <?php else: ?>
    <h2>کد ورود را بنویس</h2>
    <p class="muted">کد ۵ رقمی به شماره <b class="ltr" style="display:inline-block"><?= e(fa($_SESSION['otp_mobile'])) ?></b> پیامک شد.</p>
    <?php if ($err): ?><div class="alert bad"><?= e($err) ?></div><?php endif; ?>
    <form method="post"><?= csrf_field() ?><input type="hidden" name="act" value="verify">
      <input type="text" name="code" class="code-in" inputmode="numeric" autocomplete="one-time-code" maxlength="5" placeholder="•••••" required autofocus>
      <p><button class="btn btn-wide" type="submit">ورود</button></p>
    </form>
    <?php $wait = max(0, 60 - (time() - (int) ($_SESSION['otp_sent'] ?? 0))); ?>
    <form method="post" class="center"><?= csrf_field() ?>
      <input type="hidden" name="act" value="send"><input type="hidden" name="mobile" value="<?= e($_SESSION['otp_mobile']) ?>">
      <?php if ($wait > 0): ?><span class="hint" data-countdown="<?= $wait ?>" data-target="#resend">ارسال دوباره‌ی کد تا <?= fa($wait) ?> ثانیه دیگر</span><?php endif; ?>
      <button id="resend" class="btn btn-ghost btn-sm" type="submit">ارسال دوباره‌ی کد</button>
    </form>
    <form method="post" class="center"><?= csrf_field() ?><input type="hidden" name="act" value="change"><button class="btn btn-ghost btn-sm" type="submit" style="margin-top:8px">تغییر شماره</button></form>
  <?php endif; ?>
</div>
<?php page_foot(); ?>
