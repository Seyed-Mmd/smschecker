<?php
// نمایش عکس پیوست تیکت؛ فقط برای ادمین یا صاحب تیکت
require __DIR__ . '/inc/bootstrap.php';
$f = row('SELECT f.file, t.user_id FROM ticket_files f JOIN ticket_msgs m ON m.id=f.msg_id JOIN tickets t ON t.id=m.ticket_id WHERE f.id=?', [(int) get('id')]);
$allowed = $f && (is_admin() || (user() && (int) user()['id'] === (int) $f['user_id']));
if (!$allowed) { http_response_code(404); exit('not found'); }
$path = ticket_dir() . '/' . basename($f['file']);
if (!is_file($path)) { http_response_code(404); exit('not found'); }
$mime = (new finfo(FILEINFO_MIME_TYPE))->file($path);
if (!in_array($mime, ['image/jpeg', 'image/png', 'image/webp'], true)) { http_response_code(404); exit; }
header('Content-Type: ' . $mime); header('Content-Length: ' . filesize($path));
header('Cache-Control: private, max-age=3600'); header('Content-Disposition: inline');
readfile($path);
