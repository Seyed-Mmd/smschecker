<?php
// نمایش عکس رسید؛ فقط برای ادمین یا صاحب سفارش
require __DIR__ . '/inc/bootstrap.php';
$o = row('SELECT * FROM orders WHERE id=?', [(int) get('id')]);
$allowed = $o && $o['receipt_file'] && (is_admin() || (user() && (int) user()['id'] === (int) $o['user_id']));
if (!$allowed) { http_response_code(404); exit('not found'); }
$f = JC_ROOT . '/storage/receipts/' . basename($o['receipt_file']);
if (!is_file($f)) { http_response_code(404); exit('not found'); }
$mime = (new finfo(FILEINFO_MIME_TYPE))->file($f);
if (!in_array($mime, ['image/jpeg', 'image/png', 'image/webp'], true)) { http_response_code(404); exit; }
header('Content-Type: ' . $mime); header('Content-Length: ' . filesize($f));
header('Cache-Control: private, max-age=3600'); header('Content-Disposition: inline');
readfile($f);
