<?php
require __DIR__ . '/inc/bootstrap.php';
$u = require_user();
$id = (int) get('id');
$t = $id ? row('SELECT * FROM tickets WHERE id=? AND user_id=?', [$id, $u['id']]) : null;
if ($id && !$t) { flash('تیکت پیدا نشد.', 'bad'); redirect(u('ticket.php')); }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (upload_overflow()) { flash('حجم کل عکس‌ها بیشتر از حد مجاز سرور است. عکس‌های کوچک‌تر یا کمتری بفرست.', 'bad'); redirect(u($t ? "ticket.php?id={$t['id']}" : 'ticket.php')); }
    csrf_check();
    $act = post('act');
    if ($act === 'new') {
        $sub = mb_substr(post('subject'), 0, 120); $body = mb_substr(post('body'), 0, 3000);
        if (mb_strlen($sub) < 3 || mb_strlen($body) < 5) flash('موضوع و متن پیام را کامل بنویس.', 'bad');
        elseif (rate_count('ticket:' . $u['id'], 86400) >= 5) flash('امروز چند تیکت فرستاده‌ای؛ لطفاً منتظر پاسخ باش یا فردا دوباره تلاش کن.', 'bad');
        else {
            [$imgs, $ierr] = ticket_save_images();
            if ($ierr) flash($ierr, 'bad');
            else {
                rate_hit('ticket:' . $u['id']);
                $tid = insert('tickets', ['user_id' => $u['id'], 'subject' => $sub, 'status' => 'open', 'created_at' => time(), 'updated_at' => time()]);
                $mid = insert('ticket_msgs', ['ticket_id' => $tid, 'is_admin' => 0, 'body' => $body, 'created_at' => time()]);
                ticket_attach($mid, $imgs);
                notify_admin('admin_ticket', (string) $tid);
                flash('تیکت ثبت شد. پاسخ از طریق پیامک به تو اطلاع داده می‌شود.', 'ok');
                redirect(u("ticket.php?id=$tid"));
            }
        }
        redirect(u('ticket.php'));
    } elseif ($t && $act === 'reply') {
        $body = mb_substr(post('body'), 0, 3000);
        if ($t['status'] === 'closed') flash('این تیکت بسته شده و دیگر نمی‌توانی در آن پیام بدهی. اگر هنوز مشکلت حل نشده، یک تیکت تازه بزن.', 'bad');
        elseif (rate_count('treply:' . $u['id'], 3600) >= 20) flash('تعداد پیام‌ها در این ساعت زیاد بود.', 'bad');
        else {
            [$imgs, $ierr] = ticket_save_images();
            if ($ierr) flash($ierr, 'bad');
            elseif (mb_strlen($body) < 2 && !$imgs) flash('متن پیام خالی است.', 'bad');
            else {
                rate_hit('treply:' . $u['id']);
                $mid = insert('ticket_msgs', ['ticket_id' => $t['id'], 'is_admin' => 0, 'body' => $body, 'created_at' => time()]);
                ticket_attach($mid, $imgs);
                update('tickets', ['status' => 'open', 'updated_at' => time()], 'id=?', [$t['id']]);
                notify_admin('admin_ticket', (string) $t['id']);
                flash('پیام ارسال شد.', 'ok');
            }
        }
        redirect(u("ticket.php?id={$t['id']}"));
    } elseif ($t && $act === 'close') {
        update('tickets', ['status' => 'closed', 'updated_at' => time()], 'id=?', [$t['id']]);
        flash('تیکت بسته شد.', 'ok'); redirect(u("ticket.php?id={$t['id']}"));
    }
}
page_head($t ? 'تیکت شماره ' . fa($t['id']) : 'پشتیبانی', ['noindex' => 1]);
if ($t):
    $s = ticket_status_label($t['status']); $msgs = rows('SELECT * FROM ticket_msgs WHERE ticket_id=? ORDER BY id', [$t['id']]); $files = ticket_files_for(array_column($msgs, 'id')); ?>
<p><a href="<?= e(u('ticket.php')) ?>">← همه‌ی تیکت‌ها</a></p>
<div class="card">
  <div class="row between"><h2 style="margin:0"><?= e($t['subject']) ?></h2><?= badge($s[0], $s[1]) ?></div>
  <p class="muted">تیکت شماره <?= fa($t['id']) ?> • <?= jdate((int) $t['created_at'], true) ?></p>
  <?php foreach ($msgs as $m): ?>
    <div class="msg <?= $m['is_admin'] ? 'admin' : 'me' ?>"><small><?= $m['is_admin'] ? 'پشتیبانی جیب‌چک' : 'تو' ?> • <?= jdate((int) $m['created_at'], true) ?></small><?= e($m['body']) ?><?= ticket_images_html($files[$m['id']] ?? []) ?></div>
  <?php endforeach; ?>
  <?php if ($t['status'] !== 'closed'): ?>
  <form method="post" enctype="multipart/form-data" data-once><?= csrf_field() ?><input type="hidden" name="act" value="reply">
    <label>پیام جدید</label><textarea name="body" maxlength="3000"></textarea>
    <?= ticket_image_input() ?>
    <div class="row" style="margin-top:12px"><button class="btn" type="submit">ارسال پیام</button></div>
  </form>
  <form method="post" style="margin-top:10px"><?= csrf_field() ?><input type="hidden" name="act" value="close"><button class="btn btn-ghost btn-sm" type="submit">بستن تیکت</button></form>
  <?php else: ?>
  <div class="alert info">این تیکت بسته شده و دیگر نمی‌توانی در آن پیام بدهی. اگر هنوز مشکلت حل نشده، یک تیکت تازه بزن.</div>
  <p><a class="btn btn-ghost btn-sm" href="<?= e(u('ticket.php')) ?>">ثبت تیکت تازه</a></p>
  <?php endif; ?>
</div>
<?php else:
    $list = rows('SELECT * FROM tickets WHERE user_id=? ORDER BY updated_at DESC', [$u['id']]); ?>
<div class="grid g2" style="align-items:start">
  <div class="card">
    <h2>ارسال تیکت به پشتیبانی</h2>
    <p class="muted"><?= e(setting('support_note')) ?></p>
    <form method="post" enctype="multipart/form-data" data-once><?= csrf_field() ?><input type="hidden" name="act" value="new">
      <label>موضوع</label><input type="text" name="subject" maxlength="120" required placeholder="مثلاً: مشکل در فعال‌سازی کد">
      <label>توضیح مشکل یا سؤال</label><textarea name="body" maxlength="3000" required placeholder="هر چه دقیق‌تر بنویسی، سریع‌تر کمکت می‌کنیم. اگر درباره‌ی سفارش است، شماره‌ی سفارش را بنویس."></textarea>
      <?= ticket_image_input() ?>
      <p><button class="btn btn-wide" type="submit">ارسال تیکت</button></p>
    </form>
  </div>
  <div class="card">
    <h2>تیکت‌های من</h2>
    <?php if (!$list): ?><p class="muted">هنوز تیکتی نفرستاده‌ای.</p><?php endif; ?>
    <?php foreach ($list as $x): $s = ticket_status_label($x['status']); ?>
      <a href="<?= e(u('ticket.php?id=' . $x['id'])) ?>" style="display:block;padding:10px 0;border-bottom:1px solid var(--ln);color:var(--tx)">
        <div class="row between"><b><?= e($x['subject']) ?></b><?= badge($s[0], $s[1]) ?></div>
        <span class="hint">شماره <?= fa($x['id']) ?> • آخرین به‌روزرسانی: <?= jdate((int) $x['updated_at'], true) ?></span></a>
    <?php endforeach; ?>
  </div>
</div>
<?php endif; page_foot(); ?>
