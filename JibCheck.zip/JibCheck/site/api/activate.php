<?php
// API فعال‌سازی برنامه. ورودی JSON: code, device, name
require dirname(__DIR__) . '/inc/bootstrap.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_out(['ok' => false, 'error' => 'method'], 405);
$in = json_decode((string) file_get_contents('php://input'), true);
if (!is_array($in)) json_out(['ok' => false, 'error' => 'invalid'], 400);
$ip = client_ip();
if (rate_count("actfail:$ip", 3600) >= 20) json_out(['ok' => false, 'error' => 'rate'], 429);

$code = code_canonical((string) ($in['code'] ?? ''));
$device = (string) ($in['device'] ?? '');
$name = mb_substr(trim((string) ($in['name'] ?? '')), 0, 60);
if (!$code || !preg_match('/^[a-f0-9]{64}$/', $device)) { rate_hit("actfail:$ip"); json_out(['ok' => false, 'error' => 'invalid']); }

$c = row('SELECT * FROM codes WHERE code=?', [$code]);
if (!$c) { rate_hit("actfail:$ip"); json_out(['ok' => false, 'error' => 'invalid']); }
$st = code_status($c);
if ($st !== 'active') json_out(['ok' => false, 'error' => $st]);

$dev = row('SELECT * FROM activations WHERE code_id=? AND device_hash=?', [$c['id'], $device]);
if ($dev) {
    update('activations', ['last_at' => time(), 'device_name' => $name], 'id=?', [$dev['id']]);   // همین گوشی؛ ظرفیت جدید مصرف نمی‌شود
} else {
    if (activation_count((int) $c['id']) >= (int) $c['max_uses']) json_out(['ok' => false, 'error' => 'limit']);
    try { insert('activations', ['code_id' => $c['id'], 'device_hash' => $device, 'device_name' => $name, 'first_at' => time(), 'last_at' => time()]); }
    catch (PDOException $e) { /* درخواست هم‌زمان همین گوشی */ }
}
$used = activation_count((int) $c['id']);
json_out(['ok' => true, 'expires' => (int) $c['expires_at'], 'used' => $used, 'max' => (int) $c['max_uses']]);
