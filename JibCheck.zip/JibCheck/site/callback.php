<?php
// بازگشت از درگاه زرین‌پال: تایید پرداخت و صدور کد
require __DIR__ . '/inc/bootstrap.php';
$oid = (int) get('o'); $auth = get('Authority'); $status = get('Status');
$o = $oid ? row('SELECT * FROM orders WHERE id=?', [$oid]) : null;
$ok = false; $msg = ''; $code = null;
if (!$o || $o['method'] !== 'gateway' || $o['authority'] === null || !hash_equals((string) $o['authority'], $auth)) {
    $msg = 'اطلاعات بازگشت از درگاه معتبر نیست.';
} elseif ($o['status'] === 'approved') {
    $ok = true; $code = $o['code_id'] ? row('SELECT * FROM codes WHERE id=?', [$o['code_id']]) : null;
} elseif ($status !== 'OK') {
    update('orders', ['status' => 'failed', 'note' => 'پرداخت انجام نشد یا لغو شد', 'updated_at' => time()], "id=? AND status='pending_payment'", [$oid]);
    $msg = 'پرداخت انجام نشد یا توسط شما لغو شد. اگر مبلغی کم شده، معمولاً تا ۷۲ ساعت به حسابت برمی‌گردد.';
} else {
    $ch = curl_init('https://payment.zarinpal.com/pg/v4/payment/verify.json');
    curl_setopt_array($ch, [CURLOPT_POST => true, CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 20,
        CURLOPT_HTTPHEADER => ['Content-Type: application/json', 'Accept: application/json'],
        CURLOPT_POSTFIELDS => json_encode(['merchant_id' => setting('zarinpal_merchant'), 'amount' => (int) $o['amount'] * 10, 'authority' => $auth])]);
    $res = curl_exec($ch); curl_close($ch);
    $j = json_decode((string) $res, true);
    $c = (int) ($j['data']['code'] ?? 0);
    if ($c === 100 || $c === 101) {
        update('orders', ['ref_id' => (string) ($j['data']['ref_id'] ?? '')], 'id=?', [$oid]);
        $code = approve_order($oid); $ok = true;
    } else {
        app_log('Zarinpal verify failed: ' . $res);
        $msg = 'تایید پرداخت توسط درگاه انجام نشد. اگر مبلغ از حسابت کم شده، از بخش پشتیبانی با ذکر شماره سفارش ' . fa($oid) . ' تیکت بفرست.';
    }
}
page_head('نتیجه پرداخت', ['noindex' => 1]);
?>
<div class="card narrow center">
<?php if ($ok): ?>
  <div style="font-size:3rem">🎉</div><h2>پرداخت با موفقیت انجام شد</h2>
  <p class="muted">کد فعال‌سازی برایت پیامک شد و در پنل کاربری هم قابل دیدن است.</p>
  <?php if ($code && user() && (int) user()['id'] === (int) $o['user_id']): ?>
    <div class="codebox"><span><?= e($code['code']) ?></span><button type="button" data-copy="<?= e($code['code']) ?>">کپی</button></div>
  <?php endif; ?>
  <p><a class="btn" href="<?= e(u('panel.php')) ?>">رفتن به پنل من</a></p>
<?php else: ?>
  <div style="font-size:3rem">⚠️</div><h2>پرداخت ناموفق</h2><p class="muted"><?= e($msg) ?></p>
  <p><a class="btn" href="<?= e(u('buy.php')) ?>">تلاش دوباره</a></p>
<?php endif; ?>
</div>
<?php page_foot(); ?>
