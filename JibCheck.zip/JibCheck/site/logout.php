<?php
require __DIR__ . '/inc/bootstrap.php';
remember_clear();
unset($_SESSION['uid']); session_regenerate_id(true);
flash('از حساب خارج شدی.', 'ok');
redirect(u(''));
