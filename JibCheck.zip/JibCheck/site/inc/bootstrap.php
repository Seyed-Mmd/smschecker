<?php
define('JC_ROOT', dirname(__DIR__));
if (!is_file(JC_ROOT . '/config.php')) {
    http_response_code(503);
    exit('<!doctype html><meta charset="utf-8"><p dir="rtl" style="font-family:tahoma;padding:2em">سایت هنوز نصب نشده است. فایل <b>install.php</b> را در مرورگر باز کنید.</p>');
}
$CFG = require JC_ROOT . '/config.php';
date_default_timezone_set('Asia/Tehran');
mb_internal_encoding('UTF-8');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: SAMEORIGIN');
header('Referrer-Policy: same-origin');
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/helpers.php';
require_once __DIR__ . '/sms.php';
require_once __DIR__ . '/license.php';
require_once __DIR__ . '/coupon.php';
require_once __DIR__ . '/remember.php';
require_once __DIR__ . '/layout.php';
session_boot();
try { migrate(); } catch (Throwable $e) { app_log('migrate failed: ' . $e->getMessage()); }
try { remember_login_if_needed(); } catch (Throwable $e) { app_log('remember-me failed: ' . $e->getMessage()); }
