<?php
// «مرا به‌خاطر بسپار»: یک کوکی جدا از سشن اصلی (الگوی selector/validator)، تا کاربر حتی اگر
// سشن سمت سرور به هر دلیلی (پاک‌سازی هاست، تعویض مرورگر session و...) از بین رفت، دوباره لاگین نشود.
const REMEMBER_DAYS = 365;
const REMEMBER_COOKIE = 'jc_remember';

function remember_https(): bool {
    return (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
}
function remember_cookie_opts(int $expires): array {
    return ['expires' => $expires, 'path' => '/', 'secure' => remember_https(), 'httponly' => true, 'samesite' => 'Lax'];
}

// بعد از ورود موفق صدا زده می‌شود: یک توکن تازه می‌سازد و کوکی را ست می‌کند
function remember_set(int $userId): void {
    $selector = bin2hex(random_bytes(9));
    $validator = bin2hex(random_bytes(24));
    $exp = time() + REMEMBER_DAYS * 86400;
    insert('remember_tokens', ['user_id' => $userId, 'selector' => $selector,
        'validator_hash' => hash('sha256', $validator), 'expires_at' => $exp, 'created_at' => time()]);
    setcookie(REMEMBER_COOKIE, $selector . ':' . $validator, remember_cookie_opts($exp));
}

// موقع خروج صدا زده می‌شود: فقط توکن همین دستگاه را باطل می‌کند (دستگاه‌های دیگر کاربر دست نمی‌خورند)
function remember_clear(): void {
    if (!empty($_COOKIE[REMEMBER_COOKIE]) && str_contains($_COOKIE[REMEMBER_COOKIE], ':')) {
        [$selector] = explode(':', $_COOKIE[REMEMBER_COOKIE], 2);
        q('DELETE FROM remember_tokens WHERE selector=?', [$selector]);
    }
    setcookie(REMEMBER_COOKIE, '', remember_cookie_opts(time() - 3600));
}

// اگر سشن فعال نیست ولی کوکی «به‌خاطر بسپار» معتبر است، کاربر را دوباره لاگین می‌کند.
// بعد از هر استفاده توکن را عوض می‌کند (چرخش) تا اگر کوکی قدیمی جایی لو رفته بود، بی‌اثر شود.
function remember_login_if_needed(): void {
    if (!empty($_SESSION['uid']) || empty($_COOKIE[REMEMBER_COOKIE]) || !str_contains($_COOKIE[REMEMBER_COOKIE], ':')) return;
    [$selector, $validator] = explode(':', $_COOKIE[REMEMBER_COOKIE], 2);
    $t = row('SELECT * FROM remember_tokens WHERE selector=?', [$selector]);
    if (!$t || (int) $t['expires_at'] < time()) { setcookie(REMEMBER_COOKIE, '', remember_cookie_opts(time() - 3600)); return; }
    if (!hash_equals($t['validator_hash'], hash('sha256', $validator))) {
        // کوکی نامعتبر با selector درست؛ احتمال سرقت است، همه‌ی توکن‌های این کاربر را باطل کن
        q('DELETE FROM remember_tokens WHERE user_id=?', [(int) $t['user_id']]);
        setcookie(REMEMBER_COOKIE, '', remember_cookie_opts(time() - 3600));
        return;
    }
    $u = row('SELECT * FROM users WHERE id=?', [(int) $t['user_id']]);
    if (!$u) { q('DELETE FROM remember_tokens WHERE id=?', [$t['id']]); return; }
    q('DELETE FROM remember_tokens WHERE id=?', [$t['id']]);   // چرخش: توکن قبلی مصرف شد
    session_regenerate_id(true);
    $_SESSION['uid'] = (int) $u['id'];
    $_SESSION['csrf'] = bin2hex(random_bytes(16));
    q('UPDATE users SET last_login=? WHERE id=?', [time(), $u['id']]);
    remember_set((int) $u['id']);
}
