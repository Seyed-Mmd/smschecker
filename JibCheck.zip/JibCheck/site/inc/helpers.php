<?php
function e($s): string { return htmlspecialchars((string) $s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }

// ───── اعداد و تاریخ ─────
function fa($s): string { return strtr((string) $s, ['0'=>'۰','1'=>'۱','2'=>'۲','3'=>'۳','4'=>'۴','5'=>'۵','6'=>'۶','7'=>'۷','8'=>'۸','9'=>'۹']); }
function en_digits(string $s): string {
    return strtr($s, ['۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9',
                      '٠'=>'0','١'=>'1','٢'=>'2','٣'=>'3','٤'=>'4','٥'=>'5','٦'=>'6','٧'=>'7','٨'=>'8','٩'=>'9']);
}
function toman($n): string { return fa(number_format((int) $n)) . ' تومان'; }
function g2j(int $gy, int $gm, int $gd): array {
    $gdm = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
    $gy2 = ($gm > 2) ? ($gy + 1) : $gy;
    $days = 355666 + (365 * $gy) + intdiv($gy2 + 3, 4) - intdiv($gy2 + 99, 100) + intdiv($gy2 + 399, 400) + $gd + $gdm[$gm - 1];
    $jy = -1595 + (33 * intdiv($days, 12053)); $days %= 12053;
    $jy += 4 * intdiv($days, 1461); $days %= 1461;
    if ($days > 365) { $jy += intdiv($days - 1, 365); $days = ($days - 1) % 365; }
    if ($days < 186) { $jm = 1 + intdiv($days, 31); $jd = 1 + ($days % 31); }
    else { $jm = 7 + intdiv($days - 186, 30); $jd = 1 + (($days - 186) % 30); }
    return [$jy, $jm, $jd];
}
function jdate(int $ts, bool $time = false): string {
    if ($ts <= 0) return '—';
    [$y, $m, $d] = g2j((int) date('Y', $ts), (int) date('n', $ts), (int) date('j', $ts));
    $s = sprintf('%04d/%02d/%02d', $y, $m, $d);
    if ($time) $s .= ' ' . date('H:i', $ts);
    return fa($s);
}

// ───── ورودی‌ها ─────
function norm_mobile(string $s): ?string {
    $s = preg_replace('/[\s\-+()]/u', '', en_digits($s));
    if (preg_match('/^(?:0098|98)(9\d{9})$/', $s, $m)) return '0' . $m[1];
    if (preg_match('/^(9\d{9})$/', $s, $m)) return '0' . $m[1];
    if (preg_match('/^(09\d{9})$/', $s)) return $s;
    return null;
}
function post(string $k, string $def = ''): string { return trim((string) ($_POST[$k] ?? $def)); }
function get(string $k, string $def = ''): string { return trim((string) ($_GET[$k] ?? $def)); }
function client_ip(): string { return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0'; }

// ───── جلسه، CSRF، پیام‌ها ─────
function session_boot(): void {
    if (session_status() === PHP_SESSION_ACTIVE) return;
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
    ini_set('session.gc_maxlifetime', '2592000');
    ini_set('session.use_strict_mode', '1');
    session_name('jc_sess');
    session_set_cookie_params(['lifetime' => 2592000, 'path' => '/', 'secure' => $https, 'httponly' => true, 'samesite' => 'Lax']);
    session_start();
}
function csrf_token(): string {
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(16));
    return $_SESSION['csrf'];
}
function csrf_field(): string { return '<input type="hidden" name="_t" value="' . e(csrf_token()) . '">'; }
function csrf_check(): void {
    $t = $_POST['_t'] ?? '';
    if (!is_string($t) || !hash_equals(csrf_token(), $t)) { http_response_code(400); exit('درخواست نامعتبر یا منقضی شده است. صفحه را دوباره باز کنید.'); }
}
function flash(string $msg, string $type = 'ok'): void { $_SESSION['flash'][] = [$type, $msg]; }
function redirect(string $url): never { header('Location: ' . $url); exit; }
function json_out(array $a, int $code = 200): never {
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode($a, JSON_UNESCAPED_UNICODE);
    exit;
}
function base_path(): string { global $CFG; return rtrim((string) parse_url($CFG['site_url'], PHP_URL_PATH), '/'); }
function u(string $path = ''): string { return base_path() . '/' . ltrim($path, '/'); }   // لینک داخلی (مستقل از پوشه نصب)
function site_url(string $path = ''): string { global $CFG; return rtrim($CFG['site_url'], '/') . '/' . ltrim($path, '/'); }
function app_log(string $msg): void {
    @file_put_contents(JC_ROOT . '/storage/app.log', '[' . date('Y-m-d H:i:s') . '] ' . $msg . "\n", FILE_APPEND | LOCK_EX);
}

// ───── محدودیت تعداد درخواست ─────
function rate_count(string $key, int $window): int {
    return (int) val('SELECT COUNT(*) FROM rate WHERE k=? AND ts>?', [$key, time() - $window]);
}
function rate_hit(string $key): void {
    insert('rate', ['k' => $key, 'ts' => time()]);
    if (random_int(1, 50) === 1) q('DELETE FROM rate WHERE ts<?', [time() - 86400 * 2]);
}

// ───── کاربر و ادمین ─────
function user(): ?array {
    static $u = false;
    if ($u === false) $u = !empty($_SESSION['uid']) ? row('SELECT * FROM users WHERE id=?', [(int) $_SESSION['uid']]) : null;
    return $u;
}
function require_user(): array {
    $u = user();
    if (!$u) { $_SESSION['next'] = basename($_SERVER['SCRIPT_NAME']) . (!empty($_SERVER['QUERY_STRING']) ? '?' . $_SERVER['QUERY_STRING'] : ''); redirect(u('login.php')); }
    return $u;
}
function is_admin(): bool {
    return !empty($_SESSION['aid']) && (($_SESSION['atime'] ?? 0) > time() - 8 * 3600);
}

// ───── ارتباط با کاربر: برچسب وضعیت‌ها ─────
function order_status_label(string $s): array {
    return match ($s) {
        'pending_payment' => ['در انتظار پرداخت', 'warn'],
        'awaiting_review' => ['در انتظار تایید ادمین', 'info'],
        'approved' => ['تایید شده', 'ok'],
        'rejected' => ['رد شده', 'bad'],
        'failed' => ['پرداخت ناموفق', 'bad'],
        default => [$s, 'muted'],
    };
}
function method_label(string $m): string { return match ($m) { 'gateway' => 'درگاه پرداخت', 'coupon' => 'رایگان (کد تخفیف)', default => 'کارت‌به‌کارت' }; }
// ───── تایید دومرحله‌ای عمومی (برای هر عملیات حساس در پنل ادمین) ─────
// فقط یک درخواست تاییدِ معلق در هر لحظه نگه داشته می‌شود؛ هر صفحه فقط تاییدِ مخصوص خودش را نشان می‌دهد
const CONFIRM_TTL = 300;
function confirm_pending(string $page): ?array {
    $p = $_SESSION['pending_confirm'] ?? null;
    if (!$p || $p['created'] < time() - CONFIRM_TTL || $p['page'] !== $page) return null;
    return $p;
}
function confirm_request(string $page, string $kind, string $label, array $extra = []): never {
    $_SESSION['pending_confirm'] = array_merge(['token' => bin2hex(random_bytes(12)), 'page' => $page, 'kind' => $kind, 'label' => $label, 'created' => time()], $extra);
    redirect(u($page));
}
function confirm_box(string $page): void {
    $p = confirm_pending($page);
    if (!$p) return;
    echo '<div class="card confirm-box"><b>⚠️ تایید نهایی لازم است</b><p>' . e($p['label']) . '</p><div class="row">'
       . '<form method="post">' . csrf_field() . '<input type="hidden" name="act" value="confirm_apply"><input type="hidden" name="token" value="' . e($p['token']) . '"><button class="btn btn-sm btn-bad" type="submit">تایید و اعمال</button></form>'
       . '<form method="post">' . csrf_field() . '<input type="hidden" name="act" value="confirm_cancel"><button class="btn btn-sm btn-ghost" type="submit">انصراف</button></form></div></div>';
}

function ticket_status_label(string $s): array {
    return match ($s) { 'open' => ['در انتظار پاسخ', 'warn'], 'answered' => ['پاسخ داده شد', 'ok'], default => ['بسته شده', 'muted'] };
}

// ───── پیوست عکس در تیکت‌ها (برای کاربر و ادمین) ─────
const TICKET_MAX_IMAGES = 3;                     // حداکثر تعداد عکس در هر پیام
const TICKET_MAX_BYTES  = 5 * 1024 * 1024;       // حداکثر حجم هر عکس
function ticket_dir(): string {
    $dir = JC_ROOT . '/storage/tickets';
    if (!is_dir($dir)) @mkdir($dir, 0755, true);
    if (is_dir($dir) && !is_file("$dir/.htaccess")) {   // دسترسی مستقیم از وب ممنوع؛ عکس‌ها فقط از طریق ticket_file.php و با بررسی مجوز نمایش داده می‌شوند
        @file_put_contents("$dir/.htaccess", "<IfModule mod_authz_core.c>\n  Require all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\n  Order allow,deny\n  Deny from all\n</IfModule>\n");
        @file_put_contents("$dir/index.html", '');
    }
    return $dir;
}
// اگر مجموع حجم فرم از سقف post_max_size بیشتر باشد، PHP کل $_POST را خالی می‌کند؛ این حالت را تشخیص می‌دهیم
function upload_overflow(): bool {
    return $_SERVER['REQUEST_METHOD'] === 'POST' && empty($_POST) && empty($_FILES) && (int) ($_SERVER['CONTENT_LENGTH'] ?? 0) > 0;
}
// عکس‌های آپلودشده (فیلد images[]) را بررسی و ذخیره می‌کند. خروجی: [نام فایل‌ها, پیام خطا یا null]
function ticket_save_images(string $field = 'images'): array {
    $f = $_FILES[$field] ?? null;
    if (!$f || !isset($f['name'])) return [[], null];
    $names = is_array($f['name']) ? $f['name'] : [$f['name']];
    $n = count($names); $saved = []; $count = 0;
    for ($i = 0; $i < $n; $i++) {
        $err = is_array($f['error']) ? $f['error'][$i] : $f['error'];
        if ($err === UPLOAD_ERR_NO_FILE) continue;
        $count++;
        if ($count > TICKET_MAX_IMAGES) { ticket_discard($saved); return [[], 'حداکثر ' . fa(TICKET_MAX_IMAGES) . ' عکس در هر پیام قابل ارسال است.']; }
        $tmp = is_array($f['tmp_name']) ? $f['tmp_name'][$i] : $f['tmp_name'];
        $size = (int) (is_array($f['size']) ? $f['size'][$i] : $f['size']);
        if ($err === UPLOAD_ERR_INI_SIZE || $err === UPLOAD_ERR_FORM_SIZE || $size > TICKET_MAX_BYTES) { ticket_discard($saved); return [[], 'حجم هر عکس باید کمتر از ' . fa(TICKET_MAX_BYTES / 1048576) . ' مگابایت باشد.']; }
        if ($err !== UPLOAD_ERR_OK || !is_uploaded_file($tmp)) { ticket_discard($saved); return [[], 'آپلود عکس ناموفق بود. دوباره امتحان کن.']; }
        $mime = (new finfo(FILEINFO_MIME_TYPE))->file($tmp);
        $ext = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'][$mime] ?? null;
        if (!$ext || !@getimagesize($tmp)) { ticket_discard($saved); return [[], 'فقط عکس (JPG، PNG یا WEBP) قابل ارسال است.']; }
        $name = bin2hex(random_bytes(16)) . '.' . $ext;
        if (!@move_uploaded_file($tmp, ticket_dir() . '/' . $name)) { ticket_discard($saved); return [[], 'ذخیره‌ی عکس انجام نشد. دوباره امتحان کن.']; }
        $saved[] = $name;
    }
    return [$saved, null];
}
function ticket_discard(array $names): void { foreach ($names as $nm) @unlink(ticket_dir() . '/' . basename($nm)); }
function ticket_attach(int $msgId, array $names): void { foreach ($names as $nm) insert('ticket_files', ['msg_id' => $msgId, 'file' => $nm, 'created_at' => time()]); }
// عکس‌های پیوست‌شده‌ی چند پیام: [شناسه‌ی پیام => [ردیف‌ها]]
function ticket_files_for(array $msgIds): array {
    if (!$msgIds) return [];
    $ph = implode(',', array_fill(0, count($msgIds), '?')); $out = [];
    foreach (rows("SELECT * FROM ticket_files WHERE msg_id IN ($ph) ORDER BY id", array_map('intval', $msgIds)) as $r) $out[(int) $r['msg_id']][] = $r;
    return $out;
}
function ticket_images_html(array $files): string {
    if (!$files) return '';
    $h = '<div class="att">';
    foreach ($files as $f) { $url = e(u('ticket_file.php?id=' . $f['id'])); $h .= '<a href="' . $url . '" target="_blank" rel="noopener"><img src="' . $url . '" alt="عکس پیوست" loading="lazy"></a>'; }
    return $h . '</div>';
}
// حذف همه‌ی عکس‌های یک تیکت (هنگام حذف تیکت)
function ticket_delete_files(int $ticketId): void {
    $fs = rows('SELECT f.id, f.file FROM ticket_files f JOIN ticket_msgs m ON m.id=f.msg_id WHERE m.ticket_id=?', [$ticketId]);
    foreach ($fs as $f) { @unlink(ticket_dir() . '/' . basename($f['file'])); q('DELETE FROM ticket_files WHERE id=?', [$f['id']]); }
}
// فرم انتخاب عکس (مشترک بین کاربر و ادمین)
function ticket_image_input(): string {
    return '<label>پیوست عکس <span class="hint">(اختیاری • تا ' . fa(TICKET_MAX_IMAGES) . ' عکس، هرکدام حداکثر ' . fa(TICKET_MAX_BYTES / 1048576) . ' مگابایت)</span></label>'
         . '<input type="file" name="images[]" accept="image/jpeg,image/png,image/webp" multiple data-images="' . TICKET_MAX_IMAGES . '" data-maxmb="' . (TICKET_MAX_BYTES / 1048576) . '">'
         . '<div class="att-prev" aria-live="polite"></div>';
}
