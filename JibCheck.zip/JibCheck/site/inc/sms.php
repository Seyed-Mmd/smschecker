<?php
// ارسال پیامک با SMS.ir
//  • اگر برای هر نوع پیام «شناسه قالب» (Template ID) در پنل ادمین ثبت شده باشد، از ارسال سریع (verify) استفاده می‌شود
//  • وگرنه با «شماره خط» و متن پیام، ارسال معمولی (bulk) انجام می‌شود
function sms_types(): array {
    return [
        'otp'          => ['param' => 'Code',   'title' => 'کد ورود کاربر',               'text' => "کد ورود شما به جیب‌چک: {v}\nاین کد تا ۲ دقیقه معتبر است."],
        'code'         => ['param' => 'Code',   'title' => 'کد فعال‌سازی بعد از خرید',     'text' => "خرید شما در جیب‌چک تایید شد.\nکد فعال‌سازی: {v}\nاین کد روی حداکثر ۲ گوشی فعال می‌شود."],
        'admin_order'  => ['param' => 'Order',  'title' => 'اطلاع به ادمین: سفارش جدید',    'text' => "یک سفارش در انتظار تایید داری (سفارش شماره {v})."],
        'admin_ticket' => ['param' => 'Ticket', 'title' => 'اطلاع به ادمین: تیکت جدید',     'text' => "یک تیکت پشتیبانی جدید داری (تیکت شماره {v})."],
        'ticket_reply' => ['param' => 'Ticket', 'title' => 'اطلاع به کاربر: پاسخ تیکت',     'text' => "تیکت شماره {v} شما در جیب‌چک پاسخ داده شد. پاسخ را در پنل کاربری ببینید."],
    ];
}
function sms_post(string $path, array $payload): array {
    $ch = curl_init('https://api.sms.ir/v1/send/' . $path);
    curl_setopt_array($ch, [
        CURLOPT_POST => true, CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 12, CURLOPT_CONNECTTIMEOUT => 6,
        CURLOPT_HTTPHEADER => ['Content-Type: application/json', 'Accept: application/json', 'X-API-KEY: ' . setting('sms_api_key')],
        CURLOPT_POSTFIELDS => json_encode($payload, JSON_UNESCAPED_UNICODE),
    ]);
    $res = curl_exec($ch);
    $err = curl_error($ch);
    curl_close($ch);
    if ($res === false) return [false, 'curl: ' . $err];
    $j = json_decode($res, true);
    return [is_array($j) && (int) ($j['status'] ?? 0) === 1, $res];
}
// $v مقدار متغیر پیام است (کد، شماره سفارش یا شماره تیکت)
function sms_send(string $type, string $mobile, string $v): bool {
    global $CFG;
    $t = sms_types()[$type] ?? null;
    if (!$t) return false;
    $text = str_replace('{v}', $v, setting('sms_txt_' . $type) !== '' ? setting('sms_txt_' . $type) : $t['text']);
    if (!empty($CFG['dev_mode'])) {   // حالت آزمایشی: پیامک واقعی نمی‌رود، فقط در فایل ثبت می‌شود
        @file_put_contents(JC_ROOT . '/storage/sms_debug.log', "[$type] $mobile: $text\n", FILE_APPEND | LOCK_EX);
        return true;
    }
    if (setting('sms_api_key') === '') { app_log("SMS skipped (no api key): $type"); return false; }
    $tpl = (int) setting('sms_tpl_' . $type);
    if ($tpl > 0) {
        [$ok, $res] = sms_post('verify', ['mobile' => $mobile, 'templateId' => $tpl, 'parameters' => [['name' => $t['param'], 'value' => $v]]]);
    } else {
        $line = (int) setting('sms_line');
        if ($line <= 0) { app_log("SMS skipped (no line/template): $type"); return false; }
        [$ok, $res] = sms_post('bulk', ['lineNumber' => $line, 'messageText' => $text, 'mobiles' => [$mobile]]);
    }
    if (!$ok) app_log("SMS failed ($type): $res");
    return $ok;
}
function notify_admin(string $type, string $v): void {
    $m = norm_mobile(setting('admin_phone'));
    if (setting('admin_notify') === '1' && $m) sms_send($type, $m, $v);
}
