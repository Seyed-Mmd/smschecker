<?php
// کد تخفیف: درصدی یا مبلغ ثابت، با سقف تعداد استفاده و تاریخ انقضا

const COUPON_MIN_PAY = 1000;   // کمترین مبلغ قابل پرداخت (تومان) در درگاه؛ کمتر از آن یا رایگان است یا همین حداقل

function coupon_norm(string $in): string { return strtoupper(preg_replace('/[^A-Za-z0-9_\-]/', '', en_digits(trim($in)))); }
function coupon_find(string $code): ?array { $c = coupon_norm($code); return $c === '' ? null : row('SELECT * FROM coupons WHERE code=?', [$c]); }
// تعداد استفاده = تعداد سفارش‌های تاییدشده‌ای که این کد را داشته‌اند (جداگانه شمارنده‌ای نگه داشته نمی‌شود)
function coupon_used(int $id): int { return (int) val("SELECT COUNT(*) FROM orders WHERE coupon_id=? AND status='approved'", [$id]); }
// چند بار همین کاربر از این کد استفاده کرده (تایید‌شده + در انتظار بررسی، تا کارت‌به‌کارتِ معلق هم حساب شود)
function coupon_used_by_user(int $id, int $userId): int {
    return (int) val("SELECT COUNT(*) FROM orders WHERE coupon_id=? AND user_id=? AND status IN ('approved','awaiting_review')", [$id, $userId]);
}

// null یعنی کد برای این کاربر قابل استفاده است؛ در غیر این صورت متن خطا
function coupon_error(array $c, int $userId): ?string {
    if (!(int) $c['active']) return 'این کد تخفیف فعال نیست.';
    if ((int) $c['expires_at'] > 0 && (int) $c['expires_at'] <= time()) return 'مهلت استفاده از این کد تخفیف تمام شده است.';
    if ((int) $c['max_uses'] > 0 && coupon_used((int) $c['id']) >= (int) $c['max_uses']) return 'ظرفیت استفاده از این کد تخفیف تمام شده است.';
    $perUser = (int) ($c['per_user_max'] ?? 1);
    if ($perUser > 0 && coupon_used_by_user((int) $c['id'], $userId) >= $perUser)
        return $perUser === 1 ? 'قبلاً از این کد تخفیف استفاده کرده‌ای.' : 'سهمیه‌ی تو از این کد تخفیف (' . fa($perUser) . ' بار) تمام شده است.';
    return null;
}

// خروجی: [مبلغ نهایی، مبلغ تخفیف]
function coupon_apply(int $price, array $c): array {
    $v = (int) $c['value'];
    $d = $c['kind'] === 'percent' ? intdiv($price * min(100, max(0, $v)), 100) : $v;
    $final = max(0, $price - $d);
    if ($final > 0 && $final < COUPON_MIN_PAY) $final = min($price, COUPON_MIN_PAY);
    return [$final, $price - $final];
}
function coupon_desc(array $c): string { return $c['kind'] === 'percent' ? fa((int) $c['value']) . '٪ تخفیف' : toman($c['value']) . ' تخفیف'; }
function coupon_state(array $c): array {
    if (!(int) $c['active']) return ['غیرفعال', 'muted'];
    if ((int) $c['expires_at'] > 0 && (int) $c['expires_at'] <= time()) return ['منقضی شده', 'bad'];
    if ((int) $c['max_uses'] > 0 && coupon_used((int) $c['id']) >= (int) $c['max_uses']) return ['ظرفیت تمام', 'bad'];
    return ['فعال', 'ok'];
}
