<?php
// اتصال به پایگاه داده (MySQL یا SQLite) و توابع کوتاه کار با آن
function db(): PDO {
    static $pdo = null;
    if ($pdo) return $pdo;
    global $CFG;
    $d = $CFG['db'];
    $opt = [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC];
    if (($d['driver'] ?? 'mysql') === 'sqlite') {
        $pdo = new PDO('sqlite:' . $d['sqlite_path'], null, null, $opt);
        $pdo->exec('PRAGMA foreign_keys = ON');
        $pdo->exec('PRAGMA busy_timeout = 5000');
    } else {
        $pdo = new PDO('mysql:host=' . $d['host'] . ';dbname=' . $d['name'] . ';charset=utf8mb4', $d['user'], $d['pass'], $opt);
    }
    return $pdo;
}
function q(string $sql, array $p = []): PDOStatement { $s = db()->prepare($sql); $s->execute($p); return $s; }
function row(string $sql, array $p = []): ?array { $r = q($sql, $p)->fetch(); return $r ?: null; }
function rows(string $sql, array $p = []): array { return q($sql, $p)->fetchAll(); }
function val(string $sql, array $p = []) { $r = q($sql, $p)->fetchColumn(); return $r === false ? null : $r; }
function insert(string $table, array $data): int {
    $cols = implode(',', array_keys($data));
    $ph = implode(',', array_fill(0, count($data), '?'));
    q("INSERT INTO $table ($cols) VALUES ($ph)", array_values($data));
    return (int) db()->lastInsertId();
}
function update(string $table, array $data, string $where, array $wp = []): int {
    $set = implode(',', array_map(fn($k) => "$k=?", array_keys($data)));
    return q("UPDATE $table SET $set WHERE $where", array_merge(array_values($data), $wp))->rowCount();
}

// ───── جدول‌ها ─────
function schema_sql(string $driver): array {
    $pk = $driver === 'sqlite' ? 'INTEGER PRIMARY KEY AUTOINCREMENT' : 'INT UNSIGNED AUTO_INCREMENT PRIMARY KEY';
    $int = $driver === 'sqlite' ? 'INTEGER' : 'BIGINT';
    $s = $driver === 'sqlite' ? 'TEXT' : 'VARCHAR(255)';
    $t = 'TEXT';
    $eng = $driver === 'sqlite' ? '' : ' ENGINE=InnoDB DEFAULT CHARSET=utf8mb4';
    return [
        "CREATE TABLE IF NOT EXISTS users (id $pk, mobile $s NOT NULL UNIQUE, created_at $int NOT NULL, last_login $int NOT NULL DEFAULT 0)$eng",
        "CREATE TABLE IF NOT EXISTS otps (id $pk, mobile $s NOT NULL, code_hash $s NOT NULL, expires_at $int NOT NULL, attempts $int NOT NULL DEFAULT 0, created_at $int NOT NULL)$eng",
        "CREATE TABLE IF NOT EXISTS orders (id $pk, user_id $int NOT NULL, amount $int NOT NULL, method $s NOT NULL, status $s NOT NULL, authority $s NULL, ref_id $s NULL, receipt_file $s NULL, note $t NULL, code_id $int NULL, coupon_id $int NULL, orig_amount $int NULL, discount $int NULL, created_at $int NOT NULL, updated_at $int NOT NULL)$eng",
        "CREATE TABLE IF NOT EXISTS codes (id $pk, order_id $int NULL, user_id $int NOT NULL, code $s NOT NULL UNIQUE, max_uses $int NOT NULL, expires_at $int NOT NULL DEFAULT 0, revoked $int NOT NULL DEFAULT 0, created_at $int NOT NULL)$eng",
        "CREATE TABLE IF NOT EXISTS activations (id $pk, code_id $int NOT NULL, device_hash $s NOT NULL, device_name $s NULL, first_at $int NOT NULL, last_at $int NOT NULL)$eng",
        "CREATE UNIQUE INDEX uq_act ON activations (code_id, device_hash)",
        "CREATE TABLE IF NOT EXISTS tickets (id $pk, user_id $int NOT NULL, subject $s NOT NULL, status $s NOT NULL, created_at $int NOT NULL, updated_at $int NOT NULL)$eng",
        "CREATE TABLE IF NOT EXISTS ticket_msgs (id $pk, ticket_id $int NOT NULL, is_admin $int NOT NULL DEFAULT 0, body $t NOT NULL, created_at $int NOT NULL)$eng",
        "CREATE TABLE IF NOT EXISTS ticket_files (id $pk, msg_id $int NOT NULL, file $s NOT NULL, created_at $int NOT NULL)$eng",
        "CREATE INDEX ix_tfiles ON ticket_files (msg_id)",
        "CREATE TABLE IF NOT EXISTS settings (k $s NOT NULL PRIMARY KEY, v $t NULL)$eng",
        "CREATE TABLE IF NOT EXISTS rate (id $pk, k $s NOT NULL, ts $int NOT NULL)$eng",
        "CREATE INDEX ix_rate ON rate (k, ts)",
        "CREATE TABLE IF NOT EXISTS coupons (id $pk, code $s NOT NULL UNIQUE, kind $s NOT NULL, value $int NOT NULL, max_uses $int NOT NULL DEFAULT 0, expires_at $int NOT NULL DEFAULT 0, active $int NOT NULL DEFAULT 1, created_at $int NOT NULL)$eng",
        "CREATE TABLE IF NOT EXISTS admins (id $pk, username $s NOT NULL UNIQUE, pass_hash $s NOT NULL)$eng",
        "CREATE TABLE IF NOT EXISTS plans (id $pk, name $s NOT NULL, price $int NOT NULL, days $int NOT NULL, max_uses $int NOT NULL DEFAULT 2, active $int NOT NULL DEFAULT 1, sort_order $int NOT NULL DEFAULT 0, created_at $int NOT NULL)$eng",
        "CREATE TABLE IF NOT EXISTS remember_tokens (id $pk, user_id $int NOT NULL, selector $s NOT NULL UNIQUE, validator_hash $s NOT NULL, expires_at $int NOT NULL, created_at $int NOT NULL)$eng",
    ];
}

// ───── تنظیمات (قابل ویرایش از پنل ادمین) ─────
function setting_defaults(): array {
    return [
        'site_name' => 'جیب‌چک',
        'price' => '149000',
        'license_days' => '365',
        'max_uses' => '2',
        'pay_gateway_on' => '1',
        'pay_card_on' => '1',
        'card_number' => '',
        'card_holder' => '',
        'card_bank' => '',
        'zarinpal_merchant' => '',
        'sms_api_key' => '',
        'sms_line' => '',
        'sms_tpl_otp' => '', 'sms_tpl_code' => '', 'sms_tpl_admin_order' => '', 'sms_tpl_admin_ticket' => '', 'sms_tpl_ticket_reply' => '',
        'sms_txt_otp' => '', 'sms_txt_code' => '', 'sms_txt_admin_order' => '', 'sms_txt_admin_ticket' => '', 'sms_txt_ticket_reply' => '',
        'admin_phone' => '',
        'admin_notify' => '1',
        'app_download_url' => '',
        'buy_note' => '',
        'support_note' => 'پاسخ تیکت‌ها معمولاً در همان روز کاری داده می‌شود.',
    ];
}
function settings_all(bool $reload = false): array {
    static $cache = null;
    if ($cache === null || $reload) {
        $cache = setting_defaults();
        try { foreach (rows('SELECT k, v FROM settings') as $r) $cache[$r['k']] = (string) $r['v']; } catch (Throwable $e) {}
    }
    return $cache;
}
function setting(string $k): string { return settings_all()[$k] ?? ''; }
function set_setting(string $k, string $v): void {
    if (val('SELECT COUNT(*) FROM settings WHERE k=?', [$k])) q('UPDATE settings SET v=? WHERE k=?', [$v, $k]);
    else q('INSERT INTO settings (k, v) VALUES (?, ?)', [$k, $v]);
    settings_all(true);
}

// ───── به‌روزرسانی خودکار ساختار پایگاه داده (برای سایت‌هایی که قبلاً نصب شده‌اند) ─────
const JC_SCHEMA = 5;   // ۲: کد تخفیف | ۳: چند نوع اشتراک (plans)، «مرا به‌خاطر بسپار»، سقف استفاده‌ی هرکاربر از کد تخفیف | ۴: یادداشت روی کاربر/کد | ۵: پیوست عکس در تیکت
function migrate(): void {
    if ((int) (settings_all()['schema_v'] ?? 0) >= JC_SCHEMA) return;
    $drv = db()->getAttribute(PDO::ATTR_DRIVER_NAME);
    $int = $drv === 'sqlite' ? 'INTEGER' : 'BIGINT';
    $s = $drv === 'sqlite' ? 'TEXT' : 'VARCHAR(255)';
    $t = 'TEXT';
    $stmts = [];
    foreach (schema_sql($drv) as $sql) if (str_starts_with($sql, 'CREATE TABLE IF NOT EXISTS coupons') || str_starts_with($sql, 'CREATE TABLE IF NOT EXISTS plans') || str_starts_with($sql, 'CREATE TABLE IF NOT EXISTS remember_tokens') || str_starts_with($sql, 'CREATE TABLE IF NOT EXISTS ticket_files') || str_starts_with($sql, 'CREATE INDEX ix_tfiles')) $stmts[] = $sql;
    foreach (['coupon_id', 'orig_amount', 'discount'] as $col) $stmts[] = "ALTER TABLE orders ADD COLUMN $col $int NULL";
    foreach (['plan_id' => $int, 'plan_days' => $int, 'plan_max_uses' => $int, 'plan_name' => $s] as $col => $type) $stmts[] = "ALTER TABLE orders ADD COLUMN $col $type NULL";
    $stmts[] = "ALTER TABLE coupons ADD COLUMN per_user_max $int NOT NULL DEFAULT 1";
    $stmts[] = "ALTER TABLE users ADD COLUMN note $t NULL";
    $stmts[] = "ALTER TABLE codes ADD COLUMN note $t NULL";
    foreach ($stmts as $sql) {
        try { db()->exec($sql); }
        catch (PDOException $e) { if (!preg_match('/duplicate|already exists/i', $e->getMessage())) throw $e; }   // قبلاً ساخته شده
    }
    // یک پلن پیش‌فرض از روی تنظیمات فعلی، فقط اگر هنوز هیچ پلنی ساخته نشده
    if (!val('SELECT COUNT(*) FROM plans')) {
        $days = (int) setting('license_days');
        $name = $days <= 0 ? 'نامحدود' : ($days % 365 === 0 ? fa((string) ($days / 365)) . ' ساله' : fa((string) $days) . ' روزه');
        insert('plans', ['name' => $name, 'price' => (int) setting('price'), 'days' => $days,
            'max_uses' => max(1, (int) setting('max_uses')), 'active' => 1, 'sort_order' => 0, 'created_at' => time()]);
    }
    set_setting('schema_v', (string) JC_SCHEMA);
}
