<?php
function logo_svg(int $size = 36): string {   // لوگوی برند (فایل assets/logo-192.png)
    return '<img class="logo" src="' . e(u('assets/logo-192.png')) . '?v=3" width="' . $size . '" height="' . $size . '" alt="" decoding="async">';
}
function page_head(string $title, array $o = []): void {
    $admin = !empty($o['admin']);
    $name = setting('site_name');
    $desc = $o['desc'] ?? 'جیب‌چک؛ ثبت خودکار هزینه‌ها از روی پیامک بانک، با دسته‌بندی، بودجه و گزارش‌های کامل. داده‌ها فقط روی گوشی خودت می‌ماند.';
    header('Content-Type: text/html; charset=utf-8');
    if (!empty($o['noindex']) || $admin) header('X-Robots-Tag: noindex, nofollow');
    echo '<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8">';
    echo '<meta name="viewport" content="width=device-width, initial-scale=1">';
    echo '<meta name="color-scheme" content="light dark">';
    echo '<meta name="theme-color" content="#F3F5FA" media="(prefers-color-scheme: light)"><meta name="theme-color" content="#0E1117" media="(prefers-color-scheme: dark)">';
    // پیش‌نمایش لینک (تلگرام، واتساپ، ایتا و ...)
    echo '<meta property="og:type" content="website"><meta property="og:locale" content="fa_IR">';
    echo '<meta property="og:site_name" content="' . e($name) . '"><meta property="og:title" content="' . e($title) . '">';
    echo '<meta property="og:description" content="' . e($desc) . '"><meta name="twitter:card" content="summary">';
    echo '<title>' . e($title) . ($title === $name ? '' : ' | ' . e($name)) . '</title>';
    echo '<meta name="description" content="' . e($desc) . '">';
    $v = '?v=3';
    echo '<link rel="icon" href="' . e(u('favicon.ico')) . $v . '" sizes="any">';
    echo '<link rel="icon" type="image/png" sizes="32x32" href="' . e(u('assets/favicon-32.png')) . $v . '">';
    echo '<link rel="icon" type="image/png" sizes="192x192" href="' . e(u('assets/favicon-192.png')) . $v . '">';
    echo '<link rel="apple-touch-icon" href="' . e(u('assets/apple-touch-icon.png')) . $v . '">';
    echo '<meta property="og:image" content="' . e(site_url('assets/icon-512.png')) . '">';
    echo '<link rel="stylesheet" href="' . e(u('assets/style.css')) . '?v=2">';
    echo '</head><body class="' . e($o['body'] ?? '') . '">';
    echo '<div class="glass-bg" aria-hidden="true"><i></i><i></i><i></i><i></i></div>';
    // تشخیص صفحه‌ی فعلی برای هایلایت شیشه‌ای منو
    $cur = (string) ($_SERVER['SCRIPT_NAME'] ?? '');
    $on = function (string $h) use ($cur): string {
        if ($h === '' || $h[0] === '#') return '';
        $f = substr($h, -1) === '/' ? $h . 'index.php' : $h;
        return substr($cur, -strlen('/' . $f)) === '/' . $f ? ' class="on"' : '';
    };

    echo '<header class="top"><div class="wrap bar">';
    echo '<a class="brand" href="' . e(u($admin ? 'admin/' : '')) . '">' . logo_svg(34) . '<span>' . e($name) . ($admin ? ' <small>مدیریت</small>' : '') . '</span></a>';
    echo '<input type="checkbox" id="navtoggle" class="nav-toggle-in"><label for="navtoggle" class="nav-toggle" aria-label="منو">☰</label><nav>';
    if ($admin) {
        $np = (int) val("SELECT COUNT(*) FROM orders WHERE status='awaiting_review'");
        $nt = (int) val("SELECT COUNT(*) FROM tickets WHERE status='open'");
        $links = ['admin/' => 'داشبورد', 'admin/orders.php' => 'سفارش‌ها' . ($np ? " <i class=\"dot\">" . fa($np) . "</i>" : ''),
                  'admin/codes.php' => 'کدها', 'admin/plans.php' => 'پلن‌ها', 'admin/coupons.php' => 'تخفیف‌ها', 'admin/tickets.php' => 'تیکت‌ها' . ($nt ? " <i class=\"dot\">" . fa($nt) . "</i>" : ''),
                  'admin/users.php' => 'کاربران', 'admin/settings.php' => 'تنظیمات'];
        foreach ($links as $href => $label) echo '<a href="' . e(u($href)) . '"' . $on($href) . '>' . $label . '</a>';
        if (is_admin()) echo '<a href="' . e(u('admin/logout.php')) . '" class="muted-link">خروج</a>';
    } else {
        echo '<a href="' . e(u('')) . '#features">ویژگی‌ها</a><a href="' . e(u('buy.php')) . '"' . $on('buy.php') . '>خرید</a><a href="' . e(u('ticket.php')) . '"' . $on('ticket.php') . '>پشتیبانی</a>';
        if (user()) echo '<a href="' . e(u('panel.php')) . '"' . $on('panel.php') . '>پنل من</a><a href="' . e(u('logout.php')) . '" class="muted-link">خروج</a>';
        else echo '<a class="btn btn-sm" href="' . e(u('login.php')) . '">ورود / ثبت‌نام</a>';
    }
    echo '</nav></div></header><main class="wrap main">';
    if (!empty($_SESSION['flash'])) {
        foreach ($_SESSION['flash'] as [$t, $m]) echo '<div class="alert ' . e($t) . '">' . e($m) . '</div>';
        unset($_SESSION['flash']);
    }
}
function page_foot(array $o = []): void {
    echo '</main>';
    if (empty($o['admin'])) {
        echo '<footer class="foot"><div class="wrap"><div class="foot-grid">';
        echo '<div><div class="brand">' . logo_svg(30) . '<span>' . e(setting('site_name')) . '</span></div><p class="muted">ثبت خودکار هزینه‌ها از روی پیامک بانک؛ ساده، سریع و خصوصی.</p></div>';
        echo '<div><b>دسترسی سریع</b><a href="' . e(u('buy.php')) . '">خرید کد فعال‌سازی</a><a href="' . e(u('panel.php')) . '">پنل کاربری</a><a href="' . e(u('ticket.php')) . '">پشتیبانی و تیکت</a><a href="' . e(u('terms.php')) . '">قوانین و حریم خصوصی</a></div>';
        echo '</div><p class="copy">© ' . fa(date('Y')) . ' ' . e(setting('site_name')) . ' • همه حقوق محفوظ است.</p></div></footer>';
    }
    echo '<script src="' . e(u('assets/app.js')) . '?v=2" defer></script></body></html>';
}
function badge(string $text, string $kind = 'muted'): string { return '<span class="badge ' . e($kind) . '">' . e($text) . '</span>'; }
