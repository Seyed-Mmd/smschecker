<?php
// ساخت کد، ساخت «صفحه‌ی استاتیک کد» روی هاست و تایید سفارش
function gen_code(): string {
    $al = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
    $g = [];
    for ($i = 0; $i < 3; $i++) { $s = ''; for ($j = 0; $j < 4; $j++) $s .= $al[random_int(0, strlen($al) - 1)]; $g[] = $s; }
    return 'JC-' . implode('-', $g);
}
function code_canonical(string $in): ?string {
    $s = strtoupper(preg_replace('/[^A-Za-z0-9]/', '', en_digits($in)));
    if (strlen($s) !== 14 || !str_starts_with($s, 'JC')) return null;
    return 'JC-' . substr($s, 2, 4) . '-' . substr($s, 6, 4) . '-' . substr($s, 10, 4);
}
function code_page_file(string $code): string { return JC_ROOT . '/c/' . hash('sha256', $code) . '.json'; }

// صفحه‌ی استاتیک: برنامه اول همین فایل را می‌خواند (بدون درگیر کردن PHP و پایگاه داده)
function write_code_page(array $c): void {
    $dir = JC_ROOT . '/c';
    if (!is_dir($dir)) @mkdir($dir, 0755, true);
    $ht = $dir . '/.htaccess';
    if (!is_file($ht)) @file_put_contents($ht, "Options -Indexes\n<IfModule mod_headers.c>\nHeader set Cache-Control \"no-cache, max-age=0\"\nHeader set Access-Control-Allow-Origin \"*\"\n</IfModule>\nAddType application/json .json\n");
    $json = json_encode(['v' => 1, 'ok' => !$c['revoked'], 'expires' => (int) $c['expires_at'], 'max' => (int) $c['max_uses']]);
    $f = code_page_file($c['code']);
    $tmp = $f . '.tmp';
    file_put_contents($tmp, $json, LOCK_EX);
    rename($tmp, $f);
}
// $days/$maxUses خالی = از تنظیمات پیش‌فرض (صدور دستی ادمین)؛ برای سفارش‌های دارای پلن، مقدار همان پلن (ثبت‌شده روی خود سفارش) داده می‌شود
function issue_code(int $userId, ?int $orderId, ?int $days = null, ?int $maxUses = null): array {
    $days ??= (int) setting('license_days');
    $maxUses = max(1, $maxUses ?? (int) setting('max_uses'));
    for ($i = 0; $i < 5; $i++) {
        $code = gen_code();
        if (val('SELECT COUNT(*) FROM codes WHERE code=?', [$code])) continue;
        $id = insert('codes', ['order_id' => $orderId, 'user_id' => $userId, 'code' => $code,
            'max_uses' => $maxUses, 'expires_at' => $days > 0 ? time() + $days * 86400 : 0,
            'revoked' => 0, 'created_at' => time()]);
        $row = row('SELECT * FROM codes WHERE id=?', [$id]);
        write_code_page($row);
        return $row;
    }
    throw new RuntimeException('code generation failed');
}
function code_status(array $c): string {
    if ((int) $c['revoked']) return 'revoked';
    if ((int) $c['expires_at'] > 0 && (int) $c['expires_at'] <= time()) return 'expired';
    return 'active';
}
function code_status_label(string $s): array {
    return match ($s) { 'active' => ['فعال', 'ok'], 'expired' => ['منقضی شده', 'bad'], default => ['لغو شده', 'bad'] };
}
function activation_count(int $codeId): int { return (int) val('SELECT COUNT(*) FROM activations WHERE code_id=?', [$codeId]); }

// تایید سفارش (پرداخت درگاه یا تایید ادمین). فقط یک بار کد می‌سازد، حتی اگر دو بار صدا زده شود.
function approve_order(int $orderId): ?array {
    $won = update('orders', ['status' => 'approved', 'updated_at' => time()], "id=? AND status IN ('pending_payment','awaiting_review','rejected','failed')", [$orderId]);
    $o = row('SELECT * FROM orders WHERE id=?', [$orderId]);
    if (!$o) return null;
    if (!$won) return $o['code_id'] ? row('SELECT * FROM codes WHERE id=?', [$o['code_id']]) : null;
    $c = issue_code((int) $o['user_id'], $orderId, $o['plan_days'] !== null ? (int) $o['plan_days'] : null, $o['plan_max_uses'] !== null ? (int) $o['plan_max_uses'] : null);
    update('orders', ['code_id' => $c['id']], 'id=?', [$orderId]);
    $u = row('SELECT mobile FROM users WHERE id=?', [$o['user_id']]);
    if ($u) sms_send('code', $u['mobile'], $c['code']);
    return $c;
}
