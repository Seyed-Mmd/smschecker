<?php
require __DIR__ . '/inc/bootstrap.php';
$u = require_user();
$orders = rows('SELECT * FROM orders WHERE user_id=? ORDER BY id DESC', [$u['id']]);
$codes = rows('SELECT * FROM codes WHERE user_id=? ORDER BY id DESC', [$u['id']]);
$dl = setting('app_download_url');
page_head('پنل کاربری', ['noindex' => 1]);
?>
<div class="row between" style="margin-bottom:14px">
  <div><h2 style="margin:0">پنل کاربری</h2><span class="muted">شماره‌ی تو: <span class="ltr" style="display:inline-block"><?= e(fa($u['mobile'])) ?></span></span></div>
  <div class="row"><a class="btn btn-sm" href="<?= e(u('buy.php')) ?>">خرید کد جدید</a><a class="btn btn-sm btn-ghost" href="<?= e(u('ticket.php')) ?>">پشتیبانی و تیکت</a></div>
</div>

<h3>کدهای فعال‌سازی من</h3>
<?php if (!$codes): ?>
  <div class="card center"><p class="muted">هنوز کدی نداری. بعد از خرید و تایید پرداخت، کد اینجا نمایش داده می‌شود.</p><a class="btn" href="<?= e(u('buy.php')) ?>">خرید کد فعال‌سازی</a></div>
<?php endif; ?>
<?php foreach ($codes as $c):
    $st = code_status($c); $lb = code_status_label($st);
    $used = activation_count((int) $c['id']); $left = max(0, (int) $c['max_uses'] - $used);
    $devs = rows('SELECT * FROM activations WHERE code_id=? ORDER BY id', [$c['id']]);
    $remDays = (int) $c['expires_at'] > 0 ? (int) ceil(((int) $c['expires_at'] - time()) / 86400) : null; ?>
  <div class="card">
    <div class="row between"><b>کد فعال‌سازی</b><?= badge($lb[0], $lb[1]) ?></div>
    <div class="codebox" style="margin:10px 0"><span><?= e($c['code']) ?></span><button type="button" data-copy="<?= e($c['code']) ?>">کپی</button></div>
    <dl class="kv">
      <dt>ظرفیت فعال‌سازی</dt><dd><?= fa($used) ?> از <?= fa($c['max_uses']) ?> استفاده شده — <b><?= $left > 0 ? fa($left) . ' بار دیگر قابل فعال‌سازی' : 'ظرفیت تمام شده' ?></b></dd>
      <dt>تاریخ صدور</dt><dd><?= jdate((int) $c['created_at']) ?></dd>
      <dt>اعتبار</dt><dd><?php
        if ((int) $c['expires_at'] === 0) echo 'بدون انقضا';
        elseif ($st === 'expired') echo '<b style="color:var(--bad)">منقضی شده</b> (' . jdate((int) $c['expires_at']) . ')';
        else echo 'تا ' . jdate((int) $c['expires_at']) . ' (' . fa(max(0, $remDays)) . ' روز مانده)'; ?></dd>
    </dl>
    <?php if ($devs): ?><p class="hint">گوشی‌های فعال‌شده: <?= e(implode('، ', array_map(fn($d) => ($d['device_name'] ?: 'گوشی نامشخص') . ' (' . strip_tags(jdate((int) $d['first_at'])) . ')', $devs))) ?></p><?php endif; ?>
    <?php if ($st === 'expired'): ?><a class="btn btn-sm" href="<?= e(u('buy.php')) ?>">تمدید (خرید کد جدید)</a>
    <?php elseif ($st === 'revoked'): ?><p class="hint">این کد لغو شده است. برای پیگیری از پشتیبانی تیکت بفرست.</p>
    <?php elseif ($left === 0): ?><p class="hint">برای فعال‌سازی روی گوشی جدید، از پشتیبانی تیکت بفرست.</p><?php endif; ?>
  </div>
<?php endforeach; ?>
<?php if ($codes && $dl): ?><p><a class="btn btn-ghost" href="<?= e($dl) ?>" rel="noopener">دانلود برنامه جیب‌چک</a></p><?php endif; ?>

<h3 style="margin-top:28px">سفارش‌های من</h3>
<div class="card scroll">
<?php if (!$orders): ?><p class="muted">سفارشی ثبت نشده است.</p><?php else: ?>
<table class="tbl"><thead><tr><th>شماره</th><th>تاریخ</th><th>مبلغ</th><th>روش</th><th>وضعیت</th><th></th></tr></thead><tbody>
<?php foreach ($orders as $o): $s = order_status_label($o['status']); ?>
<tr><td><?= fa($o['id']) ?></td><td><?= jdate((int) $o['created_at'], true) ?></td><td><?= toman($o['amount']) ?><?php if (!empty($o['plan_name'])): ?><div class="hint"><?= e($o['plan_name']) ?></div><?php endif; ?><?php if ((int) $o['discount'] > 0): ?><div class="hint">با تخفیف (<?= toman($o['discount']) ?> کم شد)</div><?php endif; ?></td><td><?= e(method_label($o['method'])) ?></td>
<td><?= badge($s[0], $s[1]) ?><?php if ($o['status'] === 'rejected' && $o['note']): ?><div class="hint"><?= e($o['note']) ?></div><?php endif; ?></td>
<td><?php if ($o['method'] === 'card' && in_array($o['status'], ['pending_payment', 'awaiting_review', 'rejected'], true)): ?><a href="<?= e(u('card.php?id=' . $o['id'])) ?>">ادامه / مشاهده</a>
<?php elseif ($o['status'] === 'pending_payment' || $o['status'] === 'failed'): ?><a href="<?= e(u('buy.php')) ?>">خرید دوباره</a><?php endif; ?></td></tr>
<?php endforeach; ?></tbody></table><?php endif; ?>
</div>
<?php page_foot(); ?>
